package com.purple.client.module;

import com.purple.client.setting.Setting;
import net.minecraft.client.gui.GuiGraphics;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String category;
    public final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name, String category) {
        this.name = name;
        this.category = category;
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { enabled = !enabled; }

    public void onTick() {}
    public void onRenderHud(GuiGraphics graphics) {}
}
