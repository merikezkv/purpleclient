package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** 2D ESP: рамки рисуются поверх экрана, поэтому видны сквозь стены. */
public class ESP extends Module {
    private final BoolSetting players = new BoolSetting("Игроки", true);
    private final BoolSetting mobs = new BoolSetting("Мобы", false);
    private final BoolSetting names = new BoolSetting("Имена", true);
    private final NumSetting range = new NumSetting("Дальность", 128, 16, 256, 8);
    private final NumSetting red = new NumSetting("Красный", 170, 0, 255, 5);
    private final NumSetting green = new NumSetting("Зелёный", 60, 0, 255, 5);
    private final NumSetting blue = new NumSetting("Синий", 255, 0, 255, 5);

    public ESP() {
        super("ESP", "Render");
        settings.add(players);
        settings.add(mobs);
        settings.add(names);
        settings.add(range);
        settings.add(red);
        settings.add(green);
        settings.add(blue);
    }

    @Override
    public void onRenderHud(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.options.hideGui) return;

        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 cp = cam.getPosition();
        Vector3f look = cam.getLookVector();
        Vector3f up = cam.getUpVector();
        Vector3f left = cam.getLeftVector();

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double tan = Math.tan(Math.toRadians(mc.options.fov().get() / 2.0));
        double aspect = (double) sw / (double) sh;
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);

        int color = 0xFF000000 | ((int) red.value << 16) | ((int) green.value << 8) | (int) blue.value;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStand) continue;
            boolean isPlayer = e instanceof Player;
            if (isPlayer && !players.value) continue;
            if (!isPlayer && !mobs.value) continue;
            if (mc.player.distanceTo(e) > range.value) continue;

            double ox = Mth.lerp(pt, e.xo, e.getX()) - e.getX();
            double oy = Mth.lerp(pt, e.yo, e.getY()) - e.getY();
            double oz = Mth.lerp(pt, e.zo, e.getZ()) - e.getZ();
            AABB box = e.getBoundingBox().move(ox, oy, oz);

            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE;
            double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            boolean visible = true;

            for (int i = 0; i < 8; i++) {
                double x = (i & 1) == 0 ? box.minX : box.maxX;
                double y = (i & 2) == 0 ? box.minY : box.maxY;
                double z = (i & 4) == 0 ? box.minZ : box.maxZ;
                double dx = x - cp.x, dy = y - cp.y, dz = z - cp.z;

                double f = dx * look.x + dy * look.y + dz * look.z;
                if (f < 0.1) { visible = false; break; } // точка за спиной

                double sx = dx * left.x + dy * left.y + dz * left.z;
                double sy = dx * up.x + dy * up.y + dz * up.z;

                double px = sw / 2.0 - (sx / (f * tan * aspect)) * (sw / 2.0);
                double py = sh / 2.0 - (sy / (f * tan)) * (sh / 2.0);

                minX = Math.min(minX, px); maxX = Math.max(maxX, px);
                minY = Math.min(minY, py); maxY = Math.max(maxY, py);
            }
            if (!visible) continue;

            int x1 = (int) Mth.clamp(minX, -5000, 5000), x2 = (int) Mth.clamp(maxX, -5000, 5000);
            int y1 = (int) Mth.clamp(minY, -5000, 5000), y2 = (int) Mth.clamp(maxY, -5000, 5000);

            g.fill(x1, y1, x2 + 1, y1 + 1, color); // верх
            g.fill(x1, y2, x2 + 1, y2 + 1, color); // низ
            g.fill(x1, y1, x1 + 1, y2 + 1, color); // лево
            g.fill(x2, y1, x2 + 1, y2 + 1, color); // право

            if (names.value && isPlayer) {
                g.drawString(mc.font, e.getName(), x1, y1 - 10, color, true);
            }
        }
    }
}
