package com.purple.client.gui;

import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.setting.Setting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class ClickGuiScreen extends Screen {
    private static final int HEADER = 0xFF8A2BE2;
    private static final int ON = 0xFF9D4EDD;
    private static final int OFF = 0xFF2A1745;
    private static final int SETTING_BG = 0xFF1F1233;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int W = 140, ROW = 22;

    private static class Panel {
        final String category;
        int x, y;
        Panel(String c, int x, int y) { this.category = c; this.x = x; this.y = y; }
    }

    private record Hit(int x, int y, int w, int h, Panel panel, Module module, Setting setting) {
        boolean contains(double mx, double my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    private static final List<Panel> PANELS = new ArrayList<>();
    private static final Set<Module> EXPANDED = new HashSet<>();

    private final List<Hit> hits = new ArrayList<>();
    private Panel dragPanel;
    private int dragDX, dragDY;
    private Hit slider;

    public ClickGuiScreen() {
        super(Component.literal("ClickGUI"));
        if (PANELS.isEmpty()) {
            int x = 10;
            LinkedHashSet<String> cats = new LinkedHashSet<>();
            for (Module m : ModuleManager.MODULES) cats.add(m.category);
            for (String c : cats) { PANELS.add(new Panel(c, x, 10)); x += W + 10; }
        }
    }

    @Override
    protected void init() {
        addRenderableWidget(net.minecraft.client.gui.components.Button
                .builder(Component.literal("Закрыть"), b -> onClose())
                .bounds(width - 84, height - 28, 76, 20).build());
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0x80100820); // затемнение
        hits.clear();

        for (Panel p : PANELS) {
            int y = p.y;
            g.fill(p.x, y, p.x + W, y + ROW + 2, HEADER);
            g.drawString(font, p.category, p.x + 6, y + 7, TEXT, false);
            hits.add(new Hit(p.x, y, W, ROW + 2, p, null, null));
            y += ROW + 2;

            for (Module m : ModuleManager.MODULES) {
                if (!m.category.equals(p.category)) continue;
                g.fill(p.x, y, p.x + W, y + ROW, m.isEnabled() ? ON : OFF);
                g.drawString(font, m.name, p.x + 6, y + 7, TEXT, false);
                g.drawString(font, EXPANDED.contains(m) ? "-" : "+", p.x + W - 14, y + 7, TEXT, false);
                hits.add(new Hit(p.x, y, W, ROW, p, m, null));
                y += ROW;

                if (EXPANDED.contains(m)) {
                    for (Setting s : m.settings) {
                        g.fill(p.x, y, p.x + W, y + ROW, SETTING_BG);
                        if (s instanceof BoolSetting b) {
                            g.fill(p.x + W - 18, y + 6, p.x + W - 6, y + 16, b.value ? ON : OFF);
                            g.drawString(font, b.name, p.x + 6, y + 7, TEXT, false);
                        } else if (s instanceof NumSetting n) {
                            double frac = (n.value - n.min) / (n.max - n.min);
                            g.fill(p.x, y, p.x + (int) (W * frac), y + ROW, 0xFF5B2A9E);
                            g.drawString(font, n.name + ": " + trim(n.value), p.x + 6, y + 7, TEXT, false);
                        }
                        hits.add(new Hit(p.x, y, W, ROW, p, m, s));
                        y += ROW;
                    }
                }
            }
            g.fill(p.x, y, p.x + W, y + 2, HEADER);
        }
        super.render(g, mx, my, pt);
    }

    private static String trim(double v) {
        return v == Math.rint(v) ? String.valueOf((int) v) : String.format("%.1f", v);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;

            if (h.setting() instanceof BoolSetting b) {
                if (button == 0) b.value = !b.value;
            } else if (h.setting() instanceof NumSetting) {
                slider = h;
                updateSlider(mx);
            } else if (h.module() != null) {
                boolean arrow = mx >= h.x() + W - 30;
                if (button == 1 || (button == 0 && arrow)) {
                    if (!EXPANDED.remove(h.module())) EXPANDED.add(h.module());
                } else if (button == 0) {
                    h.module().toggle();
                }
            } else {
                dragPanel = h.panel();
                dragDX = (int) mx - h.panel().x;
                dragDY = (int) my - h.panel().y;
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragPanel != null) {
            dragPanel.x = (int) mx - dragDX;
            dragPanel.y = (int) my - dragDY;
            return true;
        }
        if (slider != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragPanel = null;
        slider = null;
        return super.mouseReleased(mx, my, button);
    }

    private void updateSlider(double mx) {
        NumSetting n = (NumSetting) slider.setting();
        double frac = Math.max(0, Math.min(1, (mx - slider.x()) / slider.w()));
        n.set(n.min + frac * (n.max - n.min));
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_Y) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
