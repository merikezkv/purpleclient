package com.purple.client.module;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShapeRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;

public class ESP extends Module {
    private final BoolSetting players = new BoolSetting("Игроки", true);
    private final BoolSetting mobs = new BoolSetting("Мобы", false);
    private final NumSetting range = new NumSetting("Дальность", 128, 16, 256, 8);
    private final NumSetting red = new NumSetting("Красный", 170, 0, 255, 5);
    private final NumSetting green = new NumSetting("Зелёный", 60, 0, 255, 5);
    private final NumSetting blue = new NumSetting("Синий", 255, 0, 255, 5);

    public ESP() {
        super("ESP", "Render");
        settings.add(players);
        settings.add(mobs);
        settings.add(range);
        settings.add(red);
        settings.add(green);
        settings.add(blue);
    }

    @Override
    public void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        PoseStack ps = event.getPoseStack();
        Vec3 cam = event.getCamera().getPosition();
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(false);

        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buffers.getBuffer(RenderType.lines());

        float r = (float) red.value / 255f, g = (float) green.value / 255f, b = (float) blue.value / 255f;

        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);

        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStand) continue;
            boolean isPlayer = e instanceof Player;
            if (isPlayer && !players.value) continue;
            if (!isPlayer && !mobs.value) continue;
            if (mc.player.distanceTo(e) > range.value) continue;

            double x = Mth.lerp(pt, e.xo, e.getX()) - e.getX();
            double y = Mth.lerp(pt, e.yo, e.getY()) - e.getY();
            double z = Mth.lerp(pt, e.zo, e.getZ()) - e.getZ();
            AABB box = e.getBoundingBox().move(x, y, z);
            ShapeRenderer.renderLineBox(ps, vc, box, r, g, b, 1f);
        }

        ps.popPose();

        // рисуем без проверки глубины, чтобы было видно сквозь стены
        RenderSystem.disableDepthTest();
        buffers.endBatch(RenderType.lines());
        RenderSystem.enableDepthTest();
    }
}
