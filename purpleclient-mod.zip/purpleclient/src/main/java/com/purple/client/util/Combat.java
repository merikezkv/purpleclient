package com.purple.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/** Текущая цель, которую бьёт игрок / Aura / TriggerBot. */
public final class Combat {
    private static LivingEntity target;
    private static long time;
    private Combat() {}

    public static void set(LivingEntity e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        target = e;
        time = mc.level.getGameTime();
    }

    public static LivingEntity get() {
        Minecraft mc = Minecraft.getInstance();
        if (target == null || mc.level == null) return null;
        if (!target.isAlive() || mc.level.getGameTime() - time > 60) {
            target = null;
            return null;
        }
        return target;
    }

    /** Ручные удары: если держим ЛКМ и смотрим на живое существо, оно становится целью. */
    public static void trackManual(Minecraft mc) {
        if (mc.player == null || mc.screen != null || !mc.options.keyAttack.isDown()) return;
        if (mc.hitResult instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity le && le != mc.player) {
            set(le);
        }
    }
}
