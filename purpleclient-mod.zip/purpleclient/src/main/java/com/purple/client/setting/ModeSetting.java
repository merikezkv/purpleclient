package com.purple.client.setting;

public class ModeSetting extends Setting {
    public final String[] modes;
    public int index;

    public ModeSetting(String name, int index, String... modes) {
        super(name);
        this.modes = modes;
        this.index = index;
    }

    public String get() { return modes[index]; }
    public boolean is(int i) { return index == i; }
    public void next() { index = (index + 1) % modes.length; }
}
