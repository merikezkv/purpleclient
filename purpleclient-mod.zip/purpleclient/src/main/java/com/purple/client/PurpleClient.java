package com.purple.client;

import com.purple.client.gui.ClickGuiScreen;
import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.util.Combat;
import com.purple.client.util.Commands;
import com.purple.client.util.Config;
import com.purple.client.util.Overlay;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.lwjgl.glfw.GLFW;

@Mod("purpleclient")
public class PurpleClient {
    public static final KeyMapping OPEN_GUI =
            new KeyMapping("key.purpleclient.gui", GLFW.GLFW_KEY_Y, "key.categories.purpleclient");

    public PurpleClient(FMLJavaModLoadingContext context) {
        context.getModEventBus().addListener(this::registerKeys);
        MinecraftForge.EVENT_BUS.addListener(this::onClientTick);
        MinecraftForge.EVENT_BUS.addListener(this::onScreenInit);
        MinecraftForge.EVENT_BUS.addListener(this::onChat);
        MinecraftForge.EVENT_BUS.addListener(this::onKey);
    }

    // Кнопка для телефона: в меню паузы и в инвентаре
    private void onScreenInit(ScreenEvent.Init.Post e) {
        Screen s = e.getScreen();
        if (s instanceof PauseScreen || s instanceof InventoryScreen) {
            e.addListener(Button.builder(Component.literal("Purple GUI"),
                    b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                    .bounds(4, 4, 76, 20).build());
        }
    }

    private void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(OPEN_GUI);
    }

    // Команды через точку: .gps .bind .friend .toggle .help
    private void onChat(ClientChatEvent e) {
        String m = e.getMessage();
        if (m.length() > 1 && m.startsWith(".")) {
            e.setCanceled(true);
            Commands.handle(m.substring(1));
        }
    }

    // Бинды модулей на клавиши
    private void onKey(InputEvent.Key e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null || mc.player == null || e.getAction() != GLFW.GLFW_PRESS) return;
        for (Module m : ModuleManager.MODULES) {
            if (m.bindKey != -1 && m.bindKey == e.getKey()) m.toggle();
        }
    }

    private void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        Config.loadOnce();

        while (OPEN_GUI.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new ClickGuiScreen());
        }
        if (mc.player != null) {
            Combat.trackManual(mc);
            ModuleManager.tick();
            Overlay.tick();
        }
    }
}
