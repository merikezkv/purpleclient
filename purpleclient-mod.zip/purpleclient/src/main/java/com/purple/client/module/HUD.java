package com.purple.client.module;

import com.purple.client.gui.Theme;
import com.purple.client.setting.BoolSetting;
import com.purple.client.util.Combat;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.TextColor;
import net.minecraft.world.entity.LivingEntity;

/** HUD в строке над хотбаром: название клиента, включённые модули, информация о цели. */
public class HUD extends Module {
    private final BoolSetting name = new BoolSetting("Название", true);
    private final BoolSetting list = new BoolSetting("Список модулей", true);
    private final BoolSetting target = new BoolSetting("Цель", true);

    public HUD() {
        super("HUD", "Misc");
        settings.add(name);
        settings.add(list);
        settings.add(target);
    }

    public MutableComponent build(LocalPlayer p) {
        MutableComponent c = Component.empty();
        boolean any = false;

        if (name.value) {
            c.append(Component.literal("PurpleClient").withStyle(s -> s.withColor(TextColor.fromRgb(Theme.rgb))));
            any = true;
        }
        if (list.value) {
            StringBuilder sb = new StringBuilder();
            for (Module m : ModuleManager.MODULES) {
                if (m.isEnabled() && m != this) {
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(m.name);
                }
            }
            if (sb.length() > 0) {
                c.append(Component.literal(" §7[§f" + sb + "§7]"));
                any = true;
            }
        }
        if (target.value) {
            LivingEntity t = Combat.get();
            if (t != null) {
                if (any) c.append(Component.literal(" §8| "));
                c.append(Component.literal(String.format("%s §c%.1f§7/§c%.1f §7%.1fм",
                        t.getName().getString(), t.getHealth(), t.getMaxHealth(), p.distanceTo(t))));
                any = true;
            }
        }
        return any ? c : null;
    }
}
