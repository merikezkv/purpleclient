package com.purple.client.module;

import com.purple.client.gui.Theme;
import com.purple.client.setting.BoolSetting;
import com.purple.client.util.Combat;
import com.purple.client.util.Config;
import com.purple.client.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** HUD: ватермарка, броня, список модулей и перетаскиваемая рамка с информацией о цели. */
public class HUD extends Module {
    public static int tx = 6, ty = 30;
    private static boolean dragging, wasDown;
    private static int dragDX, dragDY;

    private static final int TW = 156, TH = 40;

    private final BoolSetting watermark = new BoolSetting("Ватермарка", true);
    private final BoolSetting armor = new BoolSetting("Броня", true);
    private final BoolSetting list = new BoolSetting("Список модулей", true);
    private final BoolSetting target = new BoolSetting("Цель", true);

    public HUD() {
        super("HUD", "Misc");
        settings.add(watermark);
        settings.add(armor);
        settings.add(list);
        settings.add(target);
    }

    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (watermark.value) drawWatermark(g, mc);
        if (armor.value) drawArmor(g, mc, w, h);
        if (list.value) drawList(g, mc, w);
        if (target.value) drawTarget(g, mc, w, h);
    }

    private void drawWatermark(GuiGraphics g, Minecraft mc) {
        Font f = mc.font;
        String brand = "PurpleClient";
        String rest = " | " + mc.player.getName().getString() + " | " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        int w = f.width(brand) + f.width(rest) + 10;
        Draw.round(g, 6, 6, w, 14, 0xB00D0D0D);
        g.fill(9, 6, 6 + w - 3, 7, Theme.accent());
        g.drawString(f, brand, 11, 10, Theme.accent(), false);
        g.drawString(f, rest, 11 + f.width(brand), 10, 0xFFDDDDDD, false);
    }

    private void drawArmor(GuiGraphics g, Minecraft mc, int w, int h) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        boolean any = false;
        for (EquipmentSlot s : slots) if (!mc.player.getItemBySlot(s).isEmpty()) any = true;
        if (!any) return;
        int x0 = w / 2 - 36, y = h - 76;
        Draw.round(g, x0 - 4, y - 4, 80, 24, 0x990D0D0D);
        for (int i = 0; i < 4; i++) {
            ItemStack s = mc.player.getItemBySlot(slots[i]);
            if (s.isEmpty()) continue;
            g.renderItem(s, x0 + i * 18, y);
            g.renderItemDecorations(mc.font, s, x0 + i * 18, y);
        }
    }

    private void drawList(GuiGraphics g, Minecraft mc, int w) {
        List<Module> on = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) if (m.isEnabled() && m != this) on.add(m);
        on.sort((a, b) -> Integer.compare(mc.font.width(b.name), mc.font.width(a.name)));
        int y = 6;
        for (Module m : on) {
            int tw = mc.font.width(m.name);
            g.fill(w - tw - 10, y, w - 4, y + 11, 0xA00D0D0D);
            g.fill(w - 5, y, w - 4, y + 11, Theme.accent());
            g.drawString(mc.font, m.name, w - tw - 7, y + 2, Theme.accent(), false);
            y += 11;
        }
    }

    private void drawTarget(GuiGraphics g, Minecraft mc, int w, int h) {
        LivingEntity t = Combat.get();
        boolean chat = mc.screen instanceof ChatScreen;
        if (t == null && !chat) { dragging = false; return; }
        if (t == null) t = mc.player; // предпросмотр для перемещения

        tx = Mth.clamp(tx, 0, Math.max(0, w - TW));
        ty = Mth.clamp(ty, 0, Math.max(0, h - TH));

        if (chat) {
            double mx = mc.mouseHandler.xpos() * w / (double) mc.getWindow().getScreenWidth();
            double my = mc.mouseHandler.ypos() * h / (double) mc.getWindow().getScreenHeight();
            boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            if (down && !wasDown && mx >= tx && mx <= tx + TW && my >= ty && my <= ty + TH) {
                dragging = true;
                dragDX = (int) mx - tx;
                dragDY = (int) my - ty;
            }
            if (!down && dragging) {
                dragging = false;
                Config.save();
            }
            if (dragging) {
                tx = Mth.clamp((int) mx - dragDX, 0, Math.max(0, w - TW));
                ty = Mth.clamp((int) my - dragDY, 0, Math.max(0, h - TH));
            }
            wasDown = down;
        } else {
            dragging = false;
            wasDown = false;
        }

        Font f = mc.font;
        int accent = Theme.accent();
        Draw.round(g, tx, ty, TW, TH, 0xC00D0D0D);
        g.fill(tx + 3, ty, tx + TW - 3, ty + 1, accent);

        // голова
        if (t instanceof AbstractClientPlayer ap) {
            PlayerFaceRenderer.draw(g, ap.getSkin(), tx + 5, ty + 6, 28);
        } else {
            g.fill(tx + 5, ty + 6, tx + 33, ty + 34, 0xFF2A2A33);
            g.drawString(f, "?", tx + 17, ty + 16, 0xFFAAAAAA, false);
        }

        // ник
        String name = f.plainSubstrByWidth(t.getName().getString(), 72);
        g.drawString(f, name, tx + 39, ty + 5, 0xFFFFFFFF, false);

        // здоровье
        float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
        float frac = Mth.clamp(hp / max, 0f, 1f);
        int barW = 72;
        int col = frac > 0.6f ? 0xFF4ADE80 : (frac > 0.3f ? 0xFFFACC15 : 0xFFF43F5E);
        g.fill(tx + 39, ty + 16, tx + 39 + barW, ty + 21, 0xFF2A2A33);
        g.fill(tx + 39, ty + 16, tx + 39 + (int) (barW * frac), ty + 21, col);
        g.drawString(f, String.format("%.1f HP  %d бр.", hp, t.getArmorValue()), tx + 39, ty + 25, 0xFFCCCCCC, false);

        // предметы в правой и левой руке
        ItemStack main = t.getMainHandItem(), off = t.getOffhandItem();
        if (!main.isEmpty()) g.renderItem(main, tx + TW - 40, ty + 6);
        if (!off.isEmpty()) g.renderItem(off, tx + TW - 22, ty + 6);
        g.drawString(f, "R", tx + TW - 36, ty + 25, 0xFF8A8A99, false);
        g.drawString(f, "L", tx + TW - 18, ty + 25, 0xFF8A8A99, false);
    }
}
