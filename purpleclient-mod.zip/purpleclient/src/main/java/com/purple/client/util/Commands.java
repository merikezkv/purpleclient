package com.purple.client.util;

import com.mojang.blaze3d.platform.InputConstants;
import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;

import java.util.List;

/** Команды в чате через точку: .help .toggle .gps .bind .friend */
public final class Commands {
    private Commands() {}

    public static void msg(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("§d[PC] §f" + text), false);
    }

    public static Module find(String name) {
        for (Module m : ModuleManager.MODULES) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public static boolean applyBind(Module m, String keyName) {
        try {
            InputConstants.Key key = InputConstants.getKey("key.keyboard." + keyName.toLowerCase());
            m.bindKey = key.getValue();
            m.bindName = keyName.toLowerCase();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void handle(String line) {
        String[] a = line.trim().split("\\s+");
        if (a.length == 0 || a[0].isEmpty()) { help(); return; }
        switch (a[0].toLowerCase()) {
            case "help" -> help();
            case "toggle", "t" -> toggle(a);
            case "gps" -> gps(a);
            case "bind" -> bind(a);
            case "friend", "friends" -> friend(a);
            default -> msg("Неизвестная команда. Список: .help");
        }
    }

    private static void help() {
        msg(".gps <X> <Z>  /  .gps off  - метка с направлением и расстоянием");
        msg(".bind add <модуль> <клавиша>  /  .bind remove <модуль>  /  .bind list  /  .bind clear");
        msg(".friend add [ник]  /  .friend remove <ник>  /  .friend list  /  .friend clear");
        msg(".toggle <модуль>  - включить/выключить модуль");
    }

    private static void toggle(String[] a) {
        if (a.length < 2) { msg("Использование: .toggle <модуль>"); return; }
        Module m = find(a[1]);
        if (m == null) { msg("Нет такого модуля: " + a[1]); return; }
        m.toggle();
        msg(m.name + (m.isEnabled() ? " включён" : " выключен"));
    }

    private static void gps(String[] a) {
        if (a.length == 2 && a[1].equalsIgnoreCase("off")) {
            Gps.active = false;
            msg("GPS выключен");
            return;
        }
        if (a.length < 3) { msg("Использование: .gps <X> <Z>  или  .gps off"); return; }
        try {
            Gps.x = Double.parseDouble(a[1]);
            Gps.z = Double.parseDouble(a[2]);
            Gps.active = true;
            msg("GPS установлен: " + a[1] + " " + a[2] + " (стрелка и расстояние над хотбаром)");
        } catch (NumberFormatException e) {
            msg("Координаты должны быть числами");
        }
    }

    private static void bind(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase() : "";
        switch (sub) {
            case "add" -> {
                if (a.length < 4) { msg("Использование: .bind add <модуль> <клавиша>"); return; }
                Module m = find(a[2]);
                if (m == null) { msg("Нет такого модуля: " + a[2]); return; }
                if (applyBind(m, a[3])) {
                    msg(m.name + " привязан к клавише " + a[3].toUpperCase());
                    Config.save();
                } else {
                    msg("Неизвестная клавиша. Примеры: r, g, f6, right.shift, keypad.1");
                }
            }
            case "remove" -> {
                if (a.length < 3) { msg("Использование: .bind remove <модуль>"); return; }
                Module m = find(a[2]);
                if (m == null) { msg("Нет такого модуля: " + a[2]); return; }
                m.bindKey = -1;
                m.bindName = null;
                Config.save();
                msg("Бинд для " + m.name + " удалён");
            }
            case "list" -> {
                boolean any = false;
                for (Module m : ModuleManager.MODULES) {
                    if (m.bindKey != -1) { msg(m.name + " -> " + m.bindName.toUpperCase()); any = true; }
                }
                if (!any) msg("Биндов нет");
            }
            case "clear" -> {
                for (Module m : ModuleManager.MODULES) { m.bindKey = -1; m.bindName = null; }
                Config.save();
                msg("Все бинды удалены");
            }
            default -> msg("Использование: .bind add <модуль> <клавиша> | remove <модуль> | list | clear");
        }
    }

    private static void friend(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase() : "";
        switch (sub) {
            case "add" -> {
                String name = a.length > 2 ? a[2] : null;
                if (name == null) {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.hitResult instanceof EntityHitResult h && h.getEntity() instanceof Player pl) {
                        name = pl.getName().getString();
                    }
                }
                if (name == null) { msg("Укажите ник или наведите прицел на игрока: .friend add [ник]"); return; }
                msg(Friends.add(name) ? "Друг добавлен: " + name : name + " уже в друзьях");
                Config.save();
            }
            case "remove" -> {
                if (a.length < 3) { msg("Использование: .friend remove <ник>"); return; }
                msg(Friends.remove(a[2]) ? "Друг удалён: " + a[2] : a[2] + " не в друзьях");
                Config.save();
            }
            case "list" -> {
                List<String> l = Friends.list();
                msg(l.isEmpty() ? "Друзей нет" : "Друзья: " + String.join(", ", l));
            }
            case "clear" -> {
                Friends.clear();
                Config.save();
                msg("Список друзей очищен");
            }
            default -> msg("Использование: .friend add [ник] | remove <ник> | list | clear");
        }
    }
}
