package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Commands;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Показывает в чате, что выпил / съел / бросил соперник. */
public class UseTracker extends Module {
    private final NumSetting range = new NumSetting("Дальность", 64, 8, 128, 8);
    private final BoolSetting thrown = new BoolSetting("Броски", true);

    private static class State {
        boolean using;
        int remain;
        ItemStack stack = ItemStack.EMPTY;
    }

    private final Map<Integer, State> states = new HashMap<>();
    private final Set<Integer> seen = new HashSet<>();

    public UseTracker() {
        super("UseTracker", "Misc");
        settings.add(range);
        settings.add(thrown);
    }

    private void report(Player pl, String verb, String item) {
        Commands.msg("§d[Use] §f" + pl.getName().getString() + " §7" + verb + " §e" + item);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        for (Player pl : mc.level.players()) {
            if (pl == mc.player || mc.player.distanceTo(pl) > range.value) continue;
            State s = states.computeIfAbsent(pl.getId(), k -> new State());
            boolean using = pl.isUsingItem();
            if (using) {
                s.stack = pl.getUseItem().copy();
                s.remain = pl.getUseItemRemainingTicks();
            } else if (s.using) {
                if (s.remain <= 2 && !s.stack.isEmpty()) {
                    UseAnim anim = s.stack.getUseAnimation();
                    String verb = anim == UseAnim.DRINK ? "выпил" : (anim == UseAnim.EAT ? "съел" : null);
                    if (verb != null) report(pl, verb, s.stack.getHoverName().getString());
                }
                s.stack = ItemStack.EMPTY;
            }
            s.using = using;
        }

        if (thrown.value) {
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e instanceof ThrowableItemProjectile tp && tp.getOwner() instanceof Player owner
                        && owner != mc.player && e.tickCount < 5 && seen.add(e.getId())) {
                    report(owner, "бросил", tp.getItem().getHoverName().getString());
                }
            }
            if (seen.size() > 400) seen.clear();
        }
    }
}
