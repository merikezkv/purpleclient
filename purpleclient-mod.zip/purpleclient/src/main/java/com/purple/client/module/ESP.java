package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.GlowUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/** ESP через ванильное свечение (контур виден сквозь стены). */
public class ESP extends Module {
    private final BoolSetting players = new BoolSetting("Игроки", true);
    private final BoolSetting mobs = new BoolSetting("Мобы", false);
    private final NumSetting range = new NumSetting("Дальность", 128, 16, 256, 8);

    private final Set<Integer> glowing = new HashSet<>();

    public ESP() {
        super("ESP", "Render");
        settings.add(players);
        settings.add(mobs);
        settings.add(range);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        Set<Integer> now = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStand) continue;
            boolean isPlayer = e instanceof Player;
            if (isPlayer && !players.value) continue;
            if (!isPlayer && !mobs.value) continue;
            if (mc.player.distanceTo(e) > range.value) continue;
            GlowUtil.set(e, true);
            now.add(e.getId());
        }

        for (Iterator<Integer> it = glowing.iterator(); it.hasNext(); ) {
            int id = it.next();
            if (!now.contains(id)) {
                Entity e = mc.level.getEntity(id);
                if (e != null) GlowUtil.set(e, false);
                it.remove();
            }
        }
        glowing.addAll(now);
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) {
            for (int id : glowing) {
                Entity e = mc.level.getEntity(id);
                if (e != null) GlowUtil.set(e, false);
            }
        }
        glowing.clear();
    }
}
