package com.purple.client.module;

import com.mojang.blaze3d.vertex.PoseStack;
import com.purple.client.gui.Theme;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Draw;
import com.purple.client.util.Friends;
import com.purple.client.util.GlowUtil;
import com.purple.client.util.Projector;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/** ESP: рамка по хитбоксу (без направления взгляда) с информацией сверху, либо свечение. */
public class ESP extends Module {
    private final ModeSetting style = new ModeSetting("Стиль", 0, "Рамка", "Свечение");
    private final BoolSetting players = new BoolSetting("Игроки", true);
    private final BoolSetting mobs = new BoolSetting("Мобы", false);
    private final NumSetting range = new NumSetting("Дальность", 96, 16, 256, 8);
    private final BoolSetting info = new BoolSetting("Информация", true);
    private final BoolSetting items = new BoolSetting("Предметы в руках", true);
    private final BoolSetting clientColor = new BoolSetting("Цвет клиента", false);
    private final NumSetting red = new NumSetting("Красный", 170, 0, 255, 5);
    private final NumSetting green = new NumSetting("Зелёный", 60, 0, 255, 5);
    private final NumSetting blue = new NumSetting("Синий", 255, 0, 255, 5);

    private final Set<Integer> glowing = new HashSet<>();

    public ESP() {
        super("ESP", "Render");
        settings.add(style);
        settings.add(players);
        settings.add(mobs);
        settings.add(range);
        settings.add(info);
        settings.add(items);
        settings.add(clientColor);
        settings.add(red);
        settings.add(green);
        settings.add(blue);
    }

    private boolean accept(Minecraft mc, Entity e) {
        if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStand) return false;
        boolean isPlayer = e instanceof Player;
        if (isPlayer && !players.value) return false;
        if (!isPlayer && !mobs.value) return false;
        return mc.player.distanceTo(e) <= range.value;
    }

    private void clearGlow(Minecraft mc) {
        if (mc.level != null) {
            for (int id : glowing) {
                Entity e = mc.level.getEntity(id);
                if (e != null) GlowUtil.set(e, false);
            }
        }
        glowing.clear();
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (!style.is(1)) {
            if (!glowing.isEmpty()) clearGlow(mc);
            return;
        }
        Set<Integer> now = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!accept(mc, e)) continue;
            GlowUtil.set(e, true);
            now.add(e.getId());
        }
        for (Iterator<Integer> it = glowing.iterator(); it.hasNext(); ) {
            int id = it.next();
            if (!now.contains(id)) {
                Entity e = mc.level.getEntity(id);
                if (e != null) GlowUtil.set(e, false);
                it.remove();
            }
        }
        glowing.addAll(now);
    }

    @Override
    public void onDisable() {
        clearGlow(Minecraft.getInstance());
    }

    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        if (!style.is(0)) return;
        Minecraft mc = Minecraft.getInstance();
        Projector pr = Projector.create(mc);
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        int baseColor = clientColor.value ? Theme.accent()
                : 0xFF000000 | ((int) red.value << 16) | ((int) green.value << 8) | (int) blue.value;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!accept(mc, e)) continue;
            LivingEntity le = (LivingEntity) e;

            double ox = Mth.lerp(pt, e.xo, e.getX()) - e.getX();
            double oy = Mth.lerp(pt, e.yo, e.getY()) - e.getY();
            double oz = Mth.lerp(pt, e.zo, e.getZ()) - e.getZ();
            AABB box = e.getBoundingBox().move(ox, oy, oz);

            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            boolean ok = true;
            for (int i = 0; i < 8; i++) {
                double x = (i & 1) == 0 ? box.minX : box.maxX;
                double y = (i & 2) == 0 ? box.minY : box.maxY;
                double z = (i & 4) == 0 ? box.minZ : box.maxZ;
                if (!pr.project(x, y, z)) { ok = false; break; }
                minX = Math.min(minX, pr.sx); maxX = Math.max(maxX, pr.sx);
                minY = Math.min(minY, pr.sy); maxY = Math.max(maxY, pr.sy);
            }
            if (!ok) continue;

            int x1 = (int) Mth.clamp(minX, -3000, 3000), x2 = (int) Mth.clamp(maxX, -3000, 3000);
            int y1 = (int) Mth.clamp(minY, -3000, 3000), y2 = (int) Mth.clamp(maxY, -3000, 3000);
            boolean friend = e instanceof Player pl && Friends.isFriend(pl.getName().getString());
            int color = friend ? 0xFF4ADE80 : baseColor;

            // тёмная подложка + цветная рамка
            g.fill(x1 - 1, y1 - 1, x2 + 2, y1 + 1, 0xAA000000);
            g.fill(x1 - 1, y2, x2 + 2, y2 + 2, 0xAA000000);
            g.fill(x1 - 1, y1 - 1, x1 + 1, y2 + 2, 0xAA000000);
            g.fill(x2, y1 - 1, x2 + 2, y2 + 2, 0xAA000000);
            g.fill(x1, y1, x2 + 1, y1 + 1, color);
            g.fill(x1, y2, x2 + 1, y2 + 1, color);
            g.fill(x1, y1, x1 + 1, y2 + 1, color);
            g.fill(x2, y1, x2 + 1, y2 + 1, color);

            if (info.value) drawLabel(g, mc, le, (x1 + x2) / 2, y1, friend);
        }
    }

    private void drawLabel(GuiGraphics g, Minecraft mc, LivingEntity le, int cx, int top, boolean friend) {
        String name = le.getName().getString();
        float hp = le.getHealth();
        String hpColor = hp / Math.max(1f, le.getMaxHealth()) > 0.6f ? "§a" : (hp / Math.max(1f, le.getMaxHealth()) > 0.3f ? "§e" : "§c");
        String line2 = hpColor + String.format("%.1f HP", hp) + " §7| §9" + le.getArmorValue() + " брони";

        boolean showItems = items.value && (!le.getMainHandItem().isEmpty() || !le.getOffhandItem().isEmpty());
        int y = top - 12 - (showItems ? 14 : 0) - 11;
        int w1 = mc.font.width(name), w2 = mc.font.width(line2);
        Draw.round(g, cx - w1 / 2 - 3, y - 1, w1 + 6, 10, 0xAA0D0D0D);
        g.drawString(mc.font, name, cx - w1 / 2, y, friend ? 0xFF4ADE80 : 0xFFFFFFFF, false);
        Draw.round(g, cx - w2 / 2 - 3, y + 10, w2 + 6, 10, 0xAA0D0D0D);
        g.drawString(mc.font, line2, cx - w2 / 2, y + 11, 0xFFFFFFFF, false);

        if (showItems) {
            ItemStack main = le.getMainHandItem(), off = le.getOffhandItem();
            int ix = cx - 13;
            drawItem(g, main, ix, y + 22);
            drawItem(g, off, ix + 14, y + 22);
        }
    }

    private void drawItem(GuiGraphics g, ItemStack s, int x, int y) {
        if (s.isEmpty()) return;
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(x, y, 0);
        ps.scale(0.75f, 0.75f, 1f);
        g.renderItem(s, 0, 0);
        ps.popPose();
    }
}
