package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * ESP через ванильное свечение (контур виден сквозь стены).
 * В Forge 1.21.4 нет событий отрисовки, поэтому рисовать самим нельзя без Mixin.
 */
public class ESP extends Module {
    private static final int FLAG_GLOWING = 6;
    private static Method setSharedFlag;

    static {
        // ищем protected void setSharedFlag(int, boolean) без привязки к имени (имена зависят от маппингов)
        for (Method m : Entity.class.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (!Modifier.isStatic(m.getModifiers()) && m.getReturnType() == void.class
                    && p.length == 2 && p[0] == int.class && p[1] == boolean.class) {
                m.setAccessible(true);
                setSharedFlag = m;
                break;
            }
        }
    }

    private final BoolSetting players = new BoolSetting("Игроки", true);
    private final BoolSetting mobs = new BoolSetting("Мобы", false);
    private final NumSetting range = new NumSetting("Дальность", 128, 16, 256, 8);

    private final Set<Integer> glowing = new HashSet<>();

    public ESP() {
        super("ESP", "Render");
        settings.add(players);
        settings.add(mobs);
        settings.add(range);
    }

    private static void setGlow(Entity e, boolean on) {
        if (setSharedFlag == null) return;
        try {
            setSharedFlag.invoke(e, FLAG_GLOWING, on);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        Set<Integer> now = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStand) continue;
            boolean isPlayer = e instanceof Player;
            if (isPlayer && !players.value) continue;
            if (!isPlayer && !mobs.value) continue;
            if (mc.player.distanceTo(e) > range.value) continue;
            setGlow(e, true);
            now.add(e.getId());
        }

        // снимаем свечение с тех, кто перестал подходить (вышел из дальности, настройки изменились)
        for (Iterator<Integer> it = glowing.iterator(); it.hasNext(); ) {
            int id = it.next();
            if (!now.contains(id)) {
                Entity e = mc.level.getEntity(id);
                if (e != null) setGlow(e, false);
                it.remove();
            }
        }
        glowing.addAll(now);
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) {
            for (int id : glowing) {
                Entity e = mc.level.getEntity(id);
                if (e != null) setGlow(e, false);
            }
        }
        glowing.clear();
    }
}
