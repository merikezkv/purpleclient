package com.purple.client.module;

import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Combat;
import com.purple.client.util.TargetMarker;
import net.minecraft.client.Minecraft;

/** Отмечает цель, которую бьёт AttackAura / TriggerBot / игрок. */
public class TargetESP extends Module {
    private final ModeSetting mode = new ModeSetting("Режим", 1, TargetMarker.MODES);
    private final NumSetting radius = new NumSetting("Радиус", 0.5, 0.2, 1.5, 0.1);
    private final NumSetting count = new NumSetting("Частиц", 3, 1, 8, 1);

    private final TargetMarker marker = new TargetMarker();

    public TargetESP() {
        super("TargetESP", "Render");
        settings.add(mode);
        settings.add(radius);
        settings.add(count);
    }

    @Override
    public void onTick() {
        if (Minecraft.getInstance().level == null) return;
        marker.radius = radius.value;
        marker.count = (int) count.value;
        marker.update(Combat.get(), mode.index);
    }

    @Override
    public void onDisable() {
        marker.clear();
    }
}
