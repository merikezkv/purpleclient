package com.purple.client.util;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Переводит мировые координаты в экранные (для рисования в HUD-слое). */
public final class Projector {
    private final Vec3 cp;
    private final Vector3f look, up, left;
    private final double tan, aspect;
    private final int sw, sh;
    public double sx, sy;

    private Projector(Vec3 cp, Vector3f look, Vector3f up, Vector3f left, double tan, double aspect, int sw, int sh) {
        this.cp = cp; this.look = look; this.up = up; this.left = left;
        this.tan = tan; this.aspect = aspect; this.sw = sw; this.sh = sh;
    }

    public static Projector create(Minecraft mc) {
        Camera cam = mc.gameRenderer.getMainCamera();
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();

        double fov = mc.options.fov().get();
        LocalPlayer p = mc.player;
        if (p != null) {
            double f = 1.0;
            if (p.getAbilities().flying) f *= 1.1;
            double base = p.getAbilities().getWalkingSpeed();
            if (base > 0) f *= (p.getAttributeValue(Attributes.MOVEMENT_SPEED) / base + 1.0) / 2.0;
            if (p.isUsingItem() && p.getUseItem().is(Items.BOW)) {
                float t = Math.min(p.getTicksUsingItem() / 20f, 1f);
                f *= 1.0f - t * t * 0.15f;
            }
            if (!Double.isNaN(f) && f > 0.1) f = Mth.lerp(mc.options.fovEffectScale().get(), 1.0, f); else f = 1.0;
            fov *= f;
        }
        double tan = Math.tan(Math.toRadians(fov / 2.0));
        return new Projector(cam.getPosition(), cam.getLookVector(), cam.getUpVector(), cam.getLeftVector(),
                tan, (double) sw / sh, sw, sh);
    }

    /** @return false, если точка за спиной камеры. Результат в sx, sy. */
    public boolean project(double x, double y, double z) {
        double dx = x - cp.x, dy = y - cp.y, dz = z - cp.z;
        double f = dx * look.x + dy * look.y + dz * look.z;
        if (f < 0.1) return false;
        double lx = dx * left.x + dy * left.y + dz * left.z;
        double uy = dx * up.x + dy * up.y + dz * up.z;
        sx = sw / 2.0 - (lx / (f * tan * aspect)) * (sw / 2.0);
        sy = sh / 2.0 - (uy / (f * tan)) * (sh / 2.0);
        return true;
    }
}
