package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public class Sprint extends Module {
    private final BoolSetting keepOnHit = new BoolSetting("Сохр. при ударе", true);

    public Sprint() {
        super("Sprint", "Movement");
        settings.add(keepOnHit);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null) return;

        if (!mc.options.keyUp.isDown()) return;                 // только при движении вперёд
        if (p.isUsingItem() || p.isShiftKeyDown()) return;
        if (p.horizontalCollision) return;
        if (p.getFoodData().getFoodLevel() <= 6 && !p.getAbilities().mayfly) return;

        // если "сохранять при ударе" выключено, не возвращаем спринт, пока идёт взмах
        if (!keepOnHit.value && p.swinging) return;

        p.setSprinting(true);
    }
}
