package com.purple.client.util;

import com.purple.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * HUD через строку над хотбаром (action bar): в Forge 1.21.4 нет событий отрисовки,
 * поэтому рисовать свой HUD напрямую нельзя.
 */
public final class Overlay {
    private Overlay() {}

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;

        MutableComponent out = Component.empty();
        boolean any = false;

        MutableComponent hud = ModuleManager.hud.isEnabled() ? ModuleManager.hud.build(p) : null;
        if (hud != null) {
            out.append(hud);
            any = true;
        }
        Component gps = Gps.line(p);
        if (gps != null) {
            if (any) out.append(Component.literal(" §8| "));
            out.append(gps);
            any = true;
        }
        if (any) mc.gui.setOverlayMessage(out, false);
    }
}
