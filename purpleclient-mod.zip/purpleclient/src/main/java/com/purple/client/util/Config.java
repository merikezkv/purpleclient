package com.purple.client.util;

import com.purple.client.gui.Theme;
import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import net.minecraft.client.Minecraft;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/** Сохраняет цвет, друзей и бинды в файл purpleclient.properties в папке игры. */
public final class Config {
    private static boolean loaded;
    private Config() {}

    private static File file() {
        return new File(Minecraft.getInstance().gameDirectory, "purpleclient.properties");
    }

    public static void loadOnce() {
        if (loaded) return;
        loaded = true;
        try {
            File f = file();
            if (!f.exists()) return;
            Properties pr = new Properties();
            try (Reader r = new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8)) {
                pr.load(r);
            }
            String c = pr.getProperty("color");
            if (c != null) Theme.setRgb(Integer.parseInt(c, 16));
            String fr = pr.getProperty("friends");
            if (fr != null && !fr.isBlank()) for (String n : fr.split(",")) if (!n.isBlank()) Friends.add(n.trim());
            for (Module m : ModuleManager.MODULES) {
                String b = pr.getProperty("bind." + m.name);
                if (b != null) Commands.applyBind(m, b);
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Properties pr = new Properties();
            pr.setProperty("color", String.format("%06X", Theme.rgb));
            pr.setProperty("friends", String.join(",", Friends.list()));
            for (Module m : ModuleManager.MODULES) {
                if (m.bindKey != -1 && m.bindName != null) pr.setProperty("bind." + m.name, m.bindName);
            }
            try (Writer w = new OutputStreamWriter(new FileOutputStream(file()), StandardCharsets.UTF_8)) {
                pr.store(w, "Purple Client");
            }
        } catch (Exception ignored) {
        }
    }
}
