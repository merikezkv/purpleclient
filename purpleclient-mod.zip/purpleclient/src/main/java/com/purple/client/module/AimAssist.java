package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** Очень плавно подводит прицел к ближайшей к прицелу цели (ближний бой). */
public class AimAssist extends Module {
    private final NumSetting range = new NumSetting("Дальность", 4.5, 2, 8, 0.5);
    private final NumSetting fov = new NumSetting("FOV", 90, 10, 360, 10);
    private final NumSetting speed = new NumSetting("Плавность", 15, 1, 100, 1);
    private final NumSetting maxStep = new NumSetting("Макс. поворот", 6, 1, 30, 1);
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);
    private final BoolSetting onlyClick = new BoolSetting("Только при ЛКМ", true);
    private final BoolSetting vertical = new BoolSetting("Вертикаль", true);
    private final BoolSetting head = new BoolSetting("Голова", false);
    private final BoolSetting walls = new BoolSetting("Сквозь стены", false);

    public AimAssist() {
        super("AimAssist", "Combat");
        settings.add(range);
        settings.add(fov);
        settings.add(speed);
        settings.add(maxStep);
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
        settings.add(onlyClick);
        settings.add(vertical);
        settings.add(head);
        settings.add(walls);
    }

    private Vec3 aimPoint(LivingEntity e) {
        return head.value ? e.getEyePosition() : e.position().add(0, e.getBbHeight() * 0.6, 0);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) return;
        if (onlyClick.value && !mc.options.keyAttack.isDown()) return;

        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestAngle = fov.value / 2.0 + 0.001; // при 360 охватывает все стороны

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!Targets.valid(e, p, players.value, hostile.value, animals.value)) continue;
            if (p.distanceTo(e) > range.value) continue;
            if (!walls.value && !p.hasLineOfSight(e)) continue;

            LivingEntity le = (LivingEntity) e;
            Vec3 to = aimPoint(le).subtract(eye).normalize();
            double angle = Math.toDegrees(Math.acos(Mth.clamp(look.dot(to), -1.0, 1.0)));
            if (angle < bestAngle) {
                bestAngle = angle;
                best = le;
            }
        }
        if (best == null) return;

        Vec3 aim = aimPoint(best);
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

        float k = (float) speed.value / 100f;
        float max = (float) maxStep.value;
        p.setYRot(p.getYRot() + Aim.step(Mth.wrapDegrees(targetYaw - p.getYRot()), k, max));
        if (vertical.value) {
            p.setXRot(Mth.clamp(p.getXRot() + Aim.step(targetPitch - p.getXRot(), k, max), -90f, 90f));
        }
    }
}
