package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** Плавно подводит прицел к ближайшей цели (ближний бой). */
public class AimAssist extends Module {
    private final NumSetting range = new NumSetting("Дальность", 4.5, 2, 8, 0.5);
    private final NumSetting fov = new NumSetting("FOV", 60, 10, 180, 5);
    private final NumSetting speed = new NumSetting("Скорость", 25, 1, 100, 1);
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting mobs = new BoolSetting("Мобы", true);
    private final BoolSetting onlyClick = new BoolSetting("Только при ЛКМ", true);
    private final BoolSetting vertical = new BoolSetting("Вертикаль", true);
    private final BoolSetting head = new BoolSetting("Голова", false);
    private final BoolSetting walls = new BoolSetting("Сквозь стены", false);

    public AimAssist() {
        super("AimAssist", "Combat");
        settings.add(range);
        settings.add(fov);
        settings.add(speed);
        settings.add(players);
        settings.add(mobs);
        settings.add(onlyClick);
        settings.add(vertical);
        settings.add(head);
        settings.add(walls);
    }

    private Vec3 aimPoint(LivingEntity e) {
        return head.value ? e.getEyePosition() : e.position().add(0, e.getBbHeight() * 0.6, 0);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) return;
        if (onlyClick.value && !mc.options.keyAttack.isDown()) return;

        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestAngle = fov.value / 2.0;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!Targets.valid(e, p, players.value, mobs.value)) continue;
            if (p.distanceTo(e) > range.value) continue;
            if (!walls.value && !p.hasLineOfSight(e)) continue;

            LivingEntity le = (LivingEntity) e;
            Vec3 to = aimPoint(le).subtract(eye).normalize();
            double angle = Math.toDegrees(Math.acos(Mth.clamp(look.dot(to), -1.0, 1.0)));
            if (angle < bestAngle) {
                bestAngle = angle;
                best = le;
            }
        }
        if (best == null) return;

        Vec3 aim = aimPoint(best);
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

        float k = (float) speed.value / 100f;
        float dYaw = Mth.wrapDegrees(targetYaw - p.getYRot());
        p.setYRot(p.getYRot() + dYaw * k);

        if (vertical.value) {
            float dPitch = targetPitch - p.getXRot();
            p.setXRot(Mth.clamp(p.getXRot() + dPitch * k, -90f, 90f));
        }
    }
}
