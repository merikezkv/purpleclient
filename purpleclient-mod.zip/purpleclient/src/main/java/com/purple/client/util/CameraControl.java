package com.purple.client.util;

import com.purple.client.module.FreeLook;
import com.purple.client.module.ModuleManager;
import net.minecraft.client.Camera;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.EventPriority;

import java.lang.reflect.Method;
import java.util.function.Consumer;

/**
 * Управление камерой через ViewportEvent.ComputeCameraAngles (подключается динамически):
 * - FreeLook: свободная камера в третьем лице без столкновений с блоками;
 * - AttackAura (режим "Свободная"): камера смотрит на цель, а поворот игрока не меняется.
 */
public final class CameraControl {
    public static boolean registered;

    private static float auraYaw, auraPitch;
    private static long auraStamp = -100, rotStamp = -100;
    private static boolean freeInit;
    private static float fy, fp, lastY, lastP;
    private static Method mGetCamera, mGetYaw, mGetPitch, mSetYaw, mSetPitch, mPartial, mSetPos;

    private CameraControl() {}

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void register() {
        try {
            Class cls = Class.forName("net.minecraftforge.client.event.ViewportEvent$ComputeCameraAngles");
            Consumer c = CameraControl::onAngles;
            MinecraftForge.EVENT_BUS.addListener(EventPriority.NORMAL, false, cls, c);
            registered = true;
        } catch (Throwable t) {
            registered = false;
        }
    }

    /** Модули, которые меняют поворот игрока, сообщают об этом (чтобы FreeLook не принял это за мышь). */
    public static void markRotation() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) rotStamp = mc.level.getGameTime();
    }

    public static void setAura(float yaw, float pitch) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        auraYaw = yaw;
        auraPitch = pitch;
        auraStamp = mc.level.getGameTime();
    }

    private static void init(Class<?> evt) throws Exception {
        mGetCamera = evt.getMethod("getCamera");
        mGetYaw = evt.getMethod("getYaw");
        mGetPitch = evt.getMethod("getPitch");
        mSetYaw = evt.getMethod("setYaw", float.class);
        mSetPitch = evt.getMethod("setPitch", float.class);
        mPartial = evt.getMethod("getPartialTick");
        for (Method m : Camera.class.getDeclaredMethods()) {
            if (m.getParameterCount() == 1 && m.getParameterTypes()[0] == Vec3.class && m.getReturnType() == void.class) {
                m.setAccessible(true);
                mSetPos = m;
                break;
            }
        }
    }

    private static void onAngles(Object e) {
        try {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null) return;
            if (mGetCamera == null) init(e.getClass());

            long now = mc.level.getGameTime();
            CameraType type = mc.options.getCameraType();
            boolean third = !type.isFirstPerson();
            boolean front = type == CameraType.THIRD_PERSON_FRONT;
            FreeLook fl = ModuleManager.freeLook;

            float yaw = (Float) mGetYaw.invoke(e);
            float pitch = (Float) mGetPitch.invoke(e);
            boolean changed = false;

            if (fl.isEnabled() && third) {
                if (!freeInit) {
                    fy = p.getYRot(); fp = p.getXRot();
                    lastY = fy; lastP = fp;
                    freeInit = true;
                }
                if (now - rotStamp <= 1) {
                    lastY = p.getYRot();
                    lastP = p.getXRot();
                } else {
                    fy += Mth.wrapDegrees(p.getYRot() - lastY);
                    fp = Mth.clamp(fp + (p.getXRot() - lastP), -90f, 90f);
                    p.setYRot(lastY);
                    p.setXRot(lastP);
                    p.yRotO = lastY;
                    p.xRotO = lastP;
                }
                yaw = front ? fy + 180f : fy;
                pitch = front ? -fp : fp;
                changed = true;

                // камера без столкновений с блоками
                if (mSetPos != null) {
                    float pt = (float) ((Double) mPartial.invoke(e)).doubleValue();
                    Vec3 eye = p.getEyePosition(pt);
                    double yr = Math.toRadians(fy), pr = Math.toRadians(fp);
                    Vec3 look = new Vec3(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
                    double d = fl.distance();
                    Vec3 pos = front ? eye.add(look.scale(d)) : eye.subtract(look.scale(d));
                    mSetPos.invoke(mGetCamera.invoke(e), pos);
                }
            } else {
                freeInit = false;
            }

            if (now - auraStamp <= 1) {
                yaw = front ? auraYaw + 180f : auraYaw;
                pitch = front ? -auraPitch : auraPitch;
                changed = true;
            }

            if (changed) {
                mSetYaw.invoke(e, yaw);
                mSetPitch.invoke(e, pitch);
            }
        } catch (Throwable ignored) {
        }
    }
}
