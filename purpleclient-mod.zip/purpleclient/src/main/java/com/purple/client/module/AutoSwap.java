package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.util.Commands;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * Одноразовый свап предмета в левой руке по кругу: тотем -> яблоко -> щит -> шар.
 * Срабатывает при включении (клик в меню, .toggle AutoSwap или бинд: .bind add AutoSwap g)
 * и сразу выключается.
 */
public class AutoSwap extends Module {
    private final BoolSetting totem = new BoolSetting("Тотем", true);
    private final BoolSetting apple = new BoolSetting("Яблоко", true);
    private final BoolSetting shield = new BoolSetting("Щит", true);
    private final BoolSetting ball = new BoolSetting("Шар", true);
    private final ModeSetting ballType = new ModeSetting("Предмет шара", 0, "Огн. шар", "Снежок", "Эндер-жемчуг");
    private final BoolSetting messages = new BoolSetting("Сообщения", false);

    private record Kind(String name, Item[] items) {
        boolean matches(ItemStack s) {
            for (Item i : items) if (s.is(i)) return true;
            return false;
        }
    }

    public AutoSwap() {
        super("AutoSwap", "Player");
        settings.add(totem);
        settings.add(apple);
        settings.add(shield);
        settings.add(ball);
        settings.add(ballType);
        settings.add(messages);
    }

    private Item ballItem() {
        return switch (ballType.index) {
            case 1 -> Items.SNOWBALL;
            case 2 -> Items.ENDER_PEARL;
            default -> Items.FIRE_CHARGE;
        };
    }

    private static int findSlot(LocalPlayer p, Kind kind) {
        for (int i = 0; i < 9; i++) if (kind.matches(p.getInventory().getItem(i))) return 36 + i;
        for (int i = 9; i < 36; i++) if (kind.matches(p.getInventory().getItem(i))) return i;
        return -1;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        try {
            if (p == null || mc.gameMode == null || mc.screen != null || p.containerMenu != p.inventoryMenu) return;

            List<Kind> kinds = new ArrayList<>();
            if (totem.value) kinds.add(new Kind("Тотем", new Item[]{Items.TOTEM_OF_UNDYING}));
            if (apple.value) kinds.add(new Kind("Яблоко", new Item[]{Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE}));
            if (shield.value) kinds.add(new Kind("Щит", new Item[]{Items.SHIELD}));
            if (ball.value) kinds.add(new Kind("Шар", new Item[]{ballItem()}));
            if (kinds.isEmpty()) return;

            int n = kinds.size();
            int cur = -1;
            for (int i = 0; i < n; i++) {
                if (kinds.get(i).matches(p.getOffhandItem())) { cur = i; break; }
            }

            for (int j = 1; j <= n; j++) {
                int idx = Math.floorMod(cur + j, n);
                if (idx == cur) continue;
                Kind k = kinds.get(idx);
                int slot = findSlot(p, k);
                if (slot == -1) continue;
                mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
                if (messages.value) Commands.msg("AutoSwap: " + k.name());
                return;
            }
            if (messages.value) Commands.msg("AutoSwap: нет подходящих предметов");
        } finally {
            toggle(); // одноразовое срабатывание
        }
    }
}
