package com.purple.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.LivingEntity;

/** Отмечает цель: кольцо / спираль из частиц и/или ванильное свечение. */
public final class TargetMarker {
    public static final String[] MODES = {"Выкл", "Кольцо", "Спираль", "Свечение", "Кольцо+Свечение"};

    public double radius = 0.5;
    public int count = 3;
    private LivingEntity glowing;

    public void update(LivingEntity t, int mode) {
        Minecraft mc = Minecraft.getInstance();
        boolean glow = mode == 3 || mode == 4;
        if (glowing != null && (glowing != t || !glow)) {
            GlowUtil.set(glowing, false);
            glowing = null;
        }
        if (t == null || mc.level == null || mode == 0) return;

        if (glow) {
            GlowUtil.set(t, true);
            glowing = t;
        }

        double time = mc.level.getGameTime();
        double r = t.getBbWidth() * 0.5 + radius;
        if (mode == 1 || mode == 4) {
            double base = time / 20.0 * 2 * Math.PI;
            double h = (Math.sin(time / 8.0) + 1) / 2 * t.getBbHeight();
            for (int i = 0; i < count; i++) {
                double a = base + i * 2 * Math.PI / count;
                mc.level.addParticle(ParticleTypes.WITCH,
                        t.getX() + Math.cos(a) * r, t.getY() + h, t.getZ() + Math.sin(a) * r, 0, 0, 0);
            }
        } else if (mode == 2) {
            int n = count * 2;
            double base = time / 15.0 * 2 * Math.PI;
            for (int i = 0; i < n; i++) {
                double frac = i / (double) n;
                double a = base + frac * 2 * Math.PI * 1.5;
                double h = (((time / 20.0) % 1.0) + frac) % 1.0 * t.getBbHeight();
                mc.level.addParticle(ParticleTypes.WITCH,
                        t.getX() + Math.cos(a) * r, t.getY() + h, t.getZ() + Math.sin(a) * r, 0, 0, 0);
            }
        }
    }

    public void clear() {
        if (glowing != null) {
            GlowUtil.set(glowing, false);
            glowing = null;
        }
    }
}
