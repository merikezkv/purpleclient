package com.purple.client.module;

import net.minecraft.util.Mth;

final class Aim {
    private Aim() {}

    /** Плавный шаг к цели: замедляется при приближении и ограничен максимумом за тик. */
    static float step(float delta, float k, float maxStep) {
        float a = Math.abs(delta);
        if (a < 0.25f) return delta;
        float ease = 0.4f + 0.6f * Math.min(1f, a / 15f);
        return Mth.clamp(delta * k * ease, -maxStep, maxStep);
    }
}
