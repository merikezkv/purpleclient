package com.purple.client.gui;

import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.setting.Setting;
import com.purple.client.util.Config;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/** Крошечное окно: вкладки в шапке, слева модули, справа настройки, у края полоса выбора цвета. */
public class ClickGuiScreen extends Screen {
    private static final int HEAD = 13, BODY = 96, MW = 64, SPW = 96, STRIP = 18, ROW = 11, NROW = 16;
    private static final int WIDTH = MW + SPW + STRIP, TOTAL = HEAD + BODY, HUE_H = 88;
    private static final int[] PRESETS = {
            0x9D4EDD, 0x4C8DFF, 0x2EC4B6, 0x4ADE80, 0xFACC15, 0xFB923C, 0xF43F5E, 0xFFFFFF
    };
    private static final int BG = 0xE00D0D0D, SEL = 0xFF1A1A1A, TRACK = 0xFF2C2C2C;
    private static final int TXT = 0xFFEAEAEA, DIM = 0xFF8A8A8A, LINE = 0xFF212121;

    private static int wx = 14, wy = 8, scroll;
    private static String selCat;
    private static Module selMod;

    private static final int T_CLOSE = 0, T_TITLE = 1, T_TAB = 2, T_TOGGLE = 3, T_SELECT = 4, T_SET = 5;

    private record Hit(int x, int y, int w, int h, int type, String cat, Module module, Setting setting) {
        boolean contains(double mx, double my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private boolean dragWin, hueDrag, sbDrag, colorChanged;
    private int dragDX, dragDY;
    private Hit slider;

    public ClickGuiScreen() {
        super(Component.literal("ClickGUI"));
        if (selCat == null) {
            selCat = cats().get(0);
            selMod = modsOf(selCat).get(0);
        }
    }

    @Override public boolean isPauseScreen() { return false; }

    // ---------- данные ----------
    private static List<String> cats() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        for (Module m : ModuleManager.MODULES) s.add(m.category);
        return new ArrayList<>(s);
    }

    private static List<Module> modsOf(String cat) {
        List<Module> l = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) if (m.category.equals(cat)) l.add(m);
        return l;
    }

    private static String tabName(String c) {
        return switch (c) {
            case "Combat" -> "Бой";
            case "Movement" -> "Ход";
            case "Render" -> "Вид";
            case "Player" -> "Игрок";
            case "Misc" -> "Проч";
            default -> c;
        };
    }

    private static int rowH(Setting s) { return s instanceof NumSetting ? NROW : ROW; }

    private static int contentH(Module m) {
        int h = 0;
        if (m != null) for (Setting s : m.settings) h += rowH(s);
        return h;
    }

    // ---------- геометрия ----------
    private int viewTop() { return wy + HEAD + 2; }
    private int viewH() { return BODY - 4; }
    private int setX() { return wx + MW; }
    private int stripX() { return wx + MW + SPW; }
    private int maxScroll() { return Math.max(0, contentH(selMod) - viewH()); }
    private int swY(int i) { return wy + HEAD + 3 + i * 11; }
    private int hueTop() { return wy + HEAD + 3; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        wx = Mth.clamp(wx, 0, Math.max(0, width - WIDTH));
        wy = Mth.clamp(wy, 0, Math.max(0, height - TOTAL));
        scroll = Mth.clamp(scroll, 0, maxScroll());
        int accent = Theme.accent();
        hits.clear();

        g.fill(0, 0, width, height, 0x44000000);
        g.fill(wx, wy, wx + WIDTH, wy + TOTAL, BG);
        g.fill(wx, wy, wx + WIDTH, wy + 1, accent);
        g.fill(wx, wy + HEAD - 1, wx + WIDTH, wy + HEAD, LINE);
        hits.add(new Hit(wx, wy, WIDTH, HEAD, T_TITLE, null, null, null));

        // вкладки в шапке
        int tx = wx + 3;
        for (String c : cats()) {
            String label = tabName(c);
            int w = font.width(label) + 8;
            boolean sel = c.equals(selCat);
            g.drawString(font, label, tx + 4, wy + 3, sel ? accent : DIM, false);
            if (sel) g.fill(tx + 3, wy + HEAD - 2, tx + w - 3, wy + HEAD - 1, accent);
            hits.add(new Hit(tx, wy, w, HEAD - 1, T_TAB, c, null, null));
            tx += w;
        }
        boolean hc = mx >= wx + WIDTH - 12 && mx <= wx + WIDTH && my >= wy && my <= wy + HEAD;
        g.drawString(font, "x", wx + WIDTH - 9, wy + 3, hc ? accent : DIM, false);
        hits.add(new Hit(wx + WIDTH - 12, wy, 12, HEAD, T_CLOSE, null, null, null));

        g.fill(wx + MW, wy + HEAD, wx + MW + 1, wy + TOTAL, LINE);
        g.fill(stripX(), wy + HEAD, stripX() + 1, wy + TOTAL, LINE);

        // модули
        int my0 = wy + HEAD + 2;
        for (Module m : modsOf(selCat)) {
            if (m == selMod) g.fill(wx + 1, my0, wx + MW, my0 + ROW + 1, SEL);
            g.fill(wx + 4, my0 + 3, wx + 9, my0 + 8, m.isEnabled() ? accent : TRACK);
            g.drawString(font, m.name, wx + 13, my0 + 2, m.isEnabled() ? accent : (m == selMod ? TXT : DIM), false);
            hits.add(new Hit(wx, my0, 12, ROW + 1, T_TOGGLE, null, m, null));
            hits.add(new Hit(wx + 12, my0, MW - 12, ROW + 1, T_SELECT, null, m, null));
            my0 += ROW + 1;
        }

        // настройки выбранного модуля
        int sx = setX(), vt = viewTop(), vb = vt + viewH();
        g.enableScissor(sx + 1, vt, sx + SPW, vb);
        int sy = vt - scroll;
        if (selMod != null) {
            for (Setting s : selMod.settings) {
                if (s instanceof BoolSetting b) {
                    g.drawString(font, b.name, sx + 5, sy + 2, b.value ? TXT : DIM, false);
                    g.fill(sx + SPW - 14, sy + 3, sx + SPW - 9, sy + 8, b.value ? accent : TRACK);
                } else if (s instanceof NumSetting n) {
                    String v = trim(n.value);
                    g.drawString(font, n.name, sx + 5, sy + 1, DIM, false);
                    g.drawString(font, v, sx + SPW - 8 - font.width(v), sy + 1, TXT, false);
                    int tw = SPW - 16;
                    double frac = (n.value - n.min) / (n.max - n.min);
                    g.fill(sx + 5, sy + 11, sx + 5 + tw, sy + 13, TRACK);
                    g.fill(sx + 5, sy + 11, sx + 5 + (int) (tw * frac), sy + 13, accent);
                } else if (s instanceof ModeSetting m) {
                    g.drawString(font, m.name, sx + 5, sy + 2, DIM, false);
                    String v = m.get();
                    g.drawString(font, v, sx + SPW - 8 - font.width(v), sy + 2, accent, false);
                }
                hits.add(new Hit(sx, sy, SPW - 6, rowH(s), T_SET, null, selMod, s));
                sy += rowH(s);
            }
        }
        g.disableScissor();

        if (maxScroll() > 0) {
            int trackX = sx + SPW - 4;
            g.fill(trackX, vt, trackX + 2, vb, TRACK);
            int th = Math.max(8, viewH() * viewH() / contentH(selMod));
            int thumbY = vt + (int) ((viewH() - th) * (scroll / (double) maxScroll()));
            g.fill(trackX, thumbY, trackX + 2, thumbY + th, accent);
        }

        // цвет клиента: пресеты и вертикальная полоса оттенков
        for (int i = 0; i < PRESETS.length; i++) {
            int x = stripX() + 2, y = swY(i);
            g.fill(x, y, x + 8, y + 8, 0xFF000000 | PRESETS[i]);
            if ((PRESETS[i] & 0xFFFFFF) == Theme.rgb) {
                g.fill(x - 1, y - 1, x + 9, y, 0xFFFFFFFF);
                g.fill(x - 1, y + 8, x + 9, y + 9, 0xFFFFFFFF);
                g.fill(x - 1, y, x, y + 8, 0xFFFFFFFF);
                g.fill(x + 8, y, x + 9, y + 8, 0xFFFFFFFF);
            }
        }
        int hx = stripX() + 12;
        for (int i = 0; i < HUE_H; i++) {
            g.fill(hx, hueTop() + i, hx + 5, hueTop() + i + 1,
                    0xFF000000 | (Mth.hsvToRgb(i / (float) HUE_H, 0.7f, 1f) & 0xFFFFFF));
        }
        int my1 = hueTop() + (int) (Theme.hue * (HUE_H - 1));
        g.fill(hx - 1, my1, hx + 6, my1 + 1, 0xFFFFFFFF);
    }

    private static String trim(double v) {
        return v == Math.rint(v) ? String.valueOf((int) v) : String.format("%.1f", v);
    }

    private void setHueFrom(double my) {
        Theme.setHue((float) ((my - hueTop()) / (double) (HUE_H - 1)));
    }

    private void setScrollFrom(double my) {
        double frac = Mth.clamp((my - viewTop()) / (double) viewH(), 0.0, 1.0);
        scroll = (int) (frac * maxScroll());
    }

    private void updateSlider(double mx) {
        NumSetting n = (NumSetting) slider.setting();
        int tx = slider.x() + 5, tw = SPW - 16;
        double frac = Mth.clamp((mx - tx) / tw, 0.0, 1.0);
        n.set(n.min + frac * (n.max - n.min));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // цвет клиента
        for (int i = 0; i < PRESETS.length; i++) {
            int x = stripX() + 2, y = swY(i);
            if (mx >= x && mx <= x + 8 && my >= y && my <= y + 8) {
                Theme.setRgb(PRESETS[i]);
                colorChanged = true;
                return true;
            }
        }
        if (mx >= stripX() + 10 && mx <= stripX() + STRIP && my >= hueTop() - 1 && my <= hueTop() + HUE_H + 1) {
            hueDrag = true;
            colorChanged = true;
            setHueFrom(my);
            return true;
        }
        // полоса прокрутки
        if (maxScroll() > 0 && mx >= setX() + SPW - 9 && mx <= setX() + SPW
                && my >= viewTop() && my <= viewTop() + viewH()) {
            sbDrag = true;
            setScrollFrom(my);
            return true;
        }

        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            switch (h.type()) {
                case T_CLOSE -> { onClose(); return true; }
                case T_TITLE -> {
                    dragWin = true;
                    dragDX = (int) mx - wx;
                    dragDY = (int) my - wy;
                    return true;
                }
                case T_TAB -> {
                    selCat = h.cat();
                    selMod = modsOf(selCat).get(0);
                    scroll = 0;
                    return true;
                }
                case T_TOGGLE -> { h.module().toggle(); return true; }
                case T_SELECT -> {
                    selMod = h.module();
                    scroll = 0;
                    return true;
                }
                case T_SET -> {
                    if (my < viewTop() || my > viewTop() + viewH()) continue;
                    if (h.setting() instanceof BoolSetting b) {
                        b.value = !b.value;
                    } else if (h.setting() instanceof ModeSetting m) {
                        m.next();
                    } else if (h.setting() instanceof NumSetting) {
                        slider = h;
                        updateSlider(mx);
                    }
                    return true;
                }
                default -> { }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (hueDrag) { setHueFrom(my); return true; }
        if (sbDrag) { setScrollFrom(my); return true; }
        if (dragWin) {
            wx = (int) mx - dragDX;
            wy = (int) my - dragDY;
            return true;
        }
        if (slider != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (colorChanged) {
            Config.save();
            colorChanged = false;
        }
        dragWin = false;
        hueDrag = false;
        sbDrag = false;
        slider = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (mx >= setX() && mx <= setX() + SPW && my >= viewTop() && my <= viewTop() + viewH()) {
            scroll = Mth.clamp(scroll - (int) (scrollY * 12), 0, maxScroll());
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_Y) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
