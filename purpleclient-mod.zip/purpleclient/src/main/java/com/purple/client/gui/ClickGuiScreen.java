package com.purple.client.gui;

import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.setting.Setting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/** Минималистичный ClickGUI с выбором цвета клиента сбоку. */
public class ClickGuiScreen extends Screen {
    private static final int W = 120, ROW = 18, HEAD = 20;
    private static final int HEAD_BG = 0xE0101010, BG = 0xD0121212, BG_HOVER = 0xD01C1C1C, BG_SET = 0xD00C0C0C;
    private static final int TXT = 0xFFEDEDED, TXT_DIM = 0xFF9A9A9A, TRACK = 0xFF2B2B2B;

    // боковая панель выбора цвета
    private static final int PW = 100, SW = 18, GAP = 4, HUE_H = 12;
    private static final int[] PRESETS = {
            0x9D4EDD, 0x4C8DFF, 0x2EC4B6, 0x4ADE80, 0xFACC15, 0xFB923C, 0xF43F5E, 0xFFFFFF
    };

    private static class Panel {
        final String category;
        int x, y;
        Panel(String c, int x, int y) { this.category = c; this.x = x; this.y = y; }
    }

    private record Hit(int x, int y, int w, int h, Panel panel, Module module, Setting setting) {
        boolean contains(double mx, double my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    private static final List<Panel> PANELS = new ArrayList<>();
    private static final Set<Module> EXPANDED = new HashSet<>();

    private final List<Hit> hits = new ArrayList<>();
    private Panel dragPanel;
    private int dragDX, dragDY;
    private Hit slider;
    private boolean hueDrag;

    public ClickGuiScreen() {
        super(Component.literal("ClickGUI"));
        if (PANELS.isEmpty()) {
            int x = 8;
            LinkedHashSet<String> cats = new LinkedHashSet<>();
            for (Module m : ModuleManager.MODULES) cats.add(m.category);
            for (String c : cats) { PANELS.add(new Panel(c, x, 10)); x += W + 8; }
        }
    }

    @Override public boolean isPauseScreen() { return false; }

    // ---------- геометрия боковой панели ----------
    private int pickX() { return width - PW - 8; }
    private int pickY() { return 10; }
    private int swatchX(int i) { return pickX() + 6 + (i % 4) * (SW + GAP); }
    private int swatchY(int i) { return pickY() + HEAD + 6 + (i / 4) * (SW + GAP); }
    private int hueX() { return pickX() + 6; }
    private int hueY() { return pickY() + HEAD + 6 + 2 * (SW + GAP) + 2; }
    private int hueW() { return PW - 12; }
    private int closeX() { return width - 64; }
    private int closeY() { return height - 22; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        int accent = Theme.accent();
        g.fill(0, 0, width, height, 0x66000000);
        hits.clear();

        for (Panel p : PANELS) {
            int y = p.y;
            g.fill(p.x, y, p.x + W, y + HEAD, HEAD_BG);
            g.fill(p.x, y + HEAD - 1, p.x + W, y + HEAD, accent);
            g.drawString(font, p.category, p.x + 8, y + 6, TXT, false);
            hits.add(new Hit(p.x, y, W, HEAD, p, null, null));
            y += HEAD;

            for (Module m : ModuleManager.MODULES) {
                if (!m.category.equals(p.category)) continue;
                boolean hover = mx >= p.x && mx <= p.x + W && my >= y && my < y + ROW;
                g.fill(p.x, y, p.x + W, y + ROW, hover ? BG_HOVER : BG);
                if (m.isEnabled()) g.fill(p.x, y, p.x + 2, y + ROW, accent);
                g.drawString(font, m.name, p.x + 8, y + 5, m.isEnabled() ? accent : TXT_DIM, false);
                if (!m.settings.isEmpty()) {
                    g.drawString(font, EXPANDED.contains(m) ? "-" : "+", p.x + W - 12, y + 5, TXT_DIM, false);
                }
                hits.add(new Hit(p.x, y, W, ROW, p, m, null));
                y += ROW;

                if (EXPANDED.contains(m)) {
                    for (Setting s : m.settings) {
                        g.fill(p.x, y, p.x + W, y + ROW, BG_SET);
                        if (s instanceof BoolSetting b) {
                            g.drawString(font, b.name, p.x + 8, y + 5, TXT_DIM, false);
                            g.fill(p.x + W - 16, y + 5, p.x + W - 8, y + 13, b.value ? accent : TRACK);
                        } else if (s instanceof NumSetting n) {
                            String v = trim(n.value);
                            g.drawString(font, n.name, p.x + 8, y + 3, TXT_DIM, false);
                            g.drawString(font, v, p.x + W - 8 - font.width(v), y + 3, TXT, false);
                            int tx = p.x + 8, tw = W - 16;
                            double frac = (n.value - n.min) / (n.max - n.min);
                            g.fill(tx, y + ROW - 5, tx + tw, y + ROW - 3, TRACK);
                            g.fill(tx, y + ROW - 5, tx + (int) (tw * frac), y + ROW - 3, accent);
                        }
                        hits.add(new Hit(p.x, y, W, ROW, p, m, s));
                        y += ROW;
                    }
                }
            }
        }

        renderPicker(g, accent);

        boolean hc = mx >= closeX() && mx <= closeX() + 56 && my >= closeY() && my <= closeY() + 18;
        g.drawString(font, "Закрыть", closeX() + 8, closeY() + 5, hc ? accent : TXT_DIM, false);
    }

    private void renderPicker(GuiGraphics g, int accent) {
        int x = pickX(), y = pickY();
        int bottom = hueY() + HUE_H + 8;
        g.fill(x, y, x + PW, y + HEAD, HEAD_BG);
        g.fill(x, y + HEAD - 1, x + PW, y + HEAD, accent);
        g.drawString(font, "Цвет", x + 8, y + 6, TXT, false);
        g.fill(x, y + HEAD, x + PW, bottom, BG);

        for (int i = 0; i < PRESETS.length; i++) {
            int sx = swatchX(i), sy = swatchY(i);
            g.fill(sx, sy, sx + SW, sy + SW, 0xFF000000 | PRESETS[i]);
            if ((PRESETS[i] & 0xFFFFFF) == Theme.rgb) { // рамка у выбранного
                g.fill(sx - 1, sy - 1, sx + SW + 1, sy, 0xFFFFFFFF);
                g.fill(sx - 1, sy + SW, sx + SW + 1, sy + SW + 1, 0xFFFFFFFF);
                g.fill(sx - 1, sy, sx, sy + SW, 0xFFFFFFFF);
                g.fill(sx + SW, sy, sx + SW + 1, sy + SW, 0xFFFFFFFF);
            }
        }

        int hx = hueX(), hy = hueY(), hw = hueW();
        for (int i = 0; i < hw; i++) {
            g.fill(hx + i, hy, hx + i + 1, hy + HUE_H, 0xFF000000 | (Mth.hsvToRgb(i / (float) hw, 0.7f, 1f) & 0xFFFFFF));
        }
        int mxk = hx + (int) (Theme.hue * (hw - 1));
        g.fill(mxk - 1, hy - 2, mxk + 1, hy + HUE_H + 2, 0xFFFFFFFF);
    }

    private static String trim(double v) {
        return v == Math.rint(v) ? String.valueOf((int) v) : String.format("%.1f", v);
    }

    private void setHueFrom(double mx) {
        Theme.setHue((float) ((mx - hueX()) / (double) (hueW() - 1)));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // закрыть
        if (mx >= closeX() && mx <= closeX() + 56 && my >= closeY() && my <= closeY() + 18) {
            onClose();
            return true;
        }
        // выбор цвета
        for (int i = 0; i < PRESETS.length; i++) {
            if (mx >= swatchX(i) && mx <= swatchX(i) + SW && my >= swatchY(i) && my <= swatchY(i) + SW) {
                Theme.setRgb(PRESETS[i]);
                return true;
            }
        }
        if (mx >= hueX() && mx <= hueX() + hueW() && my >= hueY() - 2 && my <= hueY() + HUE_H + 2) {
            hueDrag = true;
            setHueFrom(mx);
            return true;
        }

        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;

            if (h.setting() instanceof BoolSetting b) {
                if (button == 0) b.value = !b.value;
            } else if (h.setting() instanceof NumSetting) {
                slider = h;
                updateSlider(mx);
            } else if (h.module() != null) {
                boolean arrow = mx >= h.x() + W - 30;
                if (button == 1 || (button == 0 && arrow)) {
                    if (!EXPANDED.remove(h.module())) EXPANDED.add(h.module());
                } else if (button == 0) {
                    h.module().toggle();
                }
            } else {
                dragPanel = h.panel();
                dragDX = (int) mx - h.panel().x;
                dragDY = (int) my - h.panel().y;
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (hueDrag) { setHueFrom(mx); return true; }
        if (dragPanel != null) {
            dragPanel.x = (int) mx - dragDX;
            dragPanel.y = (int) my - dragDY;
            return true;
        }
        if (slider != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragPanel = null;
        slider = null;
        hueDrag = false;
        return super.mouseReleased(mx, my, button);
    }

    private void updateSlider(double mx) {
        NumSetting n = (NumSetting) slider.setting();
        int tx = slider.x() + 8, tw = W - 16;
        double frac = Math.max(0, Math.min(1, (mx - tx) / tw));
        n.set(n.min + frac * (n.max - n.min));
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_Y) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
