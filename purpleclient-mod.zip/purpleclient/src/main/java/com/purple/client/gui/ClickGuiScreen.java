package com.purple.client.gui;

import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.KeySetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.setting.Setting;
import com.purple.client.util.Config;
import com.purple.client.util.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Окно в стиле современных читов: слева сайдбар с категориями, справа карточки модулей
 * с переключателями и раскрывающимися настройками, внизу выбор цвета клиента.
 */
public class ClickGuiScreen extends Screen {
    private static final int W = 340, H = 214, SBW = 84, HEAD = 22, FOOT = 24;
    private static final int[] PRESETS = {
            0x9D4EDD, 0x4C8DFF, 0x2EC4B6, 0x4ADE80, 0xFACC15, 0xFB923C, 0xF43F5E, 0xFFFFFF
    };
    private static final int BG = 0xF00F0F13, SIDE = 0xF0131318, CARD = 0xFF18181E, CARD2 = 0xFF1D1D25;
    private static final int TRACK = 0xFF2A2A33, TXT = 0xFFECECF2, DIM = 0xFF8B8B99, LINE = 0xFF24242C;

    private static int wx = Integer.MIN_VALUE, wy;
    private static int scroll;
    private static String selCat;
    private static final Set<Module> EXPANDED = new HashSet<>();

    private static final int T_TITLE = 0, T_CLOSE = 1, T_CAT = 2, T_ARROW = 3, T_TOGGLE = 4, T_SET = 5;

    private record Hit(int x, int y, int w, int h, int type, String cat, Module module, Setting setting) {
        boolean contains(double mx, double my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private boolean dragWin, hueDrag, sbDrag, colorChanged;
    private int dragDX, dragDY;
    private Hit slider;
    private KeySetting listening;

    public ClickGuiScreen() {
        super(Component.literal("ClickGUI"));
        if (selCat == null) selCat = cats().get(0);
    }

    @Override public boolean isPauseScreen() { return false; }

    // ---------- данные ----------
    private static List<String> cats() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        for (Module m : ModuleManager.MODULES) s.add(m.category);
        return new ArrayList<>(s);
    }

    private static List<Module> modsOf(String cat) {
        List<Module> l = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) if (m.category.equals(cat)) l.add(m);
        return l;
    }

    private static String catName(String c) {
        return switch (c) {
            case "Combat" -> "Бой";
            case "Movement" -> "Движение";
            case "Render" -> "Визуалы";
            case "Player" -> "Игрок";
            case "Misc" -> "Прочее";
            default -> c;
        };
    }

    private static int rowH(Setting s) { return s instanceof NumSetting ? 22 : 16; }

    private static int settingsH(Module m) {
        int h = 0;
        for (Setting s : m.settings) h += rowH(s);
        return h;
    }

    private static int cardH(Module m) {
        return 20 + (EXPANDED.contains(m) ? settingsH(m) + 4 : 0);
    }

    private static int contentH(String cat) {
        int h = 0;
        for (Module m : modsOf(cat)) h += cardH(m) + 4;
        return h;
    }

    // ---------- геометрия ----------
    private int x0() { return wx + SBW + 8; }
    private int cw() { return W - SBW - 22; }
    private int viewTop() { return wy + HEAD + 2; }
    private int viewBottom() { return wy + H - FOOT - 2; }
    private int viewH() { return viewBottom() - viewTop(); }
    private int maxScroll() { return Math.max(0, contentH(selCat) - viewH()); }
    private int footY() { return wy + H - FOOT; }
    private int swX(int i) { return x0() + 52 + i * 12; }
    private int hueX() { return x0() + 52 + 8 * 12 + 6; }
    private int hueW() { return 74; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        if (wx == Integer.MIN_VALUE) {
            wx = (width - W) / 2;
            wy = (height - H) / 2;
        }
        wx = Mth.clamp(wx, 0, Math.max(0, width - W));
        wy = Mth.clamp(wy, 0, Math.max(0, height - H));
        scroll = Mth.clamp(scroll, 0, maxScroll());
        int accent = Theme.accent();
        hits.clear();

        g.fill(0, 0, width, height, 0x66000000);
        Draw.round(g, wx, wy, W, H, BG);
        g.fill(wx + 1, wy + 3, wx + SBW, wy + H - 3, SIDE);
        g.fill(wx + SBW, wy + 3, wx + SBW + 1, wy + H - 3, LINE);

        // сайдбар
        g.drawString(font, "PURPLE", wx + 12, wy + 9, accent, false);
        g.drawString(font, "client", wx + 12, wy + 19, DIM, false);
        hits.add(new Hit(wx, wy, SBW, 34, T_TITLE, null, null, null));
        int cy = wy + 40;
        for (String c : cats()) {
            boolean sel = c.equals(selCat);
            if (sel) {
                Draw.round(g, wx + 6, cy, SBW - 12, 20, Draw.alpha(Theme.rgb, 0x38));
                g.fill(wx + 6, cy + 4, wx + 8, cy + 16, accent);
            }
            g.fill(wx + 15, cy + 7, wx + 21, cy + 13, sel ? accent : TRACK);
            g.drawString(font, catName(c), wx + 27, cy + 6, sel ? TXT : DIM, false);
            hits.add(new Hit(wx + 4, cy, SBW - 8, 20, T_CAT, c, null, null));
            cy += 24;
        }

        // шапка контента
        g.drawString(font, catName(selCat), x0() + 2, wy + 8, TXT, false);
        boolean hc = mx >= wx + W - 18 && mx <= wx + W - 4 && my >= wy + 3 && my <= wy + 17;
        g.drawString(font, "x", wx + W - 14, wy + 8, hc ? accent : DIM, false);
        hits.add(new Hit(wx + SBW, wy, W - SBW - 20, HEAD, T_TITLE, null, null, null));
        hits.add(new Hit(wx + W - 18, wy + 3, 14, 14, T_CLOSE, null, null, null));
        g.fill(wx + SBW + 8, wy + HEAD - 1, wx + W - 8, wy + HEAD, LINE);

        // карточки модулей
        int top = viewTop(), bottom = viewBottom();
        g.enableScissor(wx + SBW + 1, top, wx + W - 1, bottom);
        int y = top - scroll;
        int x = x0(), w = cw();
        for (Module m : modsOf(selCat)) {
            boolean open = EXPANDED.contains(m);
            int ch = cardH(m);
            Draw.round(g, x, y, w, ch, open ? CARD2 : CARD);
            if (m.isEnabled()) g.fill(x, y + 5, x + 2, y + 15, accent);
            if (!m.settings.isEmpty()) g.drawString(font, open ? "v" : ">", x + 7, y + 6, DIM, false);
            g.drawString(font, m.name, x + 18, y + 6, m.isEnabled() ? TXT : DIM, false);
            drawSwitch(g, x + w - 26, y + 6, 18, 9, m.isEnabled(), accent);
            hits.add(new Hit(x, y, 16, 20, T_ARROW, null, m, null));
            hits.add(new Hit(x + 16, y, w - 16, 20, T_TOGGLE, null, m, null));

            if (open) {
                int sy = y + 22;
                for (Setting s : m.settings) {
                    int rh = rowH(s);
                    int lx = x + 10, rx = x + w - 10;
                    if (s instanceof BoolSetting b) {
                        g.drawString(font, b.name, lx, sy + 4, b.value ? TXT : DIM, false);
                        drawSwitch(g, rx - 14, sy + 4, 14, 8, b.value, accent);
                    } else if (s instanceof NumSetting n) {
                        String v = trim(n.value);
                        g.drawString(font, n.name, lx, sy + 2, DIM, false);
                        g.drawString(font, v, rx - font.width(v), sy + 2, TXT, false);
                        double frac = (n.value - n.min) / (n.max - n.min);
                        int tw = rx - lx;
                        g.fill(lx, sy + 14, lx + tw, sy + 16, TRACK);
                        g.fill(lx, sy + 14, lx + (int) (tw * frac), sy + 16, accent);
                        int kx = lx + (int) (tw * frac);
                        g.fill(kx - 1, sy + 12, kx + 2, sy + 18, 0xFFFFFFFF);
                    } else if (s instanceof ModeSetting ms) {
                        g.drawString(font, ms.name, lx, sy + 4, DIM, false);
                        String v = ms.get();
                        int pw = font.width(v) + 8;
                        Draw.round(g, rx - pw, sy + 2, pw, 12, Draw.alpha(Theme.rgb, 0x40));
                        g.drawString(font, v, rx - pw + 4, sy + 4, accent, false);
                    } else if (s instanceof KeySetting ks) {
                        g.drawString(font, ks.name, lx, sy + 4, DIM, false);
                        String v = ks == listening ? "..." : ks.display();
                        int pw = font.width(v) + 8;
                        Draw.round(g, rx - pw, sy + 2, pw, 12, ks == listening ? Draw.alpha(Theme.rgb, 0x80) : TRACK);
                        g.drawString(font, v, rx - pw + 4, sy + 4, TXT, false);
                    }
                    hits.add(new Hit(x + 4, sy, w - 8, rh, T_SET, null, m, s));
                    sy += rh;
                }
            }
            y += ch + 4;
        }
        g.disableScissor();

        // полоса прокрутки
        if (maxScroll() > 0) {
            int sx = wx + W - 8;
            g.fill(sx, top, sx + 3, bottom, TRACK);
            int th = Math.max(10, viewH() * viewH() / contentH(selCat));
            int ty = top + (int) ((viewH() - th) * (scroll / (double) maxScroll()));
            g.fill(sx, ty, sx + 3, ty + th, accent);
        }

        // подвал: цвет клиента
        g.fill(wx + SBW + 8, footY(), wx + W - 8, footY() + 1, LINE);
        g.drawString(font, "Цвет", x0() + 2, footY() + 9, DIM, false);
        for (int i = 0; i < PRESETS.length; i++) {
            int sx = swX(i), sy = footY() + 7;
            g.fill(sx, sy, sx + 9, sy + 9, 0xFF000000 | PRESETS[i]);
            if ((PRESETS[i] & 0xFFFFFF) == Theme.rgb) {
                g.fill(sx - 1, sy - 1, sx + 10, sy, 0xFFFFFFFF);
                g.fill(sx - 1, sy + 9, sx + 10, sy + 10, 0xFFFFFFFF);
                g.fill(sx - 1, sy, sx, sy + 9, 0xFFFFFFFF);
                g.fill(sx + 9, sy, sx + 10, sy + 9, 0xFFFFFFFF);
            }
        }
        int hx = hueX(), hy = footY() + 9;
        for (int i = 0; i < hueW(); i++) {
            g.fill(hx + i, hy, hx + i + 1, hy + 6,
                    0xFF000000 | (Mth.hsvToRgb(i / (float) hueW(), 0.7f, 1f) & 0xFFFFFF));
        }
        int mk = hx + (int) (Theme.hue * (hueW() - 1));
        g.fill(mk, hy - 2, mk + 1, hy + 8, 0xFFFFFFFF);
    }

    private void drawSwitch(GuiGraphics g, int x, int y, int w, int h, boolean on, int accent) {
        Draw.round(g, x, y, w, h, on ? Draw.alpha(Theme.rgb, 0xA0) : TRACK);
        int kx = on ? x + w - h + 1 : x + 1;
        g.fill(kx, y + 1, kx + h - 2, y + h - 1, on ? accent : 0xFF6A6A78);
    }

    private static String trim(double v) {
        return v == Math.rint(v) ? String.valueOf((int) v) : String.format("%.2f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private void setHueFrom(double mx) {
        Theme.setHue((float) ((mx - hueX()) / (double) (hueW() - 1)));
    }

    private void setScrollFrom(double my) {
        double frac = Mth.clamp((my - viewTop()) / (double) viewH(), 0.0, 1.0);
        scroll = (int) (frac * maxScroll());
    }

    private void updateSlider(double mx) {
        NumSetting n = (NumSetting) slider.setting();
        int lx = slider.x() + 6, tw = slider.w() - 12;
        double frac = Mth.clamp((mx - lx) / tw, 0.0, 1.0);
        n.set(n.min + frac * (n.max - n.min));
    }

    private boolean inView(double my) { return my >= viewTop() && my <= viewBottom(); }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        listening = null;

        // цвет клиента
        for (int i = 0; i < PRESETS.length; i++) {
            int sx = swX(i), sy = footY() + 7;
            if (mx >= sx && mx <= sx + 9 && my >= sy && my <= sy + 9) {
                Theme.setRgb(PRESETS[i]);
                colorChanged = true;
                return true;
            }
        }
        if (mx >= hueX() - 2 && mx <= hueX() + hueW() + 2 && my >= footY() + 6 && my <= footY() + 18) {
            hueDrag = true;
            colorChanged = true;
            setHueFrom(mx);
            return true;
        }
        // полоса прокрутки
        if (maxScroll() > 0 && mx >= wx + W - 14 && mx <= wx + W && inView(my)) {
            sbDrag = true;
            setScrollFrom(my);
            return true;
        }

        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            switch (h.type()) {
                case T_CLOSE -> { onClose(); return true; }
                case T_TITLE -> {
                    dragWin = true;
                    dragDX = (int) mx - wx;
                    dragDY = (int) my - wy;
                    return true;
                }
                case T_CAT -> {
                    selCat = h.cat();
                    scroll = 0;
                    return true;
                }
                case T_ARROW -> {
                    if (!inView(my)) continue;
                    if (!h.module().settings.isEmpty() && !EXPANDED.remove(h.module())) EXPANDED.add(h.module());
                    return true;
                }
                case T_TOGGLE -> {
                    if (!inView(my)) continue;
                    if (button == 1) {
                        if (!h.module().settings.isEmpty() && !EXPANDED.remove(h.module())) EXPANDED.add(h.module());
                    } else {
                        h.module().toggle();
                    }
                    return true;
                }
                case T_SET -> {
                    if (!inView(my)) continue;
                    Setting s = h.setting();
                    if (s instanceof BoolSetting b) {
                        b.value = !b.value;
                    } else if (s instanceof ModeSetting ms) {
                        ms.next();
                    } else if (s instanceof KeySetting ks) {
                        listening = ks;
                    } else if (s instanceof NumSetting) {
                        slider = h;
                        updateSlider(mx);
                    }
                    return true;
                }
                default -> { }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (hueDrag) { setHueFrom(mx); return true; }
        if (sbDrag) { setScrollFrom(my); return true; }
        if (dragWin) {
            wx = (int) mx - dragDX;
            wy = (int) my - dragDY;
            return true;
        }
        if (slider != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (colorChanged) {
            Config.save();
            colorChanged = false;
        }
        dragWin = false;
        hueDrag = false;
        sbDrag = false;
        slider = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (mx >= wx + SBW && inView(my)) {
            scroll = Mth.clamp(scroll - (int) (scrollY * 14), 0, maxScroll());
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (listening != null) {
            listening.key = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            listening = null;
            Config.save();
            return true;
        }
        if (key == GLFW.GLFW_KEY_Y) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        listening = null;
        super.onClose();
    }
}
