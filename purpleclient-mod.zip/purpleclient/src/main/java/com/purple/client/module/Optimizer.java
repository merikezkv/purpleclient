package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;

/** Оптимизация клиента: ниже дальность прорисовки, быстрая графика, без тряски камеры. При выключении всё возвращается. */
public class Optimizer extends Module {
    private final NumSetting dist = new NumSetting("Дальность прорисовки", 8, 2, 32, 1);
    private final BoolSetting fast = new BoolSetting("Быстрая графика", true);
    private final BoolSetting bob = new BoolSetting("Без тряски камеры", true);

    private boolean saved;
    private int oldDist;
    private GraphicsStatus oldGraphics;
    private boolean oldBob;

    public Optimizer() {
        super("Optimizer", "Misc");
        settings.add(dist);
        settings.add(fast);
        settings.add(bob);
    }

    @Override
    public void onTick() {
        Options o = Minecraft.getInstance().options;
        if (!saved) {
            oldDist = o.renderDistance().get();
            oldGraphics = o.graphicsMode().get();
            oldBob = o.bobView().get();
            saved = true;
        }
        int d = (int) dist.value;
        if (o.renderDistance().get() != d) o.renderDistance().set(d);
        if (fast.value && o.graphicsMode().get() != GraphicsStatus.FAST) o.graphicsMode().set(GraphicsStatus.FAST);
        if (bob.value && o.bobView().get()) o.bobView().set(false);
    }

    @Override
    public void onDisable() {
        if (!saved) return;
        Options o = Minecraft.getInstance().options;
        o.renderDistance().set(oldDist);
        o.graphicsMode().set(oldGraphics);
        o.bobView().set(oldBob);
        saved = false;
    }
}
