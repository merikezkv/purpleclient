package com.purple.client.gui;

import net.minecraft.util.Mth;

/** Цвет клиента (используется во всём интерфейсе). */
public final class Theme {
    public static int rgb = 0x9D4EDD;
    public static float hue = 0.75f;

    private Theme() {}

    public static int accent() { return 0xFF000000 | rgb; }

    public static void setHue(float h) {
        hue = Mth.clamp(h, 0f, 1f);
        rgb = Mth.hsvToRgb(hue, 0.7f, 1f) & 0xFFFFFF;
    }

    public static void setRgb(int color) { rgb = color & 0xFFFFFF; }
}
