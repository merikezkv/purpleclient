package com.purple.client.module;

import com.purple.client.setting.NumSetting;

/**
 * Свободная камера в третьем лице (F5): мышь вращает камеру вокруг игрока, а не самого игрока,
 * камера не упирается в блоки. Логика в util.CameraControl.
 */
public class FreeLook extends Module {
    private final NumSetting distance = new NumSetting("Дистанция", 4.0, 2, 12, 0.5);

    public FreeLook() {
        super("FreeLook", "Render");
        settings.add(distance);
    }

    public double distance() { return distance.value; }
}
