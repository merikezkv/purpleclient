package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.List;

/**
 * Стрелки у прицела: направление на ближайших противников.
 * Показываются в слоте субтитра прямо под прицелом (своего HUD в Forge 1.21.4 нарисовать нельзя).
 */
public class Arrows extends Module {
    private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};

    private final NumSetting range = new NumSetting("Дальность", 32, 8, 64, 4);
    private final BoolSetting players = new BoolSetting("Игроки", true);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);
    private final NumSetting count = new NumSetting("Макс. целей", 4, 1, 6, 1);
    private final BoolSetting showDist = new BoolSetting("Дистанция", true);

    public Arrows() {
        super("Arrows", "Render");
        settings.add(range);
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
        settings.add(count);
        settings.add(showDist);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;

        List<Entity> list = new ArrayList<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (Targets.valid(e, p, players.value, hostile.value, animals.value) && p.distanceTo(e) <= range.value) {
                list.add(e);
            }
        }
        if (list.isEmpty()) return;
        list.sort((a, b) -> Float.compare(p.distanceTo(a), p.distanceTo(b)));

        MutableComponent out = Component.empty();
        int n = Math.min((int) count.value, list.size());
        for (int i = 0; i < n; i++) {
            Entity e = list.get(i);
            float dist = p.distanceTo(e);
            double dx = e.getX() - p.getX(), dz = e.getZ() - p.getZ();
            float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float rel = Mth.wrapDegrees(targetYaw - p.getYRot());
            int idx = Math.floorMod(Math.round(rel / 45f), 8);
            String color = dist < 8 ? "§c" : (dist < 20 ? "§e" : "§a");
            String text = color + ARROWS[idx] + (showDist.value ? String.valueOf((int) dist) : "");
            out.append(Component.literal(text + (i < n - 1 ? "  " : "")));
        }

        mc.gui.setTimes(0, 4, 4);
        mc.gui.setTitle(Component.literal(" "));
        mc.gui.setSubtitle(out);
    }
}
