package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.phys.Vec3;

/** Плавное наведение при натяжении лука / замахе трезубцем. */
public class AimBot extends Module {
    private final NumSetting range = new NumSetting("Дальность", 40, 8, 80, 1);
    private final NumSetting fov = new NumSetting("FOV", 90, 10, 360, 5);
    private final NumSetting speed = new NumSetting("Плавность", 30, 5, 100, 5);
    private final NumSetting maxStep = new NumSetting("Макс. поворот", 25, 5, 90, 5);
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);
    private final BoolSetting predict = new BoolSetting("Упреждение", true);
    private final BoolSetting walls = new BoolSetting("Сквозь стены", false);

    public AimBot() {
        super("AimBot", "Combat");
        settings.add(range);
        settings.add(fov);
        settings.add(speed);
        settings.add(maxStep);
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
        settings.add(predict);
        settings.add(walls);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !p.isUsingItem()) return;

        ItemStack stack = p.getUseItem();
        double projSpeed; // блоков за тик
        if (stack.getItem() instanceof BowItem) {
            float f = Math.min(p.getTicksUsingItem() / 20f, 1f);
            f = (f * f + f * 2f) / 3f;
            if (f < 0.1f) return;
            projSpeed = f * 3.0;
        } else if (stack.getItem() instanceof TridentItem) {
            projSpeed = 2.5;
        } else {
            return;
        }

        LivingEntity target = findTarget(mc, p);
        if (target == null) return;

        Vec3 eye = p.getEyePosition();
        Vec3 base = target.position().add(0, target.getBbHeight() * 0.5, 0);
        Vec3 aim = base;

        if (predict.value) {
            Vec3 vel = new Vec3(target.getX() - target.xo,
                                target.getY() - target.yo,
                                target.getZ() - target.zo);
            for (int i = 0; i < 3; i++) {
                double t = eye.distanceTo(aim) / projSpeed;
                aim = base.add(vel.scale(t));
            }
        }

        // компенсация падения снаряда (гравитация 0.05 за тик)
        double t = eye.distanceTo(aim) / projSpeed;
        aim = aim.add(0, 0.025 * t * t, 0);

        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

        float k = (float) speed.value / 100f;
        float max = (float) maxStep.value;
        p.setYRot(p.getYRot() + Aim.step(Mth.wrapDegrees(targetYaw - p.getYRot()), k, max));
        p.setXRot(Mth.clamp(p.getXRot() + Aim.step(targetPitch - p.getXRot(), k, max), -90f, 90f));
    }

    private LivingEntity findTarget(Minecraft mc, LocalPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestAngle = fov.value / 2.0 + 0.001;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!Targets.valid(e, p, players.value, hostile.value, animals.value)) continue;
            if (p.distanceTo(e) > range.value) continue;
            if (!walls.value && !p.hasLineOfSight(e)) continue;

            LivingEntity le = (LivingEntity) e;
            Vec3 to = le.position().add(0, le.getBbHeight() * 0.5, 0).subtract(eye).normalize();
            double angle = Math.toDegrees(Math.acos(Mth.clamp(look.dot(to), -1.0, 1.0)));
            if (angle < bestAngle) {
                bestAngle = angle;
                best = le;
            }
        }
        return best;
    }
}
