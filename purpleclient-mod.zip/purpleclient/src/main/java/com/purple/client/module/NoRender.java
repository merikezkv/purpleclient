package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;

/** Отключает лишнюю отрисовку: частицы, облака, тени сущностей. После выключения настройки возвращаются. */
public class NoRender extends Module {
    private final BoolSetting particles = new BoolSetting("Частицы", true);
    private final BoolSetting clouds = new BoolSetting("Облака", true);
    private final BoolSetting shadows = new BoolSetting("Тени сущностей", true);

    private boolean saved;
    private ParticleStatus oldParticles;
    private CloudStatus oldClouds;
    private boolean oldShadows;

    public NoRender() {
        super("NoRender", "Misc");
        settings.add(particles);
        settings.add(clouds);
        settings.add(shadows);
    }

    @Override
    public void onTick() {
        Options o = Minecraft.getInstance().options;
        if (!saved) {
            oldParticles = o.particles().get();
            oldClouds = o.cloudStatus().get();
            oldShadows = o.entityShadows().get();
            saved = true;
        }
        if (particles.value && o.particles().get() != ParticleStatus.MINIMAL) o.particles().set(ParticleStatus.MINIMAL);
        if (clouds.value && o.cloudStatus().get() != CloudStatus.OFF) o.cloudStatus().set(CloudStatus.OFF);
        if (shadows.value && o.entityShadows().get()) o.entityShadows().set(false);
    }

    @Override
    public void onDisable() {
        if (!saved) return;
        Options o = Minecraft.getInstance().options;
        o.particles().set(oldParticles);
        o.cloudStatus().set(oldClouds);
        o.entityShadows().set(oldShadows);
        saved = false;
    }
}
