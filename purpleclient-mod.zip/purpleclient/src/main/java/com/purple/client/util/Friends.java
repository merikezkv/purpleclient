package com.purple.client.util;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class Friends {
    private static final Set<String> NAMES = new LinkedHashSet<>();
    private Friends() {}

    public static boolean add(String name) { return NAMES.add(name.toLowerCase()); }
    public static boolean remove(String name) { return NAMES.remove(name.toLowerCase()); }
    public static boolean isFriend(String name) { return NAMES.contains(name.toLowerCase()); }
    public static List<String> list() { return new ArrayList<>(NAMES); }
    public static void clear() { NAMES.clear(); }
}
