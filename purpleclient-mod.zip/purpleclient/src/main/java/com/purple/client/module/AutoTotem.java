package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

/** Держит тотем бессмертия в левой руке. */
public class AutoTotem extends Module {
    private final BoolSetting always = new BoolSetting("Всегда", true);
    private final NumSetting health = new NumSetting("Здоровье (HP)", 10, 1, 20, 1);
    private final NumSetting delay = new NumSetting("Задержка (тики)", 2, 0, 10, 1);

    private int timer;

    public AutoTotem() {
        super("AutoTotem", "Player");
        settings.add(always);
        settings.add(health);
        settings.add(delay);
    }

    /** Номер слота в меню инвентаря (id 0) для первого тотема: хотбар 36-44, основной инвентарь 9-35. */
    private static int findTotemSlot(LocalPlayer p) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) return 36 + i;
        }
        for (int i = 9; i < 36; i++) {
            if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null) return;
        if (p.containerMenu != p.inventoryMenu) return;

        timer++;
        if (timer <= delay.value) return;
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
        if (!always.value && p.getHealth() + p.getAbsorptionAmount() > health.value) return;

        int slot = findTotemSlot(p);
        if (slot == -1) return;

        // SWAP с кнопкой 40 = обмен слота с левой рукой
        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
        timer = 0;
    }
}
