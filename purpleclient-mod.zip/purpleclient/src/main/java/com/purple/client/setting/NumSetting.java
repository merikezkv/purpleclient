package com.purple.client.setting;

public class NumSetting extends Setting {
    public double value;
    public final double min, max, step;
    public NumSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.value = value; this.min = min; this.max = max; this.step = step;
    }
    public void set(double v) {
        v = Math.round(v / step) * step;
        this.value = Math.max(min, Math.min(max, v));
    }
}
