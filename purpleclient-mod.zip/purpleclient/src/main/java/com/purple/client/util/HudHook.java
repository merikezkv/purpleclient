package com.purple.client.util;

import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;

import java.lang.reflect.Field;

/**
 * Подключает свой слой отрисовки к игровому HUD (в Forge 1.21.4 нет событий отрисовки).
 * Слой добавляется в список слоёв ванильного Gui через рефлексию (поле ищется по типу).
 */
public final class HudHook {
    private static boolean installed, failed, warned;

    private HudHook() {}

    public static void install(Minecraft mc) {
        if (installed || mc.gui == null) return;
        if (!failed) {
            try {
                for (Field f : Gui.class.getDeclaredFields()) {
                    if (f.getType() == LayeredDraw.class) {
                        f.setAccessible(true);
                        LayeredDraw ld = (LayeredDraw) f.get(mc.gui);
                        ld.add((g, dt) -> render(g));
                        installed = true;
                        return;
                    }
                }
                failed = true;
            } catch (Throwable t) {
                failed = true;
            }
        }
        if (failed && !warned && mc.player != null) {
            warned = true;
            Commands.msg("§cHUD-слой не подключился: рамки, HUD и круги работать не будут");
        }
    }

    private static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        for (Module m : ModuleManager.MODULES) {
            if (!m.isEnabled()) continue;
            try {
                m.onRenderHud(g, w, h);
            } catch (Throwable ignored) {
            }
        }
    }
}
