package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Combat;
import com.purple.client.util.TargetMarker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Сам наводится на цель и бьёт. Для одиночной игры и своих серверов.
 * Вращение: Плавная / Резкая.
 * Коррекция (режим наводки): Свободная / Таргет / Фокус.
 */
public class AttackAura extends Module {
    private final NumSetting range = new NumSetting("Дальность", 3.0, 2, 4.5, 0.1);
    private final NumSetting fov = new NumSetting("FOV", 360, 30, 360, 10);
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);
    private final ModeSetting rotation = new ModeSetting("Вращение", 0, "Плавная", "Резкая");
    // Свободная: камера доворачивается только при заметном рассогласовании;
    // Таргет: жёсткий захват цели, ближайшей к прицелу; Фокус: залипает на одной цели до её смерти/ухода
    private final ModeSetting correction = new ModeSetting("Коррекция", 0, "Свободная", "Таргет", "Фокус");
    private final NumSetting speed = new NumSetting("Скорость", 45, 5, 100, 5);
    private final NumSetting maxStep = new NumSetting("Макс. поворот", 40, 5, 180, 5);
    private final ModeSetting priority = new ModeSetting("Приоритет", 0, "Дистанция", "Здоровье");
    private final ModeSetting targetEsp = new ModeSetting("TargetESP", 1, TargetMarker.MODES);
    private final BoolSetting cooldown = new BoolSetting("Ждать кулдаун", true);
    private final NumSetting charge = new NumSetting("Кулдаун %", 90, 50, 100, 5);
    private final NumSetting delay = new NumSetting("Задержка (тики)", 0, 0, 10, 1);
    private final BoolSetting walls = new BoolSetting("Сквозь стены", false);
    private final BoolSetting skipUsing = new BoolSetting("Не при еде/щите", true);

    private final TargetMarker marker = new TargetMarker();
    private LivingEntity focus;
    private int timer;

    public AttackAura() {
        super("AttackAura", "Combat");
        settings.add(range);
        settings.add(fov);
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
        settings.add(rotation);
        settings.add(correction);
        settings.add(speed);
        settings.add(maxStep);
        settings.add(priority);
        settings.add(targetEsp);
        settings.add(cooldown);
        settings.add(charge);
        settings.add(delay);
        settings.add(walls);
        settings.add(skipUsing);
    }

    private LivingEntity pick(Minecraft mc, LocalPlayer p) {
        if (correction.is(2) && focus != null && focus.isAlive()
                && p.distanceTo(focus) <= range.value + 1.0
                && (walls.value || p.hasLineOfSight(focus))) {
            return focus;
        }

        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!Targets.valid(e, p, players.value, hostile.value, animals.value)) continue;
            double dist = p.distanceTo(e);
            if (dist > range.value) continue;
            if (!walls.value && !p.hasLineOfSight(e)) continue;

            LivingEntity le = (LivingEntity) e;
            Vec3 to = le.position().add(0, le.getBbHeight() * 0.6, 0).subtract(eye).normalize();
            double angle = Math.toDegrees(Math.acos(Mth.clamp(look.dot(to), -1.0, 1.0)));
            if (angle > fov.value / 2.0 + 0.001) continue;

            double score = correction.is(1) ? angle : (priority.is(1) ? le.getHealth() : dist);
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        focus = best;
        return best;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null) {
            marker.update(null, 0);
            return;
        }

        timer++;
        LivingEntity best = pick(mc, p);
        marker.update(best, targetEsp.index);
        if (best == null) return;
        Combat.set(best);

        Vec3 eye = p.getEyePosition();
        Vec3 aim = best.position().add(0, best.getBbHeight() * 0.6, 0);
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        float dYaw = Mth.wrapDegrees(targetYaw - p.getYRot());
        float dPitch = targetPitch - p.getXRot();

        boolean sharp = rotation.is(1);
        boolean skipTurn = correction.is(0) && Math.abs(dYaw) < 4 && Math.abs(dPitch) < 4;
        if (!skipTurn) {
            if (sharp) {
                p.setYRot(p.getYRot() + dYaw);
                p.setXRot(Mth.clamp(p.getXRot() + dPitch, -90f, 90f));
            } else {
                float k = (float) speed.value / 100f;
                float max = (float) maxStep.value;
                p.setYRot(p.getYRot() + Aim.step(dYaw, k, max));
                p.setXRot(Mth.clamp(p.getXRot() + Aim.step(dPitch, k, max), -90f, 90f));
            }
        }

        Vec3 to = aim.subtract(eye).normalize();
        double angle = Math.toDegrees(Math.acos(Mth.clamp(p.getLookAngle().dot(to), -1.0, 1.0)));
        boolean aligned = sharp || angle <= 25;
        if (!aligned) return;

        if (skipUsing.value && p.isUsingItem()) return;
        if (cooldown.value && p.getAttackStrengthScale(0f) * 100.0 < charge.value) return;
        if (timer <= delay.value) return;

        mc.gameMode.attack(p, best);
        p.swing(InteractionHand.MAIN_HAND);
        timer = 0;
    }

    @Override
    public void onDisable() {
        marker.clear();
        focus = null;
    }
}
