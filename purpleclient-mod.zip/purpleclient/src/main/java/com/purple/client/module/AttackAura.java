package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.CameraControl;
import com.purple.client.util.Combat;
import com.purple.client.util.TargetMarker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Сам наводится на цель и бьёт. Для одиночной игры и своих серверов.
 * Коррекция "Свободная": вы полностью управляете персонажем, а камера отдельно смотрит на цель
 * (поворот игрока не меняется, движение не сбивается).
 * Коррекция "Таргет": жёсткий захват цели с поворотом игрока и подходом вплотную.
 */
public class AttackAura extends Module {
    private final NumSetting range = new NumSetting("Дистанция атаки", 3.0, 2, 4.5, 0.1);
    private final NumSetting aimRange = new NumSetting("Дистанция наводки", 5.0, 2, 8, 0.5);
    private final NumSetting fov = new NumSetting("FOV", 360, 30, 360, 10);
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);
    private final ModeSetting rotation = new ModeSetting("Вращение", 0, "Плавная", "Резкая");
    private final ModeSetting correction = new ModeSetting("Коррекция", 0, "Свободная", "Таргет");
    private final NumSetting speed = new NumSetting("Скорость", 45, 5, 100, 5);
    private final NumSetting maxStep = new NumSetting("Макс. поворот", 40, 5, 180, 5);
    private final ModeSetting priority = new ModeSetting("Приоритет", 0, "Дистанция", "Здоровье");
    private final ModeSetting crits = new ModeSetting("Криты", 3, "Выкл", "Падение", "Прыжок", "Умный");
    private final ModeSetting targetEsp = new ModeSetting("TargetESP", 1, TargetMarker.MODES);
    private final BoolSetting cooldown = new BoolSetting("Ждать кулдаун", true);
    private final NumSetting charge = new NumSetting("Кулдаун %", 90, 50, 100, 5);
    private final NumSetting delay = new NumSetting("Задержка (тики)", 0, 0, 10, 1);
    private final BoolSetting walls = new BoolSetting("Сквозь стены", false);
    private final BoolSetting skipUsing = new BoolSetting("Не при еде/щите", true);

    private final TargetMarker marker = new TargetMarker();
    private final CritHelper crit = new CritHelper();
    private int timer;
    private boolean viewActive;
    private float viewYaw, viewPitch;

    public AttackAura() {
        super("AttackAura", "Combat");
        settings.add(range);
        settings.add(aimRange);
        settings.add(fov);
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
        settings.add(rotation);
        settings.add(correction);
        settings.add(speed);
        settings.add(maxStep);
        settings.add(priority);
        settings.add(crits);
        settings.add(targetEsp);
        settings.add(cooldown);
        settings.add(charge);
        settings.add(delay);
        settings.add(walls);
        settings.add(skipUsing);
    }

    private LivingEntity pick(Minecraft mc, LocalPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!Targets.valid(e, p, players.value, hostile.value, animals.value)) continue;
            double dist = p.distanceTo(e);
            if (dist > aimRange.value) continue;
            if (!walls.value && !p.hasLineOfSight(e)) continue;

            LivingEntity le = (LivingEntity) e;
            Vec3 to = le.position().add(0, le.getBbHeight() * 0.6, 0).subtract(eye).normalize();
            double angle = Math.toDegrees(Math.acos(Mth.clamp(look.dot(to), -1.0, 1.0)));
            if (angle > fov.value / 2.0 + 0.001) continue;

            double score = correction.is(1) ? angle : (priority.is(1) ? le.getHealth() : dist);
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        return best;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;

        crit.release(mc);
        if (mc.screen != null) {
            marker.update(null, 0);
            viewActive = false;
            return;
        }

        timer++;
        LivingEntity best = pick(mc, p);
        marker.update(best, targetEsp.index);
        if (best == null) {
            viewActive = false;
            crit.reset();
            return;
        }
        Combat.set(best);

        Vec3 eye = p.getEyePosition();
        Vec3 aim = best.position().add(0, best.getBbHeight() * 0.6, 0);
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        boolean sharp = rotation.is(1);
        float k = (float) speed.value / 100f;
        float max = (float) maxStep.value;
        boolean aligned;

        if (correction.is(0)) {
            // Свободная: поворачиваем только отдельную камеру, игрок и его движение не затрагиваются
            if (!viewActive) {
                viewYaw = p.getYRot();
                viewPitch = p.getXRot();
                viewActive = true;
            }
            float dYaw = Mth.wrapDegrees(targetYaw - viewYaw);
            float dPitch = targetPitch - viewPitch;
            if (sharp) {
                viewYaw += dYaw;
                viewPitch = Mth.clamp(viewPitch + dPitch, -90f, 90f);
            } else {
                viewYaw += Aim.step(dYaw, k, max);
                viewPitch = Mth.clamp(viewPitch + Aim.step(dPitch, k, max), -90f, 90f);
            }
            CameraControl.setAura(viewYaw, viewPitch);
            aligned = sharp || Math.abs(Mth.wrapDegrees(targetYaw - viewYaw)) <= 25;
        } else {
            // Таргет: жёсткий захват цели
            viewActive = false;
            float dYaw = Mth.wrapDegrees(targetYaw - p.getYRot());
            float dPitch = targetPitch - p.getXRot();
            if (sharp) {
                p.setYRot(p.getYRot() + dYaw);
                p.setXRot(Mth.clamp(p.getXRot() + dPitch, -90f, 90f));
            } else {
                p.setYRot(p.getYRot() + Aim.step(dYaw, k, max));
                p.setXRot(Mth.clamp(p.getXRot() + Aim.step(dPitch, k, max), -90f, 90f));
            }
            CameraControl.markRotation();

            // вжимаемся в цель
            double hx = best.getX() - p.getX(), hz = best.getZ() - p.getZ();
            double hd = Math.hypot(hx, hz);
            Vec3 v = p.getDeltaMovement();
            if (hd > 1.3 && Math.hypot(v.x, v.z) < 0.3) {
                p.setDeltaMovement(v.x + hx / hd * 0.06, v.y, v.z + hz / hd * 0.06);
            }

            Vec3 to = aim.subtract(eye).normalize();
            double angle = Math.toDegrees(Math.acos(Mth.clamp(p.getLookAngle().dot(to), -1.0, 1.0)));
            aligned = sharp || angle <= 25;
        }

        if (!aligned) return;
        if (p.distanceTo(best) > range.value) return;
        if (skipUsing.value && p.isUsingItem()) return;
        if (cooldown.value && p.getAttackStrengthScale(0f) * 100.0 < charge.value) return;
        if (timer <= delay.value) return;
        if (!crit.allow(mc, p, crits.index)) return;

        mc.gameMode.attack(p, best);
        p.swing(InteractionHand.MAIN_HAND);
        timer = 0;
        crit.reset();
    }

    @Override
    public void onDisable() {
        marker.clear();
        crit.release(Minecraft.getInstance());
        viewActive = false;
    }
}
