package com.purple.client.util;

import net.minecraft.world.entity.Entity;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/** Включает/выключает ванильное свечение сущности на клиенте. */
public final class GlowUtil {
    private static final int FLAG_GLOWING = 6;
    private static Method setSharedFlag;

    static {
        // ищем protected void setSharedFlag(int, boolean) без привязки к имени (имена зависят от маппингов)
        for (Method m : Entity.class.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (!Modifier.isStatic(m.getModifiers()) && m.getReturnType() == void.class
                    && p.length == 2 && p[0] == int.class && p[1] == boolean.class) {
                m.setAccessible(true);
                setSharedFlag = m;
                break;
            }
        }
    }

    private GlowUtil() {}

    public static void set(Entity e, boolean on) {
        if (setSharedFlag == null || e == null) return;
        try {
            setSharedFlag.invoke(e, FLAG_GLOWING, on);
        } catch (Exception ignored) {
        }
    }
}
