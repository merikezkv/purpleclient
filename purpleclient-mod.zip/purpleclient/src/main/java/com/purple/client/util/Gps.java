package com.purple.client.util;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

public final class Gps {
    public static boolean active;
    public static double x, z;
    private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};

    private Gps() {}

    public static Component line(LocalPlayer p) {
        if (!active) return null;
        double dx = x - p.getX(), dz = z - p.getZ();
        double dist = Math.hypot(dx, dz);
        if (dist < 3) {
            active = false;
            Commands.msg("Вы прибыли в точку назначения");
            return null;
        }
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float rel = Mth.wrapDegrees(targetYaw - p.getYRot());
        int idx = Math.floorMod(Math.round(rel / 45f), 8);
        return Component.literal(String.format("GPS %d %d  %dм %s", (int) x, (int) z, (int) dist, ARROWS[idx]));
    }
}
