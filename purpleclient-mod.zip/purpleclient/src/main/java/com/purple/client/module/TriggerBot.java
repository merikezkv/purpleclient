package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;

/** Бьёт, когда прицел наведён на цель. */
public class TriggerBot extends Module {
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting mobs = new BoolSetting("Мобы", true);
    private final BoolSetting cooldown = new BoolSetting("Ждать кулдаун", true);
    private final NumSetting charge = new NumSetting("Кулдаун %", 90, 50, 100, 5);
    private final NumSetting delay = new NumSetting("Задержка (тики)", 0, 0, 10, 1);
    private final BoolSetting crits = new BoolSetting("Только криты", false);
    private final BoolSetting skipUsing = new BoolSetting("Не при еде/щите", true);

    private int timer;

    public TriggerBot() {
        super("TriggerBot", "Combat");
        settings.add(players);
        settings.add(mobs);
        settings.add(cooldown);
        settings.add(charge);
        settings.add(delay);
        settings.add(crits);
        settings.add(skipUsing);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;

        timer++;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return;
        Entity target = hit.getEntity();
        if (!Targets.valid(target, p, players.value, mobs.value)) return;

        if (skipUsing.value && p.isUsingItem()) return;
        if (cooldown.value && p.getAttackStrengthScale(0f) * 100.0 < charge.value) return;
        if (crits.value && (p.onGround() || p.fallDistance <= 0 || p.isInWater())) return;
        if (timer <= delay.value) return;

        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
        timer = 0;
    }
}
