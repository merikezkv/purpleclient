package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Combat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/** Бьёт, когда прицел наведён на цель. */
public class TriggerBot extends Module {
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);
    private final BoolSetting cooldown = new BoolSetting("Ждать кулдаун", true);
    private final NumSetting charge = new NumSetting("Кулдаун %", 90, 50, 100, 5);
    private final NumSetting delay = new NumSetting("Задержка (тики)", 0, 0, 10, 1);
    // Выкл / Падение (ждёт, пока вы сами упадёте) / Прыжок (прыгает сам) / Умный (прыжок, а если крит не вышел - бьёт обычно)
    private final ModeSetting crits = new ModeSetting("Криты", 0, "Выкл", "Падение", "Прыжок", "Умный");
    private final BoolSetting skipUsing = new BoolSetting("Не при еде/щите", true);

    private int timer, stuck;
    private boolean jumpPressed;

    public TriggerBot() {
        super("TriggerBot", "Combat");
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
        settings.add(cooldown);
        settings.add(charge);
        settings.add(delay);
        settings.add(crits);
        settings.add(skipUsing);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;

        // отпускаем кнопку прыжка, которую нажали в прошлом тике
        if (jumpPressed) {
            mc.options.keyJump.setDown(false);
            jumpPressed = false;
        }
        if (mc.screen != null) return;

        timer++;
        if (!(mc.hitResult instanceof EntityHitResult hit)) { stuck = 0; return; }
        Entity target = hit.getEntity();
        if (!Targets.valid(target, p, players.value, hostile.value, animals.value)) { stuck = 0; return; }

        if (skipUsing.value && p.isUsingItem()) return;
        boolean ready = !cooldown.value || p.getAttackStrengthScale(0f) * 100.0 >= charge.value;
        if (!ready) return;

        if (!crits.is(0)) {
            boolean canCrit = !p.onGround() && p.fallDistance > 0 && !p.isInWater()
                    && !p.onClimbable() && !p.isPassenger();
            if (canCrit) {
                p.setSprinting(false); // в ваниле крит невозможен во время спринта
            } else {
                // на земле: подпрыгиваем, чтобы ударить в падении
                if ((crits.is(2) || crits.is(3)) && p.onGround()) {
                    mc.options.keyJump.setDown(true);
                    jumpPressed = true;
                }
                // "Умный": если крит долго не получается, бьём обычным ударом, чтобы не зависнуть
                if (crits.is(3)) {
                    if (++stuck <= 25) return;
                } else {
                    return;
                }
            }
        }

        if (timer <= delay.value) return;

        Combat.set((LivingEntity) target);
        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
        timer = 0;
        stuck = 0;
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (jumpPressed) {
            mc.options.keyJump.setDown(false);
            jumpPressed = false;
        }
    }
}
