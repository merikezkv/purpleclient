package com.purple.client.module;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;

final class Targets {
    private Targets() {}

    static boolean valid(Entity e, LocalPlayer p, boolean players, boolean mobs) {
        if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || e instanceof ArmorStand) return false;
        return e instanceof Player ? players : mobs;
    }
}
