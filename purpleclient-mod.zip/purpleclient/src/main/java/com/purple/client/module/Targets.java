package com.purple.client.module;

import com.purple.client.util.Friends;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

final class Targets {
    private Targets() {}

    /** Игроки (кроме друзей), враждебные мобы, животные. Всё остальное (жители, предметы и т.д.) игнорируется. */
    static boolean valid(Entity e, LocalPlayer p, boolean players, boolean hostile, boolean animals) {
        if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player pl) return players && !Friends.isFriend(pl.getName().getString());
        if (e instanceof Enemy) return hostile;
        if (e instanceof Animal) return animals;
        return false;
    }
}
