package com.purple.client.module;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    static {
        MODULES.add(new AimBot());
        MODULES.add(new AimAssist());
        MODULES.add(new TriggerBot());
        MODULES.add(new Sprint());
        MODULES.add(new ESP());
    }

    public static void tick() {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick();
    }
}
