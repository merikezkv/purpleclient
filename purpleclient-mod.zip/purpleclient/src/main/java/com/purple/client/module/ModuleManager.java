package com.purple.client.module;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    public static final HUD hud = new HUD();
    public static final FreeLook freeLook = new FreeLook();

    static {
        // Combat
        MODULES.add(new AimBot());
        MODULES.add(new AimAssist());
        MODULES.add(new TriggerBot());
        MODULES.add(new AttackAura());
        MODULES.add(new Hitboxes());
        // Movement
        MODULES.add(new Sprint());
        MODULES.add(new InventoryMove());
        // Render
        MODULES.add(new ESP());
        MODULES.add(new TargetESP());
        MODULES.add(new Arrows());
        MODULES.add(new JumpCircles());
        MODULES.add(new ChinaHat());
        MODULES.add(freeLook);
        MODULES.add(new Fullbright());
        // Player
        MODULES.add(new AutoTotem());
        MODULES.add(new AutoSwap());
        MODULES.add(new ClickPearl());
        MODULES.add(new AutoEzz());
        // Misc
        MODULES.add(hud);
        MODULES.add(new UseTracker());
        MODULES.add(new TotemTracker());
        MODULES.add(new NoRender());
        MODULES.add(new Optimizer());
    }

    public static void tick() {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick();
    }
}
