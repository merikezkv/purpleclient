package com.purple.client.module;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    public static final HUD hud = new HUD();

    static {
        MODULES.add(new AimBot());
        MODULES.add(new AimAssist());
        MODULES.add(new TriggerBot());
        MODULES.add(new AttackAura());
        MODULES.add(new Sprint());
        MODULES.add(new ESP());
        MODULES.add(new TargetESP());
        MODULES.add(new Arrows());
        MODULES.add(new AutoTotem());
        MODULES.add(new AutoSwap());
        MODULES.add(hud);
    }

    public static void tick() {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick();
    }
}
