# Purple Client (Forge 1.21.4)

Модули: ClickGUI (клавиша Y, фиолетовый), AimBot (лук/трезубец), ESP (рамки сквозь стены, настройки).
Только для одиночной игры и своих серверов.

## Установка
1. Скачайте Forge MDK 1.21.4 (files.minecraftforge.net), распакуйте.
2. Скопируйте папку `src` из этого архива в корень MDK с заменой (старый пример кода в src/main/java удалите).
3. В gradle.properties: mod_id=purpleclient, mod_name=Purple Client, mod_group_id=com.purple.client
4. Тест: ./gradlew runClient   Сборка jar: ./gradlew build  (результат в build/libs)

## Управление
Y - меню. ЛКМ по модулю - вкл/выкл, ПКМ - настройки, панели перетаскиваются.

## Если не компилируется
- TickEvent.ClientTickEvent устарел -> TickEvent.ClientTickEvent.Post и убрать проверку phase.
- ESP съезжает -> добавить ps.mulPose(event.getModelViewMatrix()) перед ps.translate(...).

## Телефон (Java Edition через лаунчер)
Подходят PojavLauncher, Zalith Launcher, FCL: установите Forge 1.21.4 (нужна Java 21), положите jar в папку mods.
- Меню открывается кнопкой **Purple GUI** в левом верхнем углу меню паузы и инвентаря.
  Либо в редакторе управления лаунчера создайте экранную кнопку и назначьте ей клавишу Y.
- Тап по модулю - вкл/выкл, тап по +/- справа - настройки, ползунки двигаются пальцем, панели перетаскиваются.
- Закрыть меню: кнопка "Закрыть" снизу справа.
- Если интерфейс мелкий или крупный, поменяйте "Масштаб интерфейса" в настройках видео.

## Модули
Combat: AimBot (лук/трезубец), AimAssist (ближний бой), TriggerBot. Movement: Sprint. Render: ESP.
Цвет клиента выбирается в боковой панели "Цвет" справа в ClickGUI.

## Команды (в чате, через точку)
.help  .toggle <модуль>  .gps <X> <Z> | off  .bind add <модуль> <клавиша> | remove | list | clear  .friend add [ник] | remove <ник> | list | clear
Цвет, друзья и бинды сохраняются в файле purpleclient.properties в папке игры.

## Модули
Combat: AimBot, AimAssist, TriggerBot, AttackAura. Movement: Sprint. Render: ESP, TargetESP, Arrows.
Player: AutoTotem, AutoSwap (одноразовый, вешается на клавишу: .bind add AutoSwap g). Misc: HUD.

## Обновление
Combat: AimBot, AimAssist, TriggerBot, AttackAura, Hitboxes. Movement: Sprint, InventoryMove.
Render: ESP, TargetESP, Arrows, JumpCircles, ChinaHat, FreeLook, Fullbright.
Player: AutoTotem, AutoSwap, ClickPearl, AutoEzz. Misc: HUD, UseTracker, TotemTracker, NoRender, Optimizer.
Команды: .ezz <текст> (текст AutoEzz, {name} = ник), .ezz test.
HUD-рамка цели перетаскивается мышью при открытом чате.
