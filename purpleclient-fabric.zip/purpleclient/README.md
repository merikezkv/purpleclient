# Purple Client 2.0 (Fabric 1.21.4)

Только для одиночной игры и своих серверов.

## Установка
1. В лаунчере установите Fabric Loader для Minecraft 1.21.4.
2. Положите в папку mods: Fabric API для 1.21.4 (например 0.119.4+1.21.4) и PurpleClient-2.0.0.jar.
3. В игре: клавиша Y или кнопка "Purple GUI" в меню паузы / инвентаре.

## Команды (в чате, через точку)
.help  .toggle <модуль>  .gps <X> <Z> | off  .bind add <модуль> <клавиша> | remove | list | clear
.friend add [ник] | remove <ник> | list | clear  .ezz <текст> | test
Цвет, друзья, бинды, включённые модули и позиция рамки цели сохраняются в purpleclient.properties.
