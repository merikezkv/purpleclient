package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Combat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/** Бьёт, когда прицел наведён на цель. */
public class TriggerBot extends Module {
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);
    private final BoolSetting cooldown = new BoolSetting("Ждать кулдаун", true);
    private final NumSetting charge = new NumSetting("Кулдаун %", 90, 50, 100, 5);
    private final NumSetting delay = new NumSetting("Задержка (тики)", 0, 0, 10, 1);
    private final ModeSetting crits = new ModeSetting("Криты", 0, "Выкл", "Падение", "Прыжок", "Умный");
    private final BoolSetting skipUsing = new BoolSetting("Не при еде/щите", true);

    private final CritHelper crit = new CritHelper();
    private int timer;

    public TriggerBot() {
        super("TriggerBot", "Combat");
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
        settings.add(cooldown);
        settings.add(charge);
        settings.add(delay);
        settings.add(crits);
        settings.add(skipUsing);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;

        crit.release(mc);
        if (mc.screen != null) return;

        timer++;
        if (!(mc.hitResult instanceof EntityHitResult hit)) { crit.reset(); return; }
        Entity target = hit.getEntity();
        if (!Targets.valid(target, p, players.value, hostile.value, animals.value)) { crit.reset(); return; }

        boolean ready = !(skipUsing.value && p.isUsingItem())
                && (!cooldown.value || p.getAttackStrengthScale(0f) * 100.0 >= charge.value)
                && timer > delay.value;
        if (!crit.allow(mc, p, crits.index, ready)) return;

        Combat.set((LivingEntity) target);
        CritHelper.attack(mc, p, target, !crits.is(0));
        timer = 0;
        crit.reset();
    }

    @Override
    public void onDisable() {
        crit.release(Minecraft.getInstance());
    }
}
