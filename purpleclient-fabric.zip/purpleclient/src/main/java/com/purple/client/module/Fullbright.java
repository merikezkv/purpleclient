package com.purple.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Освещает темноту (клиентский эффект ночного зрения). */
public class Fullbright extends Module {
    private boolean added;

    public Fullbright() {
        super("Fullbright", "Render");
    }

    @Override
    public void onTick() {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) {
            p.forceAddEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1000, 0, false, false, false), null);
            added = true;
        }
    }

    @Override
    public void onDisable() {
        LocalPlayer p = Minecraft.getInstance().player;
        if (added && p != null) {
            p.removeEffect(MobEffects.NIGHT_VISION);
        }
        added = false;
    }
}
