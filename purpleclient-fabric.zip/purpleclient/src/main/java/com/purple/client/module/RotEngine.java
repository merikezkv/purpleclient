package com.purple.client.module;

import net.minecraft.util.Mth;

/**
 * Ротации AttackAura. Режимы: 0 Резкая, 1 Плавная, 2 Линейная, 3 Пружина.
 * Виртуальная ротация (yaw, pitch) двигается к цели; дальше её либо применяют к игроку (Таргет),
 * либо показывают только на модели (Свободная).
 */
final class RotEngine {
    float yaw, pitch;
    boolean active;
    private float vy, vp;

    void begin(float y, float p) { yaw = y; pitch = p; vy = 0; vp = 0; active = true; }
    void seed(float y, float p) { yaw = y; pitch = p; active = true; }
    void end() { active = false; vy = 0; vp = 0; }

    void step(int mode, float targetYaw, float targetPitch) {
        float dy = Mth.wrapDegrees(targetYaw - yaw);
        float dp = targetPitch - pitch;
        switch (mode) {
            case 0 -> { yaw += dy; pitch += dp; }                                   // Резкая: мгновенно
            case 1 -> { yaw += ease(dy, 0.38f); pitch += ease(dp, 0.38f); }         // Плавная: замедляется у цели
            case 2 -> { yaw += linear(dy, 30f); pitch += linear(dp, 20f); }         // Линейная: постоянная скорость
            default -> {                                                            // Пружина: разгон и лёгкий перелёт
                vy = (vy + dy * 0.22f) * 0.62f;
                vp = (vp + dp * 0.22f) * 0.62f;
                yaw += vy;
                pitch += vp;
            }
        }
        pitch = Mth.clamp(pitch, -90f, 90f);
    }

    private static float ease(float d, float k) { return Math.abs(d) < 0.3f ? d : d * k; }

    private static float linear(float d, float speed) {
        return Math.abs(d) <= speed ? d : Math.signum(d) * speed;
    }
}
