package com.purple.client.mixin;

import com.purple.client.gui.UiStyle;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Все кнопки Minecraft рисуются в стиле клиента. require = 0: при несовпадении метода игра не падает. */
@Mixin(AbstractButton.class)
public abstract class AbstractButtonMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true, require = 0)
    private void purple$style(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        try {
            if (UiStyle.drawButton(g, (AbstractButton) (Object) this)) ci.cancel();
        } catch (Throwable ignored) {
            // при любой ошибке рисуем ванильную кнопку
        }
    }
}
