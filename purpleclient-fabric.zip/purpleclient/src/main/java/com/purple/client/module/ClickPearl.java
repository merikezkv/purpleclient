package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.KeySetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

/** Бросает эндер-жемчуг по нажатию выбранной клавиши (из хотбара или из инвентаря), не меняя выбранный слот. */
public class ClickPearl extends Module {
    private final KeySetting key = new KeySetting("Бинд");
    private final BoolSetting fromInventory = new BoolSetting("Из инвентаря", true);

    public ClickPearl() {
        super("ClickPearl", "Player");
        settings.add(key);
        settings.add(fromInventory);
    }

    @Override
    public void onKey(int k) {
        if (key.key == -1 || k != key.key) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null || p.containerMenu != p.inventoryMenu) return;

        int hot = -1;
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(Items.ENDER_PEARL)) { hot = i; break; }

        if (hot != -1) {
            int old = p.getInventory().selected;
            p.getInventory().selected = hot;
            mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
            p.getInventory().selected = old;
            p.swing(InteractionHand.MAIN_HAND);
            return;
        }
        if (!fromInventory.value) return;

        int slot = -1;
        for (int i = 9; i < 36; i++) if (p.getInventory().getItem(i).is(Items.ENDER_PEARL)) { slot = i; break; }
        if (slot == -1) return;

        int sel = p.getInventory().selected;
        int id = p.inventoryMenu.containerId;
        mc.gameMode.handleInventoryMouseClick(id, slot, sel, ClickType.SWAP, p);
        mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
        mc.gameMode.handleInventoryMouseClick(id, slot, sel, ClickType.SWAP, p);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
