package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;

/** Отключает лишнюю отрисовку: частицы, облака, тени сущностей. После выключения настройки возвращаются. */
public class NoRender extends Module {
    private final BoolSetting particles = new BoolSetting("Частицы", true);
    private final BoolSetting clouds = new BoolSetting("Облака", true);
    private final BoolSetting shadows = new BoolSetting("Тени сущностей", true);

    private boolean saved;
    private Object oldParticles, oldClouds;
    private boolean oldShadows;

    public NoRender() {
        super("NoRender", "Misc");
        settings.add(particles);
        settings.add(clouds);
        settings.add(shadows);
    }

    /** Значение enum-настройки по позиции (первое/последнее), без обращения к самому типу enum. */
    private static Object enumAt(Object current, boolean last) {
        Object[] all = ((Enum<?>) current).getDeclaringClass().getEnumConstants();
        return last ? all[all.length - 1] : all[0];
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setRaw(OptionInstance opt, Object value) {
        opt.set(value);
    }

    @Override
    public void onTick() {
        Options o = Minecraft.getInstance().options;
        if (!saved) {
            oldParticles = o.particles().get();
            oldClouds = o.cloudStatus().get();
            oldShadows = o.entityShadows().get();
            saved = true;
        }
        if (particles.value) {
            Object minimal = enumAt(oldParticles, true); // ALL, DECREASED, MINIMAL
            if (o.particles().get() != minimal) setRaw(o.particles(), minimal);
        }
        if (clouds.value) {
            Object off = enumAt(oldClouds, false);       // OFF, FAST, FANCY
            if (o.cloudStatus().get() != off) setRaw(o.cloudStatus(), off);
        }
        if (shadows.value && o.entityShadows().get()) o.entityShadows().set(false);
    }

    @Override
    public void onDisable() {
        if (!saved) return;
        Options o = Minecraft.getInstance().options;
        setRaw(o.particles(), oldParticles);
        setRaw(o.cloudStatus(), oldClouds);
        o.entityShadows().set(oldShadows);
        saved = false;
    }
}
