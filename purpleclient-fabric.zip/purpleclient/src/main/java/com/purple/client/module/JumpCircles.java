package com.purple.client.module;

import com.purple.client.gui.Theme;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Draw;
import com.purple.client.util.Projector;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Расходящиеся круги цвета клиента в месте прыжка. */
public class JumpCircles extends Module {
    private final NumSetting radius = new NumSetting("Радиус", 2.0, 0.5, 5, 0.25);
    private final NumSetting life = new NumSetting("Время (мс)", 800, 300, 2000, 100);

    private static class Circle {
        final double x, y, z;
        final long start;
        Circle(double x, double y, double z, long start) { this.x = x; this.y = y; this.z = z; this.start = start; }
    }

    private final List<Circle> circles = new ArrayList<>();
    private boolean wasGround = true;

    public JumpCircles() {
        super("JumpCircles", "Render");
        settings.add(radius);
        settings.add(life);
    }

    @Override
    public void onTick() {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        boolean ground = p.onGround();
        if (wasGround && !ground && p.getDeltaMovement().y > 0.1) {
            circles.add(new Circle(p.getX(), p.getY() + 0.02, p.getZ(), System.currentTimeMillis()));
        }
        wasGround = ground;
    }

    @Override
    public void onDisable() {
        circles.clear();
    }

    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        if (circles.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        Projector pr = Projector.create(mc);
        long now = System.currentTimeMillis();

        for (Iterator<Circle> it = circles.iterator(); it.hasNext(); ) {
            Circle c = it.next();
            double age = (now - c.start) / life.value;
            if (age >= 1.0) { it.remove(); continue; }
            double r = 0.3 + age * radius.value;
            int a = (int) (255 * (1.0 - age));
            int color = Draw.alpha(Theme.rgb, a);
            int n = 40;
            for (int i = 0; i < n; i++) {
                double ang = Math.PI * 2 * i / n;
                if (pr.project(c.x + Math.cos(ang) * r, c.y, c.z + Math.sin(ang) * r)) {
                    Draw.dot(g, pr.sx, pr.sy, color);
                }
            }
        }
    }
}
