package com.purple.client.module;

import com.purple.client.setting.Setting;
import com.purple.client.util.Config;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String category;
    public final List<Setting> settings = new ArrayList<>();
    public int bindKey = -1;
    public String bindName;
    private boolean enabled;

    protected Module(String name, String category) {
        this.name = name;
        this.category = category;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        if (!enabled) onDisable();
        Config.save();
    }

    public void setEnabled(boolean v) {
        if (v != enabled) toggle();
    }

    public void onTick() {}
    public void onDisable() {}
    /** Нажатие клавиши в игре (вызывается только у включённых модулей). */
    public void onKey(int key) {}
    /** Отрисовка в HUD-слое (w, h - размер экрана в GUI-пикселях). */
    public void onRenderHud(GuiGraphics g, int w, int h) {}
}
