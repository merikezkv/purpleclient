package com.purple.client.gui;

import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.KeySetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.setting.Setting;
import com.purple.client.util.Config;
import com.purple.client.util.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Окно с обводкой: слева сайдбар с категориями, справа карточки модулей в две колонки с обводкой,
 * переключателями и раскрывающимися настройками, внизу выбор цвета клиента. Все элементы анимированы.
 */
public class ClickGuiScreen extends Screen {
    private static final int SBW = 92, HEAD = 26, FOOT = 26, GAP = 8;
    private static final int[] PRESETS = {
            0x9D4EDD, 0x4C8DFF, 0x2EC4B6, 0x4ADE80, 0xFACC15, 0xFB923C, 0xF43F5E, 0xFFFFFF
    };
    private static final int BG = 0xF00E0E13, SIDE = 0xF0121218, CARD = 0xFF17171E, CARD2 = 0xFF1B1B24, CARD_HOVER = 0xFF1F1F29;
    private static final int TRACK = 0xFF2A2A33, TXT = 0xFFECECF2, DIM = 0xFF8B8B99, LINE = 0xFF24242C, BORDER = 0xFF262630;

    private static int wx = Integer.MIN_VALUE, wy;
    private static int scroll;
    private static String selCat;
    private static final Set<Module> EXPANDED = new HashSet<>();

    private static final int T_TITLE = 0, T_CLOSE = 1, T_CAT = 2, T_ARROW = 3, T_TOGGLE = 4, T_SET = 5;

    private record Hit(int x, int y, int w, int h, int type, String cat, Module module, Setting setting) {
        boolean contains(double mx, double my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    private record AKey(Object obj, int kind) {}

    private final List<Hit> hits = new ArrayList<>();
    private final Map<AKey, Float> anims = new HashMap<>();
    private final long openStart = System.nanoTime();
    private long lastNanos = System.nanoTime();
    private float k = 0.2f, fa = 0f, scrollCur, pillRel = Float.NaN, catFade = 1f;
    private boolean dragWin, hueDrag, sbDrag, colorChanged;
    private int dragDX, dragDY, winW = 404, winH = 244;
    private Hit slider;
    private KeySetting listening;

    public ClickGuiScreen() {
        super(Component.literal("ClickGUI"));
        if (selCat == null) selCat = cats().get(0);
        scrollCur = scroll;
    }

    @Override public boolean isPauseScreen() { return false; }

    // ---------- анимации ----------
    private float anim(Object o, int kind, float target) {
        AKey key = new AKey(o, kind);
        float cur = anims.getOrDefault(key, target);
        cur += (target - cur) * k;
        if (Math.abs(target - cur) < 0.004f) cur = target;
        anims.put(key, cur);
        return cur;
    }

    private float expF(Module m) {
        return anims.getOrDefault(new AKey(m, 1), EXPANDED.contains(m) ? 1f : 0f);
    }

    private static int lerpColor(int a, int b, float t) {
        int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    private int ca(int c) {
        if (fa >= 0.999f) return c;
        int a = (int) (((c >>> 24) & 0xFF) * fa);
        return (a << 24) | (c & 0xFFFFFF);
    }

    private void fill(GuiGraphics g, int x1, int y1, int x2, int y2, int c) { g.fill(x1, y1, x2, y2, ca(c)); }
    private void rnd(GuiGraphics g, int x, int y, int w, int h, int c) { Draw.round(g, x, y, w, h, ca(c)); }

    private void txt(GuiGraphics g, String s, int x, int y, int c) {
        int cc = ca(c);
        if ((cc >>> 24) < 8) return;
        g.drawString(font, s, x, y, cc, false);
    }

    // ---------- данные ----------
    private static List<String> cats() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        for (Module m : ModuleManager.MODULES) s.add(m.category);
        return new ArrayList<>(s);
    }

    private static List<Module> modsOf(String cat) {
        List<Module> l = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) if (m.category.equals(cat)) l.add(m);
        return l;
    }

    private static String catName(String c) {
        return switch (c) {
            case "Combat" -> "Бой";
            case "Movement" -> "Движение";
            case "Render" -> "Визуалы";
            case "Player" -> "Игрок";
            case "Misc" -> "Прочее";
            default -> c;
        };
    }

    private static int rowH(Setting s) {
        if (s instanceof NumSetting) return 24;
        if (s instanceof BoolSetting) return 17;
        return 18;
    }

    private static int settingsH(Module m) {
        int h = 0;
        for (Setting s : m.settings) if (s.visible.getAsBoolean()) h += rowH(s);
        return h;
    }

    private int cardH(Module m) {
        return 22 + (int) ((settingsH(m) + 4) * expF(m));
    }

    private int contentH(String cat) {
        int[] c = {0, 0};
        for (Module m : modsOf(cat)) {
            int i = c[0] <= c[1] ? 0 : 1;
            c[i] += cardH(m) + 6;
        }
        return Math.max(c[0], c[1]);
    }

    // ---------- геометрия ----------
    private int x0() { return wx + SBW + 10; }
    private int cw() { return winW - SBW - 24; }
    private int colW() { return (cw() - GAP) / 2; }
    private int viewTop() { return wy + HEAD; }
    private int viewBottom() { return wy + winH - FOOT; }
    private int viewH() { return viewBottom() - viewTop(); }
    private int maxScroll() { return Math.max(0, contentH(selCat) + 8 - viewH()); }
    private int footY() { return wy + winH - FOOT; }
    private int swX(int i) { return x0() + 44 + i * 12; }
    private int hueX() { return x0() + 44 + 8 * 12 + 6; }
    private int hueW() { return 78; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        winW = Math.min(404, width - 12);
        winH = Math.min(244, height - 12);
        if (wx == Integer.MIN_VALUE) {
            wx = (width - winW) / 2;
            wy = (height - winH) / 2;
        }
        wx = Mth.clamp(wx, 0, Math.max(0, width - winW));
        wy = Mth.clamp(wy, 0, Math.max(0, height - winH));

        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        k = 1f - (float) Math.exp(-dt * 16f);
        float t = Mth.clamp((now - openStart) / 220e6f, 0f, 1f);
        float ease = 1f - (1f - t) * (1f - t) * (1f - t);
        fa = ease;

        int baseWy = wy;
        wy = baseWy + (int) ((1f - ease) * 14f);
        try {
            draw(g, mx, my);
        } finally {
            wy = baseWy;
        }
    }

    private void draw(GuiGraphics g, int mx, int my) {
        int accent = Theme.accent();
        hits.clear();

        for (Module m : modsOf(selCat)) anim(m, 1, EXPANDED.contains(m) ? 1f : 0f);
        scroll = Mth.clamp(scroll, 0, maxScroll());
        scrollCur += (scroll - scrollCur) * k;
        if (Math.abs(scroll - scrollCur) < 0.4f) scrollCur = scroll;
        catFade += (1f - catFade) * k;
        if (catFade > 0.995f) catFade = 1f;

        g.fill(0, 0, width, height, ((int) (0x70 * fa)) << 24);

        // окно с обводкой цвета клиента
        rnd(g, wx - 1, wy - 1, winW + 2, winH + 2, Draw.alpha(Theme.rgb, 0xB0));
        rnd(g, wx, wy, winW, winH, BG);

        // сайдбар с обводкой
        rnd(g, wx + 5, wy + 5, SBW - 4, winH - 10, BORDER);
        rnd(g, wx + 6, wy + 6, SBW - 6, winH - 12, SIDE);
        txt(g, "PURPLE", wx + 15, wy + 13, accent);
        txt(g, "CLIENT", wx + 15, wy + 23, DIM);
        fill(g, wx + 12, wy + 36, wx + SBW - 6, wy + 37, LINE);
        hits.add(new Hit(wx, wy, SBW, 36, T_TITLE, null, null, null));

        List<String> cs = cats();
        float targetRel = 44 + cs.indexOf(selCat) * 26;
        pillRel = Float.isNaN(pillRel) ? targetRel : pillRel + (targetRel - pillRel) * k;
        int py = wy + Math.round(pillRel);
        rnd(g, wx + 10, py, SBW - 14, 22, Draw.alpha(Theme.rgb, 0x90));
        rnd(g, wx + 11, py + 1, SBW - 16, 20, lerpColor(0xFF15151B, accent, 0.16f));

        int cy = wy + 44;
        for (String c : cs) {
            boolean sel = c.equals(selCat);
            rnd(g, wx + 17, cy + 5, 12, 12, sel ? accent : 0xFF2A2A34);
            txt(g, catName(c).substring(0, 1), wx + 20, cy + 7, 0xFF0E0E13);
            txt(g, catName(c), wx + 35, cy + 7, sel ? TXT : DIM);
            hits.add(new Hit(wx + 8, cy, SBW - 12, 22, T_CAT, c, null, null));
            cy += 26;
        }

        // шапка контента
        int enabled = 0, total = 0;
        for (Module m : modsOf(selCat)) { total++; if (m.isEnabled()) enabled++; }
        txt(g, catName(selCat), x0(), wy + 9, TXT);
        String cnt = enabled + "/" + total;
        txt(g, cnt, wx + winW - 30 - font.width(cnt), wy + 9, DIM);
        boolean hc = mx >= wx + winW - 20 && mx <= wx + winW - 4 && my >= wy + 4 && my <= wy + 20;
        txt(g, "x", wx + winW - 14, wy + 9, hc ? accent : DIM);
        hits.add(new Hit(wx + SBW, wy, winW - SBW - 24, HEAD, T_TITLE, null, null, null));
        hits.add(new Hit(wx + winW - 20, wy + 4, 16, 16, T_CLOSE, null, null, null));
        fill(g, wx + SBW + 8, wy + HEAD - 1, wx + winW - 8, wy + HEAD, LINE);

        // карточки модулей: две колонки
        int top = viewTop(), bottom = viewBottom();
        int colW = colW();
        int[] cyCol = {0, 0};
        g.enableScissor(wx + SBW, top, wx + winW - 2, bottom);
        int base = top + 6 - Math.round(scrollCur) + (int) ((1f - catFade) * 10f);
        for (Module m : modsOf(selCat)) {
            int ci = cyCol[0] <= cyCol[1] ? 0 : 1;
            int x = x0() + ci * (colW + GAP);
            int y = base + cyCol[ci];
            float ex = expF(m);
            boolean open = EXPANDED.contains(m);
            int ch = cardH(m);
            cyCol[ci] += ch + 6;

            boolean hov = mx >= x && mx <= x + colW && my >= y && my <= y + 22 && my >= top && my <= bottom;
            float hv = anim(m, 2, hov ? 1f : 0f);
            float tg = anim(m, 0, m.isEnabled() ? 1f : 0f);

            // обводка карточки: серая, при наведении светлее, у включённого цвета клиента
            int border = lerpColor(lerpColor(BORDER, 0xFF3A3A48, hv), Draw.alpha(Theme.rgb, 0xC0) | 0, tg);
            rnd(g, x - 1, y - 1, colW + 2, ch + 2, border);
            int body = lerpColor(CARD, CARD_HOVER, hv);
            if (ex > 0f) body = lerpColor(body, CARD2, ex);
            rnd(g, x, y, colW, ch, body);

            if (!m.settings.isEmpty()) txt(g, ex > 0.5f ? "v" : ">", x + 7, y + 7, DIM);
            String title = font.plainSubstrByWidth(m.name, colW - 18 - 34);
            txt(g, title, x + 18, y + 7, lerpColor(DIM, TXT, tg));
            drawSwitch(g, x + colW - 26, y + 6, 18, 10, tg, accent);
            hits.add(new Hit(x, y, 18, 22, T_ARROW, null, m, null));
            hits.add(new Hit(x + 18, y, colW - 18, 22, T_TOGGLE, null, m, null));

            if (ex > 0.02f) {
                g.enableScissor(x, y, x + colW, y + ch);
                boolean live = open && ex > 0.95f;
                int sy = y + 24;
                int lx = x + 9, rx = x + colW - 9;
                for (Setting s : m.settings) {
                    if (!s.visible.getAsBoolean()) continue;
                    int rh = rowH(s);
                    if (s instanceof BoolSetting b) {
                        float bt = anim(b, 0, b.value ? 1f : 0f);
                        txt(g, font.plainSubstrByWidth(b.name, rx - lx - 22), lx, sy + 4, lerpColor(DIM, TXT, bt));
                        drawSwitch(g, rx - 15, sy + 4, 15, 8, bt, accent);
                    } else if (s instanceof NumSetting n) {
                        String v = trim(n.value);
                        txt(g, font.plainSubstrByWidth(n.name, rx - lx - font.width(v) - 6), lx, sy + 3, DIM);
                        txt(g, v, rx - font.width(v), sy + 3, TXT);
                        double frac = (n.value - n.min) / (n.max - n.min);
                        float shown = anim(n, 3, (float) frac);
                        int tw = rx - lx;
                        fill(g, lx, sy + 16, lx + tw, sy + 18, TRACK);
                        fill(g, lx, sy + 16, lx + (int) (tw * shown), sy + 18, accent);
                        int kx = lx + (int) (tw * shown);
                        fill(g, kx - 1, sy + 14, kx + 2, sy + 20, 0xFFFFFFFF);
                    } else if (s instanceof ModeSetting ms) {
                        String v = ms.get();
                        int pw = Math.min(font.width(v) + 10, (rx - lx) / 2 + 12);
                        txt(g, font.plainSubstrByWidth(ms.name, rx - lx - pw - 4), lx, sy + 5, DIM);
                        rnd(g, rx - pw, sy + 2, pw, 13, Draw.alpha(Theme.rgb, 0x40));
                        txt(g, font.plainSubstrByWidth(v, pw - 8), rx - pw + 5, sy + 5, accent);
                    } else if (s instanceof KeySetting ks) {
                        String v = ks == listening ? "..." : ks.display();
                        int pw = Math.min(font.width(v) + 10, (rx - lx) / 2 + 12);
                        txt(g, font.plainSubstrByWidth(ks.name, rx - lx - pw - 4), lx, sy + 5, DIM);
                        rnd(g, rx - pw, sy + 2, pw, 13, ks == listening ? Draw.alpha(Theme.rgb, 0x80) : TRACK);
                        txt(g, font.plainSubstrByWidth(v, pw - 8), rx - pw + 5, sy + 5, TXT);
                    }
                    if (live) hits.add(new Hit(x + 4, sy, colW - 8, rh, T_SET, null, m, s));
                    sy += rh;
                }
                g.disableScissor();
            }
        }
        g.disableScissor();

        // полоса прокрутки
        if (maxScroll() > 0) {
            int sx = wx + winW - 9;
            fill(g, sx, top + 4, sx + 3, bottom - 4, TRACK);
            int vh = viewH() - 8;
            int th = Math.max(12, vh * viewH() / (contentH(selCat) + 8));
            int ty = top + 4 + (int) ((vh - th) * (scrollCur / (double) maxScroll()));
            fill(g, sx, ty, sx + 3, ty + th, accent);
        }

        // подвал: цвет клиента
        fill(g, wx + SBW + 8, footY(), wx + winW - 8, footY() + 1, LINE);
        txt(g, "Цвет", x0(), footY() + 9, DIM);
        for (int i = 0; i < PRESETS.length; i++) {
            int sx = swX(i), sy = footY() + 7;
            rnd(g, sx, sy, 10, 10, 0xFF000000 | PRESETS[i]);
            if ((PRESETS[i] & 0xFFFFFF) == Theme.rgb) {
                fill(g, sx - 1, sy - 1, sx + 11, sy, 0xFFFFFFFF);
                fill(g, sx - 1, sy + 10, sx + 11, sy + 11, 0xFFFFFFFF);
                fill(g, sx - 1, sy, sx, sy + 10, 0xFFFFFFFF);
                fill(g, sx + 10, sy, sx + 11, sy + 10, 0xFFFFFFFF);
            }
        }
        int hx = hueX(), hy = footY() + 9;
        for (int i = 0; i < hueW(); i++) {
            fill(g, hx + i, hy, hx + i + 1, hy + 6,
                    0xFF000000 | (Mth.hsvToRgb(i / (float) hueW(), 0.7f, 1f) & 0xFFFFFF));
        }
        int mk = hx + (int) (Theme.hue * (hueW() - 1));
        fill(g, mk, hy - 2, mk + 1, hy + 8, 0xFFFFFFFF);
    }

    private void drawSwitch(GuiGraphics g, int x, int y, int w, int h, float t, int accent) {
        rnd(g, x, y, w, h, lerpColor(TRACK, Draw.alpha(Theme.rgb, 0xA0), t));
        int kx = x + 1 + Math.round((w - h) * t);
        fill(g, kx, y + 1, kx + h - 2, y + h - 1, lerpColor(0xFF6A6A78, accent, t));
    }

    private static String trim(double v) {
        return v == Math.rint(v) ? String.valueOf((int) v) : String.format("%.2f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private void setHueFrom(double mx) {
        Theme.setHue((float) ((mx - hueX()) / (double) (hueW() - 1)));
    }

    private void setScrollFrom(double my) {
        double frac = Mth.clamp((my - viewTop()) / (double) viewH(), 0.0, 1.0);
        scroll = (int) (frac * maxScroll());
    }

    private void updateSlider(double mx) {
        NumSetting n = (NumSetting) slider.setting();
        int lx = slider.x() + 5, tw = slider.w() - 10;
        double frac = Mth.clamp((mx - lx) / tw, 0.0, 1.0);
        n.set(n.min + frac * (n.max - n.min));
    }

    private boolean inView(double my) { return my >= viewTop() && my <= viewBottom(); }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        listening = null;

        for (int i = 0; i < PRESETS.length; i++) {
            int sx = swX(i), sy = footY() + 7;
            if (mx >= sx && mx <= sx + 10 && my >= sy && my <= sy + 10) {
                Theme.setRgb(PRESETS[i]);
                colorChanged = true;
                return true;
            }
        }
        if (mx >= hueX() - 2 && mx <= hueX() + hueW() + 2 && my >= footY() + 6 && my <= footY() + 18) {
            hueDrag = true;
            colorChanged = true;
            setHueFrom(mx);
            return true;
        }
        if (maxScroll() > 0 && mx >= wx + winW - 16 && mx <= wx + winW && inView(my)) {
            sbDrag = true;
            setScrollFrom(my);
            return true;
        }

        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            switch (h.type()) {
                case T_CLOSE -> { onClose(); return true; }
                case T_TITLE -> {
                    dragWin = true;
                    dragDX = (int) mx - wx;
                    dragDY = (int) my - wy;
                    return true;
                }
                case T_CAT -> {
                    if (!h.cat().equals(selCat)) {
                        selCat = h.cat();
                        scroll = 0;
                        scrollCur = 0;
                        catFade = 0f;
                    }
                    return true;
                }
                case T_ARROW -> {
                    if (!inView(my)) continue;
                    if (!h.module().settings.isEmpty() && !EXPANDED.remove(h.module())) EXPANDED.add(h.module());
                    return true;
                }
                case T_TOGGLE -> {
                    if (!inView(my)) continue;
                    if (button == 1) {
                        if (!h.module().settings.isEmpty() && !EXPANDED.remove(h.module())) EXPANDED.add(h.module());
                    } else {
                        h.module().toggle();
                    }
                    return true;
                }
                case T_SET -> {
                    if (!inView(my)) continue;
                    Setting s = h.setting();
                    if (s instanceof BoolSetting b) {
                        b.value = !b.value;
                    } else if (s instanceof ModeSetting ms) {
                        ms.next();
                    } else if (s instanceof KeySetting ks) {
                        listening = ks;
                    } else if (s instanceof NumSetting) {
                        slider = h;
                        updateSlider(mx);
                    }
                    return true;
                }
                default -> { }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (hueDrag) { setHueFrom(mx); return true; }
        if (sbDrag) { setScrollFrom(my); return true; }
        if (dragWin) {
            wx = (int) mx - dragDX;
            wy = (int) my - dragDY;
            return true;
        }
        if (slider != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (colorChanged) {
            Config.save();
            colorChanged = false;
        }
        dragWin = false;
        hueDrag = false;
        sbDrag = false;
        slider = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (mx >= wx + SBW && inView(my)) {
            scroll = Mth.clamp(scroll - (int) (scrollY * 16), 0, maxScroll());
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (listening != null) {
            listening.key = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            listening = null;
            Config.save();
            return true;
        }
        if (key == GLFW.GLFW_KEY_Y) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        listening = null;
        super.onClose();
    }
}
