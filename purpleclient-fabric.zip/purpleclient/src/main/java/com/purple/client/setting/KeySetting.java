package com.purple.client.setting;

import com.mojang.blaze3d.platform.InputConstants;

public class KeySetting extends Setting {
    public int key = -1;

    public KeySetting(String name) { super(name); }

    public String display() {
        if (key == -1) return "Нет";
        try {
            return InputConstants.Type.KEYSYM.getOrCreate(key).getDisplayName().getString().toUpperCase();
        } catch (Throwable t) {
            return "K" + key;
        }
    }
}
