package com.purple.client.module;

import com.purple.client.setting.NumSetting;
import com.purple.client.util.Commands;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.HashMap;
import java.util.Map;

/** Показывает в чате, какой тотем потерял соперник (название и зачарован ли) и сколько тотемов он уже потерял. */
public class TotemTracker extends Module {
    private final NumSetting range = new NumSetting("Дальность", 64, 8, 128, 8);

    private static class State {
        int count, pending, pops;
        ItemStack totem = ItemStack.EMPTY, popped = ItemStack.EMPTY;
    }

    private final Map<Integer, State> states = new HashMap<>();

    public TotemTracker() {
        super("TotemTracker", "Misc");
        settings.add(range);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        for (Player pl : mc.level.players()) {
            if (pl == mc.player || mc.player.distanceTo(pl) > range.value) continue;
            State s = states.computeIfAbsent(pl.getId(), k -> new State());

            ItemStack main = pl.getMainHandItem(), off = pl.getOffhandItem();
            int cnt = (main.is(Items.TOTEM_OF_UNDYING) ? main.getCount() : 0)
                    + (off.is(Items.TOTEM_OF_UNDYING) ? off.getCount() : 0);
            ItemStack cur = main.is(Items.TOTEM_OF_UNDYING) ? main : (off.is(Items.TOTEM_OF_UNDYING) ? off : ItemStack.EMPTY);

            if (cnt < s.count && !s.totem.isEmpty()) {
                s.pending = 4;
                s.popped = s.totem.copy();
            }
            if (s.pending > 0) {
                s.pending--;
                // после сноса тотема здоровье становится 1.0; если игрок просто убрал тотем, оно останется высоким
                if (pl.getHealth() <= 2.0f || pl.isDeadOrDying()) {
                    s.pops++;
                    String kind = s.popped.hasFoil() ? "зачарованный" : "обычный";
                    Commands.msg("§d[Totem] §f" + pl.getName().getString() + " §7потерял тотем §e"
                            + s.popped.getHoverName().getString() + " §7(" + kind + ") §8#" + s.pops);
                    s.pending = 0;
                }
            }
            if (!cur.isEmpty()) s.totem = cur.copy();
            s.count = cnt;
        }
    }
}
