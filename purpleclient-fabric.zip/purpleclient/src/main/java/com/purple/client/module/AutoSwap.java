package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.KeySetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.util.Commands;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Как в обычных читах: выбираете два предмета и клавишу, по нажатию предмет в левой руке
 * меняется между ними (предметы берутся и из инвентаря).
 */
public class AutoSwap extends Module {
    private static final String[] NAMES = {"Тотем", "Яблоко", "Щит", "Шар"};

    private final ModeSetting first = new ModeSetting("Предмет 1", 0, NAMES);
    private final ModeSetting second = new ModeSetting("Предмет 2", 2, NAMES);
    private final KeySetting key = new KeySetting("Бинд");
    private final ModeSetting ballType = new ModeSetting("Предмет шара", 0, "Огн. шар", "Снежок", "Эндер-жемчуг");
    private final BoolSetting messages = new BoolSetting("Сообщения", false);

    public AutoSwap() {
        super("AutoSwap", "Player");
        settings.add(first);
        settings.add(second);
        settings.add(key);
        settings.add(ballType);
        settings.add(messages);
    }

    private Item[] items(int kind) {
        return switch (kind) {
            case 0 -> new Item[]{Items.TOTEM_OF_UNDYING};
            case 1 -> new Item[]{Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE};
            case 2 -> new Item[]{Items.SHIELD};
            default -> new Item[]{switch (ballType.index) {
                case 1 -> Items.SNOWBALL;
                case 2 -> Items.ENDER_PEARL;
                default -> Items.FIRE_CHARGE;
            }};
        };
    }

    private boolean matches(ItemStack s, int kind) {
        for (Item i : items(kind)) if (s.is(i)) return true;
        return false;
    }

    private int findSlot(LocalPlayer p, int kind) {
        for (int i = 0; i < 9; i++) if (matches(p.getInventory().getItem(i), kind)) return 36 + i;
        for (int i = 9; i < 36; i++) if (matches(p.getInventory().getItem(i), kind)) return i;
        return -1;
    }

    private boolean swapTo(Minecraft mc, LocalPlayer p, int kind) {
        int slot = findSlot(p, kind);
        if (slot == -1) return false;
        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
        if (messages.value) Commands.msg("AutoSwap: " + NAMES[kind]);
        return true;
    }

    @Override
    public void onKey(int k) {
        if (key.key == -1 || k != key.key) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null || p.containerMenu != p.inventoryMenu) return;

        int a = first.index, b = second.index;
        if (a == b) return;
        ItemStack off = p.getOffhandItem();
        int want = matches(off, a) ? b : a;
        int other = want == a ? b : a;
        if (!swapTo(mc, p, want) && !matches(off, other)) {
            if (!swapTo(mc, p, other) && messages.value) Commands.msg("AutoSwap: нет предметов");
        }
    }
}
