package com.purple.client.module;

import com.purple.client.setting.NumSetting;
import com.purple.client.util.Combat;
import com.purple.client.util.Commands;
import net.minecraft.client.Minecraft;

/** Тестовая функция: после убийства игрока пишет в чат ваш текст. Текст: .ezz <текст> ({name} = ник). */
public class AutoEzz extends Module {
    public static String message = "ez {name}";

    private final NumSetting cooldown = new NumSetting("Кулдаун (сек)", 3, 0, 30, 1);
    private long lastSent = -1000;

    public AutoEzz() {
        super("AutoEzz", "Player");
        settings.add(cooldown);
    }

    public static void send(String name) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getConnection() == null) return;
        mc.getConnection().sendChat(message.replace("{name}", name));
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Combat.get(); // обновляет состояние цели и фиксирует убийство
        String killed = Combat.pollKill();
        if (killed == null) return;
        long now = mc.level.getGameTime();
        if (now - lastSent < cooldown.value * 20) return;
        lastSent = now;
        send(killed);
        Commands.msg("AutoEzz: убит " + killed);
    }

    @Override
    public void onDisable() {
        Combat.pollKill();
    }
}
