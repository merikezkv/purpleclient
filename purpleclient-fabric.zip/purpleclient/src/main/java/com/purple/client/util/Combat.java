package com.purple.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;

/** Текущая цель, которую бьёт игрок / AttackAura / TriggerBot. */
public final class Combat {
    private static LivingEntity target;
    private static long time;
    private static String pendingKill;

    private Combat() {}

    public static void set(LivingEntity e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        target = e;
        time = mc.level.getGameTime();
    }

    public static LivingEntity get() {
        Minecraft mc = Minecraft.getInstance();
        if (target == null || mc.level == null) return null;
        long age = mc.level.getGameTime() - time;
        if (!target.isAlive()) {
            if (target instanceof Player pl && pl.isDeadOrDying() && age <= 60) {
                pendingKill = pl.getName().getString();
            }
            target = null;
            return null;
        }
        if (age > 60) {
            target = null;
            return null;
        }
        return target;
    }

    /** Ник игрока, которого только что убили (один раз), либо null. */
    public static String pollKill() {
        String s = pendingKill;
        pendingKill = null;
        return s;
    }

    /** Ручные удары: если держим ЛКМ и смотрим на живое существо, оно становится целью. */
    public static void trackManual(Minecraft mc) {
        if (mc.player == null || mc.screen != null || !mc.options.keyAttack.isDown()) return;
        if (mc.hitResult instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity le && le != mc.player) {
            set(le);
        }
    }
}
