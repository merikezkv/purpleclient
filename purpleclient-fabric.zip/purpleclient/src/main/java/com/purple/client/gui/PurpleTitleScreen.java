package com.purple.client.gui;

import com.mojang.blaze3d.vertex.PoseStack;
import com.purple.client.PurpleClient;
import com.purple.client.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.TitleScreen;

/**
 * Главное меню в стиле клиента. Наследуется от ванильного TitleScreen, поэтому все кнопки
 * (одиночная игра, сетевая игра, настройки, выход) работают как обычно, меняется только вид.
 */
public class PurpleTitleScreen extends TitleScreen {
    private final long start = System.nanoTime();

    public PurpleTitleScreen() {
        super();
    }

    private static double hash(int i, int k) {
        double x = Math.sin(i * 12.9898 + k * 78.233) * 43758.5453;
        return x - Math.floor(x);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        double t = (System.nanoTime() - start) / 1e9;
        int accent = Theme.accent();
        Font f = Minecraft.getInstance().font;

        // фон: вертикальный градиент и мерцающие частицы
        g.fillGradient(0, 0, width, height, 0xFF0A0912, 0xFF1A1030);
        for (int i = 0; i < 80; i++) {
            double sx = hash(i, 1) * width;
            double sy = (hash(i, 2) * height + t * (5 + hash(i, 3) * 16)) % height;
            int a = (int) (50 + 110 * (0.5 + 0.5 * Math.sin(t * 1.4 + i)));
            int s = hash(i, 4) > 0.82 ? 2 : 1;
            g.fill((int) sx, (int) sy, (int) sx + s, (int) sy + s, Draw.alpha(Theme.rgb, a));
        }

        // мягкое свечение за заголовком
        int cx = width / 2, ty = Math.max(14, height / 4 - 14);
        for (int i = 0; i < 9; i++) {
            Draw.round(g, cx - 130 - i * 7, ty - 10 - i * 3, 260 + i * 14, 46 + i * 6, Draw.alpha(Theme.rgb, 9));
        }

        // заголовок (масштаб x3)
        PoseStack ps = g.pose();
        ps.pushPose();
        try {
            String a = "PURPLE", b = "CLIENT";
            int wa = f.width(a), wb = f.width(b);
            float scale = 3f;
            ps.translate(cx, ty, 0);
            ps.scale(scale, scale, 1f);
            int totalW = wa + wb + 6;
            g.drawString(f, a, -totalW / 2, 0, 0xFFFFFFFF, false);
            g.drawString(f, b, -totalW / 2 + wa + 6, 0, accent, false);
        } finally {
            ps.popPose();
        }
        String sub = "Purple Client " + PurpleClient.VERSION + "  |  Minecraft 1.21.4";
        g.drawString(f, sub, cx - f.width(sub) / 2, ty + 32, 0xFF9A9AAA, false);
        for (int i = 0; i < 120; i += 2) {
            double u = Math.sin(t * 1.2 + i * 0.05);
            g.fill(cx - 60 + i, ty + 44, cx - 58 + i, ty + 45, Draw.alpha(Theme.rgb, (int) (130 + 100 * u)));
        }

        // кнопки (ванильные; рисуются в нашем стиле через миксин)
        for (GuiEventListener c : children()) {
            if (c instanceof Renderable r) r.render(g, mx, my, pt);
        }
    }
}
