package com.purple.client.setting;

import java.util.function.BooleanSupplier;

public abstract class Setting {
    public final String name;
    /** Настройка показывается в меню, только если условие истинно. */
    public BooleanSupplier visible = () -> true;

    protected Setting(String name) { this.name = name; }

    public Setting showIf(BooleanSupplier condition) {
        this.visible = condition;
        return this;
    }
}
