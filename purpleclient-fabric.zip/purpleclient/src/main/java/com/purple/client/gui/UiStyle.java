package com.purple.client.gui;

import com.purple.client.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.SpriteIconButton;

/** Единый стиль кнопок Minecraft: тёмные скруглённые кнопки с обводкой цвета клиента при наведении. */
public final class UiStyle {
    private UiStyle() {}

    public static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    /** @return true, если кнопка нарисована в нашем стиле (иначе рисует ваниль: иконки и пустые кнопки). */
    public static boolean drawButton(GuiGraphics g, AbstractButton b) {
        if (b instanceof ImageButton || b instanceof SpriteIconButton) return false;
        String msg = b.getMessage().getString();
        if (msg == null || msg.isEmpty()) return false;

        Font f = Minecraft.getInstance().font;
        int x = b.getX(), y = b.getY(), w = b.getWidth(), h = b.getHeight();
        boolean hover = b.isHoveredOrFocused() && b.active;
        int accent = Theme.accent();

        int outline = hover ? accent : (b.active ? 0xFF2E2E3A : 0xFF22222B);
        int body = hover ? mix(0xFF15151C, accent, 0.20f) : (b.active ? 0xFF15151C : 0xFF111116);
        Draw.round(g, x, y, w, h, outline);
        Draw.round(g, x + 1, y + 1, w - 2, h - 2, body);

        String text = f.plainSubstrByWidth(msg, w - 8);
        int color = hover ? 0xFFFFFFFF : (b.active ? 0xFFD8D8E4 : 0xFF6A6A78);
        g.drawString(f, text, x + (w - f.width(text)) / 2, y + (h - 8) / 2, color, false);
        return true;
    }
}
