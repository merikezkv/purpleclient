package com.purple.client.util;

import com.purple.client.gui.Theme;
import com.purple.client.module.AutoEzz;
import com.purple.client.module.HUD;
import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.setting.KeySetting;
import com.purple.client.setting.Setting;
import net.minecraft.client.Minecraft;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/** Сохраняет цвет, друзей, бинды, позицию HUD и текст AutoEzz в purpleclient.properties. */
public final class Config {
    private static boolean started, ready;
    private Config() {}

    private static File file() {
        return new File(Minecraft.getInstance().gameDirectory, "purpleclient.properties");
    }

    public static void loadOnce() {
        if (started) return;
        started = true;
        try {
            File f = file();
            if (!f.exists()) {
                // первый запуск: сразу включаем HUD и ESP
                ModuleManager.hud.setEnabled(true);
                for (Module m : ModuleManager.MODULES) if (m.name.equals("ESP")) m.setEnabled(true);
                return;
            }
            Properties pr = new Properties();
            try (Reader r = new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8)) {
                pr.load(r);
            }
            String c = pr.getProperty("color");
            if (c != null) Theme.setRgb(Integer.parseInt(c, 16));
            String fr = pr.getProperty("friends");
            if (fr != null && !fr.isBlank()) for (String n : fr.split(",")) if (!n.isBlank()) Friends.add(n.trim());
            for (HUD.Elem el : HUD.ELEMS) {
                String ex = pr.getProperty("hud." + el.id + ".x"), ey = pr.getProperty("hud." + el.id + ".y");
                if (ex != null) el.x = Integer.parseInt(ex);
                if (ey != null) el.y = Integer.parseInt(ey);
            }
            String ez = pr.getProperty("ezz");
            if (ez != null) AutoEzz.message = ez;
            for (Module m : ModuleManager.MODULES) {
                String b = pr.getProperty("bind." + m.name);
                if (b != null) Commands.applyBind(m, b);
                String on = pr.getProperty("on." + m.name);
                if (on != null) m.setEnabled(Boolean.parseBoolean(on));
                for (Setting s : m.settings) {
                    if (s instanceof KeySetting ks) {
                        String k = pr.getProperty("ks." + m.name + "." + ks.name);
                        if (k != null) ks.key = Integer.parseInt(k);
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            ready = true;
        }
    }

    public static void save() {
        if (!ready) return;
        try {
            Properties pr = new Properties();
            pr.setProperty("color", String.format("%06X", Theme.rgb));
            pr.setProperty("friends", String.join(",", Friends.list()));
            for (HUD.Elem el : HUD.ELEMS) {
                pr.setProperty("hud." + el.id + ".x", String.valueOf(el.x));
                pr.setProperty("hud." + el.id + ".y", String.valueOf(el.y));
            }
            pr.setProperty("ezz", AutoEzz.message);
            for (Module m : ModuleManager.MODULES) {
                pr.setProperty("on." + m.name, String.valueOf(m.isEnabled()));
                if (m.bindKey != -1 && m.bindName != null) pr.setProperty("bind." + m.name, m.bindName);
                for (Setting s : m.settings) {
                    if (s instanceof KeySetting ks && ks.key != -1) {
                        pr.setProperty("ks." + m.name + "." + ks.name, String.valueOf(ks.key));
                    }
                }
            }
            try (Writer w = new OutputStreamWriter(new FileOutputStream(file()), StandardCharsets.UTF_8)) {
                pr.store(w, "Purple Client");
            }
        } catch (Exception ignored) {
        }
    }
}
