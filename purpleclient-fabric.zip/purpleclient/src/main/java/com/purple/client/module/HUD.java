package com.purple.client.module;

import com.purple.client.PurpleClient;
import com.purple.client.gui.Theme;
import com.purple.client.setting.BoolSetting;
import com.purple.client.util.Combat;
import com.purple.client.util.Config;
import com.purple.client.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * HUD в стиле современных клиентов: ватермарка с логотипом, анимированный список модулей с градиентом,
 * панели "Цель", "Инфо", "Эффекты", "Бинды" (перетаскиваются мышью при открытом чате), броня над хотбаром.
 */
public class HUD extends Module {
    public static class Elem {
        public final String id;
        public int x, y, w = 110, h = 30;
        Elem(String id, int x, int y) { this.id = id; this.x = x; this.y = y; }
    }

    public static final Elem TARGET = new Elem("target", 6, 34);
    public static final Elem INFO = new Elem("info", 6, 92);
    public static final Elem EFFECTS = new Elem("effects", 6, 126);
    public static final Elem BINDS = new Elem("binds", 6, 190);
    public static final List<Elem> ELEMS = List.of(TARGET, INFO, EFFECTS, BINDS);

    private final BoolSetting watermark = new BoolSetting("Ватермарка", true);
    private final BoolSetting list = new BoolSetting("Список модулей", true);
    private final BoolSetting target = new BoolSetting("Цель", true);
    private final BoolSetting info = new BoolSetting("Информация", true);
    private final BoolSetting effects = new BoolSetting("Эффекты", true);
    private final BoolSetting binds = new BoolSetting("Бинды", true);
    private final BoolSetting armor = new BoolSetting("Броня", true);

    private final Map<Module, Float> listAnim = new HashMap<>();
    private static long lastNs = System.nanoTime();
    private static Elem grabbed;
    private static int dragDX, dragDY;
    private static boolean wasDown;
    private float shownHp = -1f, bps;
    private LivingEntity lastTarget;

    public HUD() {
        super("HUD", "Misc");
        settings.add(watermark);
        settings.add(list);
        settings.add(target);
        settings.add(info);
        settings.add(effects);
        settings.add(binds);
        settings.add(armor);
    }

    // ---------- вспомогательное ----------
    /** Градиентный цвет на основе цвета клиента (мерцает от основного к светлому оттенку). */
    private static int grad(double phase) {
        double t = (Math.sin(System.currentTimeMillis() / 700.0 + phase) + 1) / 2;
        int c = Theme.rgb;
        int r = (c >> 16) & 255, gg = (c >> 8) & 255, b = c & 255;
        int r2 = (int) (r + (255 - r) * 0.55), g2 = (int) (gg + (255 - gg) * 0.55), b2 = (int) (b + (255 - b) * 0.55);
        return 0xFF000000 | ((int) (r + (r2 - r) * t) << 16) | ((int) (gg + (g2 - gg) * t) << 8) | (int) (b + (b2 - b) * t);
    }

    private void panel(GuiGraphics g, Elem e, String title) {
        Draw.round(g, e.x, e.y, e.w, e.h, 0xC00F0F14);
        for (int i = 0; i < e.w - 8; i += 2) g.fill(e.x + 4 + i, e.y + 1, e.x + 6 + i, e.y + 2, grad(i * 0.03));
        if (title != null) g.drawString(Minecraft.getInstance().font, title, e.x + 6, e.y + 5, grad(0), false);
    }

    private void handleDrag(Minecraft mc, int w, int h) {
        if (!(mc.screen instanceof ChatScreen)) {
            grabbed = null;
            wasDown = false;
            return;
        }
        double mx = mc.mouseHandler.xpos() * w / (double) mc.getWindow().getScreenWidth();
        double my = mc.mouseHandler.ypos() * h / (double) mc.getWindow().getScreenHeight();
        boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !wasDown) {
            for (int i = ELEMS.size() - 1; i >= 0; i--) {
                Elem e = ELEMS.get(i);
                if (mx >= e.x && mx <= e.x + e.w && my >= e.y && my <= e.y + e.h) {
                    grabbed = e;
                    dragDX = (int) mx - e.x;
                    dragDY = (int) my - e.y;
                    break;
                }
            }
        }
        if (!down && grabbed != null) {
            grabbed = null;
            Config.save();
        }
        if (grabbed != null) {
            grabbed.x = Mth.clamp((int) mx - dragDX, 0, Math.max(0, w - grabbed.w));
            grabbed.y = Mth.clamp((int) my - dragDY, 0, Math.max(0, h - grabbed.h));
        }
        wasDown = down;
    }

    // ---------- отрисовка ----------
    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;

        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        float k = 1f - (float) Math.exp(-dt * 12f);

        for (Elem e : ELEMS) {
            e.x = Mth.clamp(e.x, 0, Math.max(0, w - 20));
            e.y = Mth.clamp(e.y, 0, Math.max(0, h - 20));
        }
        handleDrag(mc, w, h);
        boolean chat = mc.screen instanceof ChatScreen;

        if (watermark.value) drawWatermark(g, mc, p);
        if (list.value) drawList(g, mc, w, k);
        if (armor.value) drawArmor(g, mc, p, w, h);
        if (info.value) drawInfo(g, mc, p, k);
        if (effects.value) drawEffects(g, mc, p, chat);
        if (binds.value) drawBinds(g, mc, chat);
        if (target.value) drawTarget(g, mc, p, chat, k);
    }

    private void drawWatermark(GuiGraphics g, Minecraft mc, LocalPlayer p) {
        Font f = mc.font;
        String a = "Purple", b = "Client " + PurpleClient.VERSION;
        String right = p.getName().getString() + "   " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        int w = 6 + 12 + 6 + f.width(a) + f.width(b) + 10 + f.width(right) + 8;
        Draw.round(g, 6, 6, w, 18, 0xC00F0F14);
        Draw.round(g, 9, 9, 12, 12, Theme.accent());
        g.drawString(f, "P", 13, 11, 0xFF0F0F14, false);
        g.drawString(f, a, 27, 11, 0xFFFFFFFF, false);
        g.drawString(f, b, 27 + f.width(a), 11, Theme.accent(), false);
        g.fill(27 + f.width(a) + f.width(b) + 5, 10, 28 + f.width(a) + f.width(b) + 5, 20, 0xFF3A3A44);
        g.drawString(f, right, 27 + f.width(a) + f.width(b) + 10, 11, 0xFFB5B5C2, false);
        for (int i = 0; i < w - 8; i += 2) g.fill(10 + i, 22, 12 + i, 23, grad(i * 0.04));
    }

    private void drawList(GuiGraphics g, Minecraft mc, int w, float k) {
        Font f = mc.font;
        List<Module> vis = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) {
            if (m == this) continue;
            float tgt = m.isEnabled() ? 1f : 0f;
            float a = listAnim.getOrDefault(m, tgt);
            a += (tgt - a) * k;
            if (Math.abs(tgt - a) < 0.01f) a = tgt;
            listAnim.put(m, a);
            if (a > 0.02f) vis.add(m);
        }
        vis.sort((x, y) -> Integer.compare(f.width(y.name), f.width(x.name)));

        int y = 6, idx = 0;
        for (Module m : vis) {
            float a = listAnim.get(m);
            int bw = f.width(m.name) + 12;
            int x = w - bw - 4 + (int) ((1f - a) * (bw + 8));
            int col = grad(idx * 0.55);
            Draw.round(g, x, y, bw, 11, Draw.alpha(0x0F0F14, (int) (0xC0 * a)));
            g.fill(x + bw - 2, y + 1, x + bw, y + 10, Draw.alpha(col, (int) (255 * a)));
            if (a > 0.15f) g.drawString(f, m.name, x + 5, y + 2, Draw.alpha(col, (int) (255 * a)), false);
            y += Math.max(1, (int) (12 * a));
            idx++;
        }
    }

    private void drawArmor(GuiGraphics g, Minecraft mc, LocalPlayer p, int w, int h) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        boolean any = false;
        for (EquipmentSlot s : slots) if (!p.getItemBySlot(s).isEmpty()) any = true;
        if (!any) return;
        int x0 = w / 2 - 36, y = h - 76;
        Draw.round(g, x0 - 4, y - 4, 80, 24, 0xC00F0F14);
        for (int i = 0; i < 4; i++) {
            ItemStack s = p.getItemBySlot(slots[i]);
            if (s.isEmpty()) continue;
            g.renderItem(s, x0 + i * 18, y);
            g.renderItemDecorations(mc.font, s, x0 + i * 18, y);
        }
    }

    private void drawInfo(GuiGraphics g, Minecraft mc, LocalPlayer p, float k) {
        Font f = mc.font;
        double sp = Math.hypot(p.getX() - p.xo, p.getZ() - p.zo) * 20.0;
        bps += (float) ((sp - bps) * k);
        String l1 = String.format("XYZ  %d  %d  %d", (int) Math.floor(p.getX()), (int) Math.floor(p.getY()), (int) Math.floor(p.getZ()));
        String l2 = String.format("BPS  %.1f", bps);
        Elem e = INFO;
        e.w = Math.max(f.width(l1), f.width(l2)) + 14;
        e.h = 30;
        panel(g, e, null);
        g.drawString(f, l1, e.x + 7, e.y + 6, 0xFFE6E6F0, false);
        g.drawString(f, l2, e.x + 7, e.y + 17, grad(1.0), false);
    }

    private void drawEffects(GuiGraphics g, Minecraft mc, LocalPlayer p, boolean chat) {
        Font f = mc.font;
        List<String> rows = new ArrayList<>();
        for (MobEffectInstance inst : p.getActiveEffects()) {
            String name = Component.translatable(inst.getDescriptionId()).getString();
            if (inst.getAmplifier() > 0) name += " " + (inst.getAmplifier() + 1);
            String time;
            if (inst.isInfiniteDuration()) {
                time = "∞";
            } else {
                int s = inst.getDuration() / 20;
                time = String.format("%d:%02d", s / 60, s % 60);
            }
            rows.add(name + "  " + time);
        }
        Elem e = EFFECTS;
        if (rows.isEmpty()) {
            if (!chat) { e.w = 0; e.h = 0; return; }
            rows.add("Нет эффектов");
        }
        int mw = 0;
        for (String r : rows) mw = Math.max(mw, f.width(r));
        e.w = Math.max(70, mw + 14);
        e.h = 16 + rows.size() * 11;
        panel(g, e, "Эффекты");
        int y = e.y + 17;
        for (String r : rows) {
            g.drawString(f, r, e.x + 7, y, 0xFFE6E6F0, false);
            y += 11;
        }
    }

    private void drawBinds(GuiGraphics g, Minecraft mc, boolean chat) {
        Font f = mc.font;
        List<Module> bound = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) if (m.bindKey != -1 && m.bindName != null) bound.add(m);
        Elem e = BINDS;
        if (bound.isEmpty() && !chat) { e.w = 0; e.h = 0; return; }
        int mw = f.width("Бинды");
        for (Module m : bound) mw = Math.max(mw, f.width(m.name + "  [" + m.bindName.toUpperCase() + "]"));
        e.w = Math.max(80, mw + 14);
        e.h = 16 + Math.max(1, bound.size()) * 11;
        panel(g, e, "Бинды");
        int y = e.y + 17;
        if (bound.isEmpty()) {
            g.drawString(f, "(.bind add модуль клавиша)", e.x + 7, y, 0xFF8A8A99, false);
            e.w = Math.max(e.w, f.width("(.bind add модуль клавиша)") + 14);
            return;
        }
        for (Module m : bound) {
            int col = m.isEnabled() ? grad(0) : 0xFF8A8A99;
            g.drawString(f, m.name + "  [" + m.bindName.toUpperCase() + "]", e.x + 7, y, col, false);
            y += 11;
        }
    }

    private void drawTarget(GuiGraphics g, Minecraft mc, LocalPlayer p, boolean chat, float k) {
        LivingEntity t = Combat.get();
        Elem e = TARGET;
        if (t == null && !chat) { lastTarget = null; e.w = 0; e.h = 0; return; }
        if (t == null) t = p; // предпросмотр, чтобы можно было переместить рамку

        e.w = 150;
        e.h = 46;
        Font f = mc.font;
        panel(g, e, null);

        if (t != lastTarget) {
            lastTarget = t;
            shownHp = t.getHealth();
        }
        shownHp += (t.getHealth() - shownHp) * k;

        // голова в рамке
        Draw.round(g, e.x + 5, e.y + 7, 32, 32, 0xFF1C1C24);
        if (t instanceof AbstractClientPlayer ap) {
            PlayerFaceRenderer.draw(g, ap.getSkin(), e.x + 7, e.y + 9, 28);
        } else {
            g.drawString(f, "?", e.x + 19, e.y + 19, 0xFFAAAAAA, false);
        }

        // ник и здоровье
        String name = f.plainSubstrByWidth(t.getName().getString(), 76);
        g.drawString(f, name, e.x + 43, e.y + 7, 0xFFFFFFFF, false);
        float max = Math.max(1f, t.getMaxHealth());
        String hpText = String.format("%.1f", t.getHealth());
        g.drawString(f, hpText, e.x + e.w - 7 - f.width(hpText), e.y + 7, grad(0), false);

        int bx = e.x + 43, by = e.y + 19, bw = e.w - 50;
        g.fill(bx, by, bx + bw, by + 6, 0xFF1C1C24);
        float frac = Mth.clamp(shownHp / max, 0f, 1f);
        int fillW = (int) (bw * frac);
        for (int i = 0; i < fillW; i += 2) g.fill(bx + i, by, bx + Math.min(i + 2, fillW), by + 6, grad(i * 0.05));
        float ab = t.getAbsorptionAmount();
        if (ab > 0) g.fill(bx, by + 6, bx + (int) (bw * Mth.clamp(ab / max, 0f, 1f)), by + 7, 0xFFFACC15);

        g.drawString(f, String.format("Броня %d   %.1fм", t.getArmorValue(), p.distanceTo(t)), e.x + 43, e.y + 31, 0xFF9A9AAA, false);

        // предметы в правой и левой руке
        ItemStack main = t.getMainHandItem(), off = t.getOffhandItem();
        if (!main.isEmpty()) g.renderItem(main, e.x + e.w - 40, e.y + 27);
        if (!off.isEmpty()) g.renderItem(off, e.x + e.w - 22, e.y + 27);
    }
}
