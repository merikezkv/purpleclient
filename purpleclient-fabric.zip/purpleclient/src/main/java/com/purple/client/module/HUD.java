package com.purple.client.module;

import com.mojang.blaze3d.vertex.PoseStack;
import com.purple.client.PurpleClient;
import com.purple.client.gui.Theme;
import com.purple.client.setting.BoolSetting;
import com.purple.client.util.Combat;
import com.purple.client.util.Config;
import com.purple.client.util.Draw;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Компактный HUD в стиле современных клиентов: ватермарка, список модулей с градиентом,
 * панели Keybinds / Potions / Info / Target (перетаскиваются мышью при открытом чате), броня над хотбаром.
 */
public class HUD extends Module {
    public static class Elem {
        public final String id;
        public int x, y, w = 90, h = 24;
        Elem(String id) { this.id = id; }
    }

    public static boolean positioned;
    public static final Elem TARGET = new Elem("target");
    public static final Elem INFO = new Elem("info");
    public static final Elem EFFECTS = new Elem("effects");
    public static final Elem BINDS = new Elem("binds");
    public static final List<Elem> ELEMS = List.of(TARGET, INFO, EFFECTS, BINDS);

    private final BoolSetting watermark = new BoolSetting("Ватермарка", true);
    private final BoolSetting list = new BoolSetting("Список модулей", true);
    private final BoolSetting target = new BoolSetting("Цель", true);
    private final BoolSetting info = new BoolSetting("Информация", true);
    private final BoolSetting effects = new BoolSetting("Эффекты", true);
    private final BoolSetting binds = new BoolSetting("Бинды", true);
    private final BoolSetting armor = new BoolSetting("Броня", true);

    private final Map<Module, Float> listAnim = new HashMap<>();
    private static long lastNs = System.nanoTime();
    private static Elem grabbed;
    private static int dragDX, dragDY;
    private static boolean wasDown;
    private float shownHp = -1f, bps;
    private LivingEntity lastTarget;

    public HUD() {
        super("HUD", "Misc");
        settings.add(watermark);
        settings.add(list);
        settings.add(target);
        settings.add(info);
        settings.add(effects);
        settings.add(binds);
        settings.add(armor);
    }

    // ---------- вспомогательное ----------
    private static int grad(double phase) {
        double t = (Math.sin(System.currentTimeMillis() / 700.0 + phase) + 1) / 2;
        int c = Theme.rgb;
        int r = (c >> 16) & 255, gg = (c >> 8) & 255, b = c & 255;
        int r2 = (int) (r + (255 - r) * 0.55), g2 = (int) (gg + (255 - gg) * 0.55), b2 = (int) (b + (255 - b) * 0.55);
        return 0xFF000000 | ((int) (r + (r2 - r) * t) << 16) | ((int) (gg + (g2 - gg) * t) << 8) | (int) (b + (b2 - b) * t);
    }

    /** Панель: тёмный фон, заголовок и градиентная линия под ним. */
    private void panel(GuiGraphics g, Elem e, String title) {
        Font f = Minecraft.getInstance().font;
        Draw.round(g, e.x, e.y, e.w, e.h, 0xB00D0D12);
        if (title != null) {
            g.drawString(f, title, e.x + 5, e.y + 3, grad(0), false);
            for (int i = 0; i < e.w - 8; i += 2) g.fill(e.x + 4 + i, e.y + 13, e.x + 6 + i, e.y + 14, grad(i * 0.03));
        }
    }

    private void handleDrag(Minecraft mc, int w, int h) {
        if (!(mc.screen instanceof ChatScreen)) {
            grabbed = null;
            wasDown = false;
            return;
        }
        double mx = mc.mouseHandler.xpos() * w / (double) mc.getWindow().getScreenWidth();
        double my = mc.mouseHandler.ypos() * h / (double) mc.getWindow().getScreenHeight();
        boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !wasDown) {
            for (int i = ELEMS.size() - 1; i >= 0; i--) {
                Elem e = ELEMS.get(i);
                if (e.w > 0 && mx >= e.x && mx <= e.x + e.w && my >= e.y && my <= e.y + e.h) {
                    grabbed = e;
                    dragDX = (int) mx - e.x;
                    dragDY = (int) my - e.y;
                    break;
                }
            }
        }
        if (!down && grabbed != null) {
            grabbed = null;
            Config.save();
        }
        if (grabbed != null) {
            grabbed.x = Mth.clamp((int) mx - dragDX, 0, Math.max(0, w - grabbed.w));
            grabbed.y = Mth.clamp((int) my - dragDY, 0, Math.max(0, h - grabbed.h));
        }
        wasDown = down;
    }

    // ---------- отрисовка ----------
    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;

        if (!positioned) {
            positioned = true;
            BINDS.x = 6;   BINDS.y = 28;
            EFFECTS.x = 6; EFFECTS.y = 92;
            INFO.x = 6;    INFO.y = h - 28;
            TARGET.x = w / 2 + 14; TARGET.y = h / 2 + 34;
        }

        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        float k = 1f - (float) Math.exp(-dt * 12f);

        for (Elem e : ELEMS) {
            e.x = Mth.clamp(e.x, 0, Math.max(0, w - 20));
            e.y = Mth.clamp(e.y, 0, Math.max(0, h - 20));
        }
        handleDrag(mc, w, h);
        boolean chat = mc.screen instanceof ChatScreen;

        if (watermark.value) drawWatermark(g, mc, p);
        if (list.value) drawList(g, mc, w, k);
        if (armor.value) drawArmor(g, mc, p, w, h);
        if (info.value) drawInfo(g, mc, p, k);
        if (effects.value) drawEffects(g, mc, p, chat);
        if (binds.value) drawBinds(g, mc, chat);
        if (target.value) drawTarget(g, mc, p, chat, k);
    }

    private void drawWatermark(GuiGraphics g, Minecraft mc, LocalPlayer p) {
        Font f = mc.font;
        String a = "Purple", b = "Client " + PurpleClient.VERSION;
        String right = p.getName().getString() + "  " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        int x = 22;
        int w = x + f.width(a) + f.width(b) + 8 + f.width(right) + 6 - 6;
        Draw.round(g, 6, 6, w, 14, 0xB00D0D12);
        Draw.round(g, 8, 8, 10, 10, Theme.accent());
        g.drawString(f, "P", 11, 9, 0xFF0D0D12, false);
        g.drawString(f, a, x, 10, 0xFFFFFFFF, false);
        g.drawString(f, b, x + f.width(a), 10, Theme.accent(), false);
        int sx = x + f.width(a) + f.width(b) + 4;
        g.fill(sx, 9, sx + 1, 17, 0xFF34343E);
        g.drawString(f, right, sx + 5, 10, 0xFFB5B5C2, false);
        for (int i = 0; i < w - 8; i += 2) g.fill(10 + i, 19, 12 + i, 20, grad(i * 0.04));
    }

    private void drawList(GuiGraphics g, Minecraft mc, int w, float k) {
        Font f = mc.font;
        List<Module> vis = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) {
            if (m == this) continue;
            float tgt = m.isEnabled() ? 1f : 0f;
            float a = listAnim.getOrDefault(m, tgt);
            a += (tgt - a) * k;
            if (Math.abs(tgt - a) < 0.01f) a = tgt;
            listAnim.put(m, a);
            if (a > 0.02f) vis.add(m);
        }
        vis.sort((x, y) -> Integer.compare(f.width(y.name), f.width(x.name)));

        int y = 6, idx = 0;
        for (Module m : vis) {
            float a = listAnim.get(m);
            int bw = f.width(m.name) + 9;
            int x = w - bw - 4 + (int) ((1f - a) * (bw + 8));
            int col = grad(idx * 0.55);
            Draw.round(g, x, y, bw, 10, Draw.alpha(0x0D0D12, (int) (0xB0 * a)));
            g.fill(x + bw - 2, y + 1, x + bw, y + 9, Draw.alpha(col, (int) (255 * a)));
            if (a > 0.15f) g.drawString(f, m.name, x + 4, y + 1, Draw.alpha(col, (int) (255 * a)), false);
            y += Math.max(1, (int) (11 * a));
            idx++;
        }
    }

    private void drawArmor(GuiGraphics g, Minecraft mc, LocalPlayer p, int w, int h) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        boolean any = false;
        for (EquipmentSlot s : slots) if (!p.getItemBySlot(s).isEmpty()) any = true;
        if (!any) return;
        int x0 = w / 2 - 36, y = h - 74;
        Draw.round(g, x0 - 3, y - 3, 78, 22, 0xB00D0D12);
        for (int i = 0; i < 4; i++) {
            ItemStack s = p.getItemBySlot(slots[i]);
            if (s.isEmpty()) continue;
            g.renderItem(s, x0 + i * 18, y);
            g.renderItemDecorations(mc.font, s, x0 + i * 18, y);
        }
    }

    private void drawInfo(GuiGraphics g, Minecraft mc, LocalPlayer p, float k) {
        Font f = mc.font;
        double sp = Math.hypot(p.getX() - p.xo, p.getZ() - p.zo) * 20.0;
        bps += (float) ((sp - bps) * k);
        String l1 = String.format("XYZ  %d  %d  %d", (int) Math.floor(p.getX()), (int) Math.floor(p.getY()), (int) Math.floor(p.getZ()));
        String l2 = String.format("BPS  %.1f", bps);
        Elem e = INFO;
        e.w = Math.max(f.width(l1), f.width(l2)) + 10;
        e.h = 24;
        panel(g, e, null);
        g.drawString(f, l1, e.x + 5, e.y + 4, 0xFFE6E6F0, false);
        g.drawString(f, l2, e.x + 5, e.y + 14, grad(1.0), false);
    }

    private void drawEffects(GuiGraphics g, Minecraft mc, LocalPlayer p, boolean chat) {
        Font f = mc.font;
        List<String> rows = new ArrayList<>();
        for (MobEffectInstance inst : p.getActiveEffects()) {
            String name = Component.translatable(inst.getDescriptionId()).getString();
            if (inst.getAmplifier() > 0) name += " " + (inst.getAmplifier() + 1);
            String time;
            if (inst.isInfiniteDuration()) {
                time = "∞";
            } else {
                int s = inst.getDuration() / 20;
                time = String.format("%d:%02d", s / 60, s % 60);
            }
            rows.add(name + "  " + time);
        }
        Elem e = EFFECTS;
        if (rows.isEmpty()) {
            if (!chat) { e.w = 0; e.h = 0; return; }
            rows.add("нет эффектов");
        }
        int mw = f.width("Potions");
        for (String r : rows) mw = Math.max(mw, f.width(r));
        e.w = mw + 12;
        e.h = 16 + rows.size() * 10 + 2;
        panel(g, e, "Potions");
        int y = e.y + 17;
        for (String r : rows) {
            g.drawString(f, r, e.x + 5, y, 0xFFE6E6F0, false);
            y += 10;
        }
    }

    private void drawBinds(GuiGraphics g, Minecraft mc, boolean chat) {
        Font f = mc.font;
        List<Module> bound = new ArrayList<>();
        for (Module m : ModuleManager.MODULES) if (m.bindKey != -1 && m.bindName != null) bound.add(m);
        Elem e = BINDS;
        if (bound.isEmpty() && !chat) { e.w = 0; e.h = 0; return; }
        String hint = ".bind add модуль клавиша";
        int mw = f.width("Keybinds");
        for (Module m : bound) mw = Math.max(mw, f.width(m.name + "  " + m.bindName.toUpperCase()));
        if (bound.isEmpty()) mw = Math.max(mw, f.width(hint));
        e.w = mw + 12;
        e.h = 16 + Math.max(1, bound.size()) * 10 + 2;
        panel(g, e, "Keybinds");
        int y = e.y + 17;
        if (bound.isEmpty()) {
            g.drawString(f, hint, e.x + 5, y, 0xFF8A8A99, false);
            return;
        }
        for (Module m : bound) {
            String name = m.name;
            String key = m.bindName.toUpperCase();
            g.drawString(f, name, e.x + 5, y, m.isEnabled() ? grad(0) : 0xFF8A8A99, false);
            g.drawString(f, key, e.x + e.w - 5 - f.width(key), y, 0xFFB5B5C2, false);
            y += 10;
        }
    }

    private void drawTarget(GuiGraphics g, Minecraft mc, LocalPlayer p, boolean chat, float k) {
        LivingEntity t = Combat.get();
        Elem e = TARGET;
        if (t == null && !chat) { lastTarget = null; e.w = 0; e.h = 0; return; }
        if (t == null) t = p; // предпросмотр для перемещения

        Font f = mc.font;
        e.w = 128;
        e.h = 36;
        panel(g, e, null);

        if (t != lastTarget) {
            lastTarget = t;
            shownHp = t.getHealth();
        }
        shownHp += (t.getHealth() - shownHp) * k;

        // голова
        Draw.round(g, e.x + 4, e.y + 5, 26, 26, 0xFF1C1C24);
        if (t instanceof AbstractClientPlayer ap) {
            PlayerFaceRenderer.draw(g, ap.getSkin(), e.x + 5, e.y + 6, 24);
        } else {
            g.drawString(f, "?", e.x + 15, e.y + 14, 0xFFAAAAAA, false);
        }

        // ник, здоровье
        String name = f.plainSubstrByWidth(t.getName().getString(), e.w - 38 - 26);
        g.drawString(f, name, e.x + 34, e.y + 5, 0xFFFFFFFF, false);
        String hp = String.format("%.1f", t.getHealth());
        g.drawString(f, hp, e.x + e.w - 5 - f.width(hp), e.y + 5, grad(0), false);

        float max = Math.max(1f, t.getMaxHealth());
        int bx = e.x + 34, by = e.y + 16, bw = e.w - 40;
        g.fill(bx, by, bx + bw, by + 4, 0xFF1C1C24);
        int fillW = (int) (bw * Mth.clamp(shownHp / max, 0f, 1f));
        for (int i = 0; i < fillW; i += 2) g.fill(bx + i, by, bx + Math.min(i + 2, fillW), by + 4, grad(i * 0.05));
        if (t.getAbsorptionAmount() > 0) {
            g.fill(bx, by + 4, bx + (int) (bw * Mth.clamp(t.getAbsorptionAmount() / max, 0f, 1f)), by + 5, 0xFFFACC15);
        }

        g.drawString(f, String.format("Бр %d  %.1fм", t.getArmorValue(), p.distanceTo(t)), e.x + 34, e.y + 24, 0xFF9A9AAA, false);

        // предметы в руках (мелкие значки)
        ItemStack main = t.getMainHandItem(), off = t.getOffhandItem();
        smallItem(g, main, e.x + e.w - 28, e.y + 21);
        smallItem(g, off, e.x + e.w - 15, e.y + 21);
    }

    private static void smallItem(GuiGraphics g, ItemStack s, int x, int y) {
        if (s.isEmpty()) return;
        PoseStack ps = g.pose();
        ps.pushPose();
        try {
            ps.translate(x, y, 0);
            ps.scale(0.7f, 0.7f, 1f);
            g.renderItem(s, 0, 0);
        } finally {
            ps.popPose();
        }
    }
}
