package com.purple.client.util;

import com.purple.client.gui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/**
 * TargetESP для AttackAura. Всё рисуется линиями поверх экрана, без частиц.
 * Режимы: Скобы (светящиеся дуги вокруг торса), Шлейф (кометы со светящимся хвостом), Круг (кольцо на земле).
 */
public final class TargetMarker {
    public static final String[] MODES = {"Скобы", "Шлейф", "Круг"};

    public void render(GuiGraphics g, LivingEntity t, int mode) {
        if (t == null) return;
        Minecraft mc = Minecraft.getInstance();
        Projector pr = Projector.create(mc);
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        double x = Mth.lerp(pt, t.xo, t.getX());
        double y = Mth.lerp(pt, t.yo, t.getY());
        double z = Mth.lerp(pt, t.zo, t.getZ());
        double time = System.currentTimeMillis() / 1000.0;
        double bh = t.getBbHeight(), bw = t.getBbWidth();
        int rgb = Theme.rgb;

        switch (mode) {
            case 0 -> brackets(g, pr, x, y, z, bh, bw, time, rgb);
            case 1 -> trail(g, pr, x, y, z, bh, bw, time, rgb);
            default -> ground(g, pr, x, y, z, bw, time, rgb);
        }
    }

    // ---------- рисование ----------
    private static int lighten(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return ((int) (r + (255 - r) * 0.6) << 16) | ((int) (g + (255 - g) * 0.6) << 8) | (int) (b + (255 - b) * 0.6);
    }

    /** Отрезок заданной толщины. */
    private static void seg(GuiGraphics g, double x1, double y1, double x2, double y2, int size, int color) {
        double dx = x2 - x1, dy = y2 - y1;
        int n = (int) Math.max(1, Math.max(Math.abs(dx), Math.abs(dy)));
        n = Math.min(n, 300);
        int h = size / 2;
        for (int i = 0; i <= n; i++) {
            int x = (int) (x1 + dx * i / n), y = (int) (y1 + dy * i / n);
            g.fill(x - h, y - h, x - h + size, y - h + size, color);
        }
    }

    /** Светящийся отрезок: широкое слабое свечение, среднее и яркая светлая сердцевина. */
    private static void glowSeg(GuiGraphics g, double x1, double y1, double x2, double y2, int rgb, int a, int core) {
        seg(g, x1, y1, x2, y2, core + 6, Draw.alpha(rgb, Math.max(a / 9, 4)));
        seg(g, x1, y1, x2, y2, core + 3, Draw.alpha(rgb, Math.max(a / 3, 8)));
        seg(g, x1, y1, x2, y2, core, Draw.alpha(lighten(rgb), a));
    }

    private static void glowDot(GuiGraphics g, double x, double y, int rgb, int size) {
        seg(g, x, y, x, y, size + 7, Draw.alpha(rgb, 28));
        seg(g, x, y, x, y, size + 4, Draw.alpha(rgb, 80));
        seg(g, x, y, x, y, size, Draw.alpha(lighten(rgb), 255));
    }

    /** Замкнутое или дуговое кольцо из отрезков. */
    private static void ringLine(GuiGraphics g, Projector pr, double cx, double cy, double cz, double r,
                                 double from, double to, int steps, int size, int color, boolean glow, int rgb, int alpha) {
        double px = 0, py = 0;
        boolean has = false;
        for (int i = 0; i <= steps; i++) {
            double a = from + (to - from) * i / steps;
            if (pr.project(cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r)) {
                if (has) {
                    if (glow) glowSeg(g, px, py, pr.sx, pr.sy, rgb, alpha, size);
                    else seg(g, px, py, pr.sx, pr.sy, size, color);
                }
                px = pr.sx;
                py = pr.sy;
                has = true;
            } else {
                has = false;
            }
        }
    }

    // ---------- режимы ----------
    /** Скобы: две светящиеся дуги вокруг торса, вращаются. */
    private void brackets(GuiGraphics g, Projector pr, double x, double y, double z, double bh, double bw, double time, int rgb) {
        double r = bw * 0.5 + 0.22;
        double bandH = bh * 0.27, mid = y + bh * 0.58;
        double base = time * 1.9;
        double arc = Math.toRadians(95);
        int steps = 16;

        for (int s = 0; s < 2; s++) {
            double a0 = base + s * Math.PI - arc / 2;
            // верхний и нижний край, середина (тоньше свечения)
            ringLine(g, pr, x, mid + bandH / 2, z, r, a0, a0 + arc, steps, 2, 0, true, rgb, 255);
            ringLine(g, pr, x, mid - bandH / 2, z, r, a0, a0 + arc, steps, 2, 0, true, rgb, 255);
            ringLine(g, pr, x, mid, z, r, a0, a0 + arc, steps, 3, Draw.alpha(rgb, 120), false, rgb, 0);
            // торцы скобы
            for (int e = 0; e < 2; e++) {
                double a = a0 + arc * e;
                double px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r;
                if (pr.project(px, mid + bandH / 2, pz)) {
                    double sx = pr.sx, sy = pr.sy;
                    if (pr.project(px, mid - bandH / 2, pz)) glowSeg(g, sx, sy, pr.sx, pr.sy, rgb, 255, 2);
                }
            }
        }
    }

    /** Шлейф: две кометы, бегущие по спирали вокруг тела, с плавно истончающимся светящимся хвостом. */
    private void trail(GuiGraphics g, Projector pr, double x, double y, double z, double bh, double bw, double time, int rgb) {
        double r = bw * 0.5 + 0.35;
        int n = 44;
        for (int c = 0; c < 2; c++) {
            double px = 0, py = 0;
            boolean has = false;
            for (int j = 0; j < n; j++) {
                double tt = time - j * 0.028;
                double ang = tt * 3.2 + c * Math.PI;
                double hh = bh * (0.5 + 0.42 * Math.sin(tt * 1.9 + c * 1.3));
                if (pr.project(x + Math.cos(ang) * r, y + hh, z + Math.sin(ang) * r)) {
                    if (has) {
                        double f = 1.0 - j / (double) n;
                        int core = j < 6 ? 4 : (j < 16 ? 3 : 2);
                        glowSeg(g, px, py, pr.sx, pr.sy, rgb, Math.max((int) (255 * f), 10), core);
                    } else if (j == 0) {
                        glowDot(g, pr.sx, pr.sy, rgb, 4);
                    }
                    px = pr.sx;
                    py = pr.sy;
                    has = true;
                } else {
                    has = false;
                }
            }
        }
    }

    /** Круг: кольцо на земле с мягким свечением внутрь и бегущей яркой дугой. */
    private void ground(GuiGraphics g, Projector pr, double x, double y, double z, double bw, double time, int rgb) {
        double pulse = 0.5 + 0.5 * Math.sin(time * 2.2);
        double rr = bw * 0.5 + 0.55 + 0.06 * pulse;
        double gy = y + 0.03;
        int n = 48;

        // свечение внутрь: кольца уменьшающегося радиуса и яркости
        for (int k = 5; k >= 1; k--) {
            double f = k / 6.0;
            double r2 = rr * (1.0 - f * 0.55);
            int a = (int) (150 * (1.0 - f) + 20);
            ringLine(g, pr, x, gy, z, r2, 0, Math.PI * 2, n, 2, Draw.alpha(rgb, a), false, rgb, 0);
        }
        // внешнее яркое кольцо
        ringLine(g, pr, x, gy, z, rr, 0, Math.PI * 2, n, 3, 0, true, rgb, 255);
        // бегущая светлая дуга
        double a0 = time * 2.6;
        ringLine(g, pr, x, gy, z, rr, a0, a0 + 1.1, 12, 4, 0, true, rgb, 255);
    }
}
