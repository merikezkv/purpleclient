package com.purple.client.util;

import com.purple.client.gui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/** TargetESP для AttackAura: яркие маркеры, нарисованные поверх экрана. Режимы: Ромб, Цепи, Призраки, Кольцо. */
public final class TargetMarker {
    public static final String[] MODES = {"Ромб", "Цепи", "Призраки", "Кольцо"};

    public void render(GuiGraphics g, LivingEntity t, int mode) {
        if (t == null) return;
        Minecraft mc = Minecraft.getInstance();
        Projector pr = Projector.create(mc);
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        double x = Mth.lerp(pt, t.xo, t.getX());
        double y = Mth.lerp(pt, t.yo, t.getY());
        double z = Mth.lerp(pt, t.zo, t.getZ());
        double time = System.currentTimeMillis() / 1000.0;
        double bh = t.getBbHeight(), bw = t.getBbWidth();
        int rgb = Theme.rgb;

        switch (mode) {
            case 0 -> diamond(g, pr, x, y, z, bh, time, rgb);
            case 1 -> chains(g, pr, x, y, z, bh, bw, time, rgb);
            case 2 -> ghosts(g, pr, x, y, z, bh, bw, time, rgb);
            default -> ring(g, pr, x, y, z, bh, bw, time, rgb);
        }
    }

    private static int lighten(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return ((int) (r + (255 - r) * 0.6) << 16) | ((int) (g + (255 - g) * 0.6) << 8) | (int) (b + (255 - b) * 0.6);
    }

    private static void dot(GuiGraphics g, double x, double y, int size, int color) {
        int h = size / 2;
        g.fill((int) x - h, (int) y - h, (int) x - h + size, (int) y - h + size, color);
    }

    /** Яркая точка со свечением. */
    private static void glow(GuiGraphics g, double x, double y, int rgb, int a, int size) {
        dot(g, x, y, size + 6, Draw.alpha(rgb, Math.max(a / 6, 6)));
        dot(g, x, y, size + 3, Draw.alpha(rgb, Math.max(a / 2, 10)));
        dot(g, x, y, size, Draw.alpha(lighten(rgb), a));
    }

    private static void edge(GuiGraphics g, double[][] v, boolean[] ok, int a, int b, int color) {
        if (ok[a] && ok[b]) Draw.line(g, v[a][0], v[a][1], v[b][0], v[b][1], color, 1);
    }

    /** Ромб: вращающийся объёмный ромб над головой. */
    private void diamond(GuiGraphics g, Projector pr, double x, double y, double z, double bh, double time, int rgb) {
        double cy = y + bh + 0.65 + 0.07 * Math.sin(time * 3);
        double hh = 0.36, rr = 0.26, ang = time * 2.4;
        double[][] v = new double[6][2];
        boolean[] ok = new boolean[6];

        ok[0] = pr.project(x, cy + hh, z); v[0][0] = pr.sx; v[0][1] = pr.sy;
        ok[1] = pr.project(x, cy - hh, z); v[1][0] = pr.sx; v[1][1] = pr.sy;
        for (int k = 0; k < 4; k++) {
            double a = ang + k * Math.PI / 2;
            ok[2 + k] = pr.project(x + Math.cos(a) * rr, cy, z + Math.sin(a) * rr);
            v[2 + k][0] = pr.sx;
            v[2 + k][1] = pr.sy;
        }
        int col = Draw.alpha(rgb, 255), col2 = Draw.alpha(lighten(rgb), 255);
        for (int k = 0; k < 4; k++) {
            int e = 2 + k, n = 2 + (k + 1) % 4;
            edge(g, v, ok, 0, e, col);
            edge(g, v, ok, 1, e, col);
            edge(g, v, ok, e, n, col2);
        }
        for (int i = 0; i < 6; i++) if (ok[i]) glow(g, v[i][0], v[i][1], rgb, 255, 3);
    }

    /** Цепи: кольцо из звеньев, чередующихся по ориентации. */
    private void chains(GuiGraphics g, Projector pr, double x, double y, double z, double bh, double bw, double time, int rgb) {
        int n = 12;
        double r = bw * 0.5 + 0.4, hm = y + bh * 0.55, base = time * 1.1;
        double a = 0.22, b = 0.095;
        int c1 = Draw.alpha(rgb, 255), c2 = Draw.alpha(lighten(rgb), 255);
        for (int i = 0; i < n; i++) {
            double th = base + i * 2 * Math.PI / n;
            double cx = x + Math.cos(th) * r, cz = z + Math.sin(th) * r;
            double tx = -Math.sin(th), tz = Math.cos(th), rx = Math.cos(th), rz = Math.sin(th);
            boolean vertical = i % 2 == 0;
            int col = vertical ? c1 : c2;
            for (int j = 0; j < 12; j++) {
                double ph = 2 * Math.PI * j / 12;
                double ca = Math.cos(ph) * a, sb = Math.sin(ph) * b;
                double px = cx + tx * ca + (vertical ? 0 : rx * sb);
                double py = hm + (vertical ? sb : 0);
                double pz = cz + tz * ca + (vertical ? 0 : rz * sb);
                if (pr.project(px, py, pz)) dot(g, pr.sx, pr.sy, 3, col);
            }
        }
    }

    /** Призраки: три светящиеся сферы с длинным шлейфом. */
    private void ghosts(GuiGraphics g, Projector pr, double x, double y, double z, double bh, double bw, double time, int rgb) {
        double rad = bw * 0.5 + 0.5;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 28; j++) {
                double tt = time - j * 0.02;
                double ang = tt * 2.3 + i * 2 * Math.PI / 3;
                double hh = bh * (0.5 + 0.38 * Math.sin(tt * 1.7 + i * 2.1));
                if (!pr.project(x + Math.cos(ang) * rad, y + hh, z + Math.sin(ang) * rad)) continue;
                int a = (int) (255 * (1.0 - j / 28.0));
                if (j == 0) {
                    glow(g, pr.sx, pr.sy, rgb, 255, 5);
                } else {
                    int size = j < 4 ? 5 : (j < 10 ? 4 : 3);
                    dot(g, pr.sx, pr.sy, size, Draw.alpha(rgb, Math.max(a, 12)));
                }
            }
        }
    }

    /** Кольцо: широкое яркое кольцо с шлейфом, бегущее вверх-вниз по телу. */
    private void ring(GuiGraphics g, Projector pr, double x, double y, double z, double bh, double bw, double time, int rgb) {
        double rr = bw * 0.5 + 0.6;
        int n = 56;
        for (int j = 0; j < 6; j++) {
            double tt = time - j * 0.045;
            double hh = (Math.sin(tt * 1.7) + 1) / 2 * bh;
            int a = j == 0 ? 255 : Math.max(200 - j * 32, 20);
            int size = j == 0 ? 3 : 2;
            int col = Draw.alpha(j == 0 ? lighten(rgb) : rgb, a);
            for (int k = 0; k < n; k++) {
                double ang = 2 * Math.PI * k / n;
                if (pr.project(x + Math.cos(ang) * rr, y + hh, z + Math.sin(ang) * rr)) dot(g, pr.sx, pr.sy, size, col);
            }
        }
    }
}
