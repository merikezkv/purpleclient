package com.purple.client.util;

import com.purple.client.gui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/** TargetESP как в современных читах: рисуется поверх экрана, без частиц и эффектов. */
public final class TargetMarker {
    public static final String[] MODES = {"Выкл", "Кольцо", "Маркер", "Круг"};

    public double size = 1.0;

    public void render(GuiGraphics g, LivingEntity t, int mode) {
        if (t == null || mode == 0) return;
        Minecraft mc = Minecraft.getInstance();
        Projector pr = Projector.create(mc);
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        double x = Mth.lerp(pt, t.xo, t.getX());
        double y = Mth.lerp(pt, t.yo, t.getY());
        double z = Mth.lerp(pt, t.zo, t.getZ());
        double time = System.currentTimeMillis() / 1000.0;
        double r = (t.getBbWidth() * 0.5 + 0.25) * size;
        double bh = t.getBbHeight();
        int rgb = Theme.rgb;

        if (mode == 1) {
            // два "кометных" кольца со шлейфом, плавно бегущих вверх-вниз по телу
            for (int c = 0; c < 2; c++) {
                for (int i = 0; i < 40; i++) {
                    double tt = time - i * 0.016;
                    double ang = tt * 4.0 + c * Math.PI;
                    double hh = (Math.sin(tt * 1.8 + c * 0.6) + 1) / 2 * bh;
                    if (!pr.project(x + Math.cos(ang) * r, y + hh, z + Math.sin(ang) * r)) continue;
                    int a = (int) (255 * (1.0 - i / 40.0));
                    int s = i < 3 ? 3 : 2;
                    g.fill((int) pr.sx, (int) pr.sy, (int) pr.sx + s, (int) pr.sy + s, Draw.alpha(rgb, Math.max(a, 8)));
                }
            }
        } else if (mode == 2) {
            // вращающийся пульсирующий маркер в центре цели
            if (!pr.project(x, y + bh * 0.5, z)) return;
            double cx = pr.sx, cy = pr.sy;
            double s1 = 13 + 3 * Math.sin(time * 4);
            double ang = time * 2.2;
            int col = Draw.alpha(rgb, 235), col2 = Draw.alpha(rgb, 110);
            for (int k = 0; k < 4; k++) {
                double a1 = ang + k * Math.PI / 2 + Math.PI / 4, a2 = ang + (k + 1) * Math.PI / 2 + Math.PI / 4;
                Draw.line(g, cx + Math.cos(a1) * s1, cy + Math.sin(a1) * s1,
                        cx + Math.cos(a2) * s1, cy + Math.sin(a2) * s1, col, 2);
                double b1 = -ang * 0.7 + k * Math.PI / 2, b2 = -ang * 0.7 + (k + 1) * Math.PI / 2;
                Draw.line(g, cx + Math.cos(b1) * (s1 + 6), cy + Math.sin(b1) * (s1 + 6),
                        cx + Math.cos(b2) * (s1 + 6), cy + Math.sin(b2) * (s1 + 6), col2, 3);
            }
            g.fill((int) cx - 1, (int) cy - 1, (int) cx + 2, (int) cy + 2, col);
        } else {
            // круг на земле: пульсирует и бежит пунктиром
            double rr = r * (1.0 + 0.12 * Math.sin(time * 3));
            int n = 44;
            int shift = (int) (time * 14);
            for (int i = 0; i < n; i++) {
                double ang = Math.PI * 2 * i / n;
                if (pr.project(x + Math.cos(ang) * rr, y + 0.03, z + Math.sin(ang) * rr)) {
                    int a = ((i + shift) % 6 < 3) ? 240 : 90;
                    g.fill((int) pr.sx, (int) pr.sy, (int) pr.sx + 2, (int) pr.sy + 2, Draw.alpha(rgb, a));
                }
                if (pr.project(x + Math.cos(ang) * rr * 0.7, y + 0.03, z + Math.sin(ang) * rr * 0.7)) {
                    g.fill((int) pr.sx, (int) pr.sy, (int) pr.sx + 2, (int) pr.sy + 2, Draw.alpha(rgb, 70));
                }
            }
        }
    }
}
