package com.purple.client.module;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;

/** Позволяет ходить (WASD) с открытым инвентарём/контейнером. Прыжок и приседание не работают. */
public class InventoryMove extends Module {
    private boolean active;

    public InventoryMove() {
        super("InventoryMove", "Movement");
    }

    private static void sync(KeyMapping k, long win) {
        if (k.getKey().getType() != InputConstants.Type.KEYSYM) return;
        k.setDown(InputConstants.isKeyDown(win, k.getKey().getValue()));
    }

    private void releaseAll(Minecraft mc) {
        mc.options.keyUp.setDown(false);
        mc.options.keyDown.setDown(false);
        mc.options.keyLeft.setDown(false);
        mc.options.keyRight.setDown(false);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.screen instanceof AbstractContainerScreen<?> scr && !(scr.getFocused() instanceof EditBox)) {
            long win = mc.getWindow().getWindow();
            sync(mc.options.keyUp, win);
            sync(mc.options.keyDown, win);
            sync(mc.options.keyLeft, win);
            sync(mc.options.keyRight, win);
            active = true;
        } else if (active) {
            releaseAll(mc);
            active = false;
        }
    }

    @Override
    public void onDisable() {
        if (active) {
            releaseAll(Minecraft.getInstance());
            active = false;
        }
    }
}
