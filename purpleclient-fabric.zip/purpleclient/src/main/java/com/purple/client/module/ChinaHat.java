package com.purple.client.module;

import com.purple.client.gui.Theme;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Draw;
import com.purple.client.util.Projector;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;

/** Китайская шляпа (конус цвета клиента) над головой: у вас в третьем лице и, по желанию, у других игроков. */
public class ChinaHat extends Module {
    private final NumSetting height = new NumSetting("Высота", 0.45, 0.2, 1.0, 0.05);
    private final NumSetting radius = new NumSetting("Радиус", 0.55, 0.3, 1.0, 0.05);
    private final BoolSetting others = new BoolSetting("Другие игроки", false);

    public ChinaHat() {
        super("ChinaHat", "Render");
        settings.add(height);
        settings.add(radius);
        settings.add(others);
    }

    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        List<Player> list = new ArrayList<>();
        if (!mc.options.getCameraType().isFirstPerson()) list.add(mc.player);
        if (others.value) {
            for (Player pl : mc.level.players()) if (pl != mc.player && mc.player.distanceTo(pl) < 48) list.add(pl);
        }
        if (list.isEmpty()) return;

        Projector pr = Projector.create(mc);
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        double time = System.currentTimeMillis() / 1500.0 * Math.PI * 2;
        int ring = Draw.alpha(Theme.rgb, 230), spoke = Draw.alpha(Theme.rgb, 140);

        for (Player pl : list) {
            double x = Mth.lerp(pt, pl.xo, pl.getX());
            double y = Mth.lerp(pt, pl.yo, pl.getY());
            double z = Mth.lerp(pt, pl.zo, pl.getZ());
            double top = y + pl.getBbHeight() + (pl.isCrouching() ? -0.1 : 0.05);
            double r = radius.value;

            for (int i = 0; i < 32; i++) {
                double a = Math.PI * 2 * i / 32;
                if (pr.project(x + Math.cos(a) * r, top, z + Math.sin(a) * r)) Draw.dot(g, pr.sx, pr.sy, ring);
            }
            if (!pr.project(x, top + height.value, z)) continue;
            double ax = pr.sx, ay = pr.sy;
            for (int k = 0; k < 10; k++) {
                double a = time + Math.PI * 2 * k / 10;
                if (pr.project(x + Math.cos(a) * r, top, z + Math.sin(a) * r)) {
                    Draw.line(g, ax, ay, pr.sx, pr.sy, spoke, 3);
                }
            }
        }
    }
}
