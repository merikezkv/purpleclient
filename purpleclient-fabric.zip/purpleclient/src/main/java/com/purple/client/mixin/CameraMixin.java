package com.purple.client.mixin;

import com.purple.client.module.ModuleManager;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** FreeLook: камера в третьем лице (F5) не упирается в блоки. require = 0: если метод не найден, игра не падает. */
@Mixin(Camera.class)
public class CameraMixin {
    @Inject(method = "getMaxZoom", at = @At("HEAD"), cancellable = true, require = 0)
    private void purple$noClip(float maxZoom, CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.freeLook.isEnabled()) {
            cir.setReturnValue((float) ModuleManager.freeLook.distance());
        }
    }
}
