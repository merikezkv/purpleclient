package com.purple.client.module;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.List;

/** Стрелки вокруг прицела, указывающие на противников. */
public class Arrows extends Module {
    private final NumSetting range = new NumSetting("Дальность", 32, 8, 64, 4);
    private final NumSetting radius = new NumSetting("Радиус", 42, 20, 100, 2);
    private final BoolSetting players = new BoolSetting("Игроки", true);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);
    private final NumSetting count = new NumSetting("Макс. целей", 5, 1, 10, 1);
    private final BoolSetting showDist = new BoolSetting("Дистанция", true);

    public Arrows() {
        super("Arrows", "Render");
        settings.add(range);
        settings.add(radius);
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
        settings.add(count);
        settings.add(showDist);
    }

    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;

        List<Entity> list = new ArrayList<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (Targets.valid(e, p, players.value, hostile.value, animals.value) && p.distanceTo(e) <= range.value) {
                list.add(e);
            }
        }
        if (list.isEmpty()) return;
        list.sort((a, b) -> Float.compare(p.distanceTo(a), p.distanceTo(b)));

        int cx = w / 2, cy = h / 2, r = (int) radius.value;
        int n = Math.min((int) count.value, list.size());
        for (int i = 0; i < n; i++) {
            Entity e = list.get(i);
            float dist = p.distanceTo(e);
            double dx = e.getX() - p.getX(), dz = e.getZ() - p.getZ();
            float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float rel = Mth.wrapDegrees(targetYaw - p.getYRot());
            int color = dist < 8 ? 0xFFFF5555 : (dist < 20 ? 0xFFFFD43B : 0xFF55FF7F);

            PoseStack ps = g.pose();
            ps.pushPose();
            try {
                ps.translate(cx, cy, 0);
                ps.mulPose(Axis.ZP.rotationDegrees(rel));
                ps.translate(0, -r, 0);
                g.drawString(mc.font, "▲", -mc.font.width("▲") / 2, -4, color, true);
            } finally {
                ps.popPose();
            }

            if (showDist.value) {
                String t = String.valueOf((int) dist);
                double rad = Math.toRadians(rel);
                int tx = cx + (int) (Math.sin(rad) * (r + 11)) - mc.font.width(t) / 2;
                int ty = cy - (int) (Math.cos(rad) * (r + 11)) - 4;
                g.drawString(mc.font, t, tx, ty, color, true);
            }
        }
    }
}
