package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Combat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/** Автоспринт: включается мгновенно, держится после ударов, не мешает критам, может ускорять бег. */
public class Sprint extends Module {
    private final BoolSetting keepOnHit = new BoolSetting("Сохр. при ударе", true);
    private final BoolSetting noCritBlock = new BoolSetting("Не мешать критам", true);
    private final NumSetting boost = new NumSetting("Ускорение", 1.15, 1.0, 1.5, 0.05);

    public Sprint() {
        super("Sprint", "Movement");
        settings.add(keepOnHit);
        settings.add(noCritBlock);
        settings.add(boost);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null) return;

        if (!mc.options.keyUp.isDown()) return;
        if (p.isUsingItem() || p.isShiftKeyDown()) return;
        if (p.horizontalCollision) return;
        if (p.getFoodData().getFoodLevel() <= 6 && !p.getAbilities().mayfly) return;
        if (!keepOnHit.value && p.swinging) return;

        // в падении перед ударом по цели не спринтуем: спринт отменяет крит
        if (noCritBlock.value && Combat.get() != null && !p.onGround() && p.fallDistance > 0) return;

        p.setSprinting(true);

        if (boost.value > 1.0 && p.onGround()) {
            Vec3 v = p.getDeltaMovement();
            double sp = Math.hypot(v.x, v.z);
            double cap = 0.28 * boost.value;
            if (sp > 0.05 && sp < cap) {
                double ns = Math.min(cap, sp * boost.value);
                double sc = ns / sp;
                p.setDeltaMovement(v.x * sc, v.y, v.z * sc);
            }
        }
    }
}
