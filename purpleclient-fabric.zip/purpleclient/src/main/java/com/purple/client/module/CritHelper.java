package com.purple.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** Логика критических ударов для TriggerBot и AttackAura. Режимы: 0 Выкл, 1 Падение, 2 Прыжок, 3 Умный. */
final class CritHelper {
    private boolean jumpPressed;
    private int stuck;

    /** Отпустить кнопку прыжка, нажатую в прошлом тике (вызывать в начале onTick). */
    void release(Minecraft mc) {
        if (jumpPressed) {
            mc.options.keyJump.setDown(false);
            jumpPressed = false;
        }
    }

    void reset() { stuck = 0; }

    /**
     * @param ready кулдаун и прочие условия удара выполнены
     * @return true, если можно бить прямо сейчас. Прыжок делается сразу, пока кулдаун перезаряжается,
     * поэтому удар в падении выходит без потери скорости.
     */
    boolean allow(Minecraft mc, LocalPlayer p, int mode, boolean ready) {
        if (mode == 0) return ready;
        boolean canCrit = !p.onGround() && p.fallDistance > 0 && !p.isInWater()
                && !p.onClimbable() && !p.isPassenger();
        if (canCrit) {
            if (!ready) return false;
            p.setSprinting(false); // в ваниле крит невозможен во время спринта
            stuck = 0;
            return true;
        }
        if ((mode == 2 || mode == 3) && p.onGround() && !jumpPressed) {
            mc.options.keyJump.setDown(true);
            jumpPressed = true;
        }
        // "Умный": если крит долго не получается при готовом ударе, бьём обычным
        return mode == 3 && ready && ++stuck > 6;
    }
}
