package com.purple.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;

/**
 * Логика критических ударов. Режимы TriggerBot: 0 Выкл, 1 Падение, 2 Прыжок, 3 Умный.
 * Для крита в ваниле нужно, чтобы СЕРВЕР считал вас не бегущим: поэтому перед ударом отправляется
 * пакет "остановка спринта", а после удара "начало спринта" (раньше сбрасывался только локальный флаг,
 * и сервер засчитывал обычный удар вместо крита).
 */
final class CritHelper {
    private boolean jumpPressed;
    private int stuck;

    /** Крит возможен в падении: учитываем и пройденную высоту, и вертикальную скорость. */
    static boolean canCrit(LocalPlayer p) {
        return !p.onGround() && !p.isInWater() && !p.onClimbable() && !p.isPassenger()
                && (p.fallDistance > 0 || p.getDeltaMovement().y < -0.02);
    }

    /** Удар с синхронизацией спринта (если unSprint). */
    static void attack(Minecraft mc, LocalPlayer p, Entity target, boolean unSprint) {
        boolean sprinting = p.isSprinting();
        boolean sync = unSprint && sprinting && mc.getConnection() != null;
        if (sync) {
            mc.getConnection().send(new ServerboundPlayerCommandPacket(p, ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
            p.setSprinting(false);
        }
        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
        if (sync) {
            mc.getConnection().send(new ServerboundPlayerCommandPacket(p, ServerboundPlayerCommandPacket.Action.START_SPRINTING));
            p.setSprinting(true);
        }
    }

    /** Отпустить кнопку прыжка, нажатую в прошлом тике (вызывать в начале onTick). */
    void release(Minecraft mc) {
        if (jumpPressed) {
            mc.options.keyJump.setDown(false);
            jumpPressed = false;
        }
    }

    void reset() { stuck = 0; }

    /** @return true, если можно бить прямо сейчас. */
    boolean allow(Minecraft mc, LocalPlayer p, int mode, boolean ready) {
        if (mode == 0) return ready;
        if (canCrit(p)) return ready;
        if ((mode == 2 || mode == 3) && p.onGround() && !jumpPressed) {
            mc.options.keyJump.setDown(true);
            jumpPressed = true;
        }
        // "Умный": если крит долго не получается при готовом ударе, бьём обычным
        return mode == 3 && ready && ++stuck > 6;
    }
}
