package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Combat;
import com.purple.client.util.Friends;
import com.purple.client.util.TargetMarker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * AttackAura 3.1. Бьёт ТОЛЬКО критами раз в 10 тиков. Цели: все стороны (360°), игроки и любые мобы.
 * Ротация: Резкая / Плавная / Линейная / Пружина.
 * Коррекция "Свободная": камера и управление остаются у вас, модель на вашем экране смотрит на врага.
 * Коррекция "Таргет": жёсткий захват цели с поворотом камеры и подходом вплотную.
 * Только для одиночной игры и своих серверов.
 */
public class AttackAura extends Module {
    private final NumSetting range = new NumSetting("Дистанция атаки", 3.0, 2, 6, 0.1);
    private final NumSetting aimRange = new NumSetting("Дистанция наводки", 5.0, 2, 10, 0.5);
    private final BoolSetting players = new BoolSetting("Игроки", true);
    private final BoolSetting mobs = new BoolSetting("Мобы", true);
    private final BoolSetting skipPassive = new BoolSetting("Не бить жителей и питомцев", true);
    private final ModeSetting priority = new ModeSetting("Приоритет", 0, "Дистанция", "Здоровье", "Угол");
    private final ModeSetting rotation = new ModeSetting("Ротация", 1, "Резкая", "Плавная", "Линейная", "Пружина");
    private final ModeSetting correction = new ModeSetting("Коррекция", 0, "Свободная", "Таргет");
    private final BoolSetting modelLook = new BoolSetting("Модель на цель", true);
    private final BoolSetting autoJump = new BoolSetting("Авто-прыжок", true);
    private final ModeSetting targetEsp = new ModeSetting("TargetESP", 0, TargetMarker.MODES);
    private final BoolSetting walls = new BoolSetting("Сквозь стены", false);
    private final BoolSetting skipUsing = new BoolSetting("Не при еде/щите", true);

    private final TargetMarker marker = new TargetMarker();
    private final RotEngine eng = new RotEngine();
    /** Удар каждые 10 тиков, без настройки. */
    private static final int INTERVAL = 10;
    private int timer = INTERVAL;
    private LivingEntity renderTarget;

    public AttackAura() {
        super("AttackAura", "Combat");
        modelLook.showIf(() -> correction.is(0));

        settings.add(range);
        settings.add(aimRange);
        settings.add(players);
        settings.add(mobs);
        settings.add(skipPassive);
        settings.add(priority);
        settings.add(rotation);
        settings.add(correction);
        settings.add(modelLook);
        settings.add(autoJump);
        settings.add(targetEsp);
        settings.add(walls);
        settings.add(skipUsing);
    }

    /** Подходит ли существо как цель: игроки (кроме друзей) и ЛЮБЫЕ мобы. */
    private boolean accept(Entity e, LocalPlayer p) {
        if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player pl) {
            return players.value && !pl.isSpectator() && !Friends.isFriend(pl.getName().getString());
        }
        if (!mobs.value) return false;
        if (skipPassive.value && (e instanceof AbstractVillager || (e instanceof TamableAnimal t && t.isTame()))) return false;
        return true;
    }

    private LivingEntity pick(Minecraft mc, LocalPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!accept(e, p)) continue;
            double dist = Math.sqrt(e.getBoundingBox().distanceToSqr(eye));
            if (dist > aimRange.value) continue;
            if (!walls.value && !p.hasLineOfSight(e)) continue;

            LivingEntity le = (LivingEntity) e;
            double score;
            if (priority.is(1)) {
                score = le.getHealth();
            } else if (priority.is(2)) {
                Vec3 to = le.position().add(0, le.getBbHeight() * 0.5, 0).subtract(eye).normalize();
                score = Math.toDegrees(Math.acos(Mth.clamp(look.dot(to), -1.0, 1.0)));
            } else {
                score = dist;
            }
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        return best;
    }

    /** Прыжок как в ванили (с бонусом спринта), чтобы получить удар в падении. */
    private static void jump(LocalPlayer p) {
        Vec3 v = p.getDeltaMovement();
        double nx = v.x, nz = v.z;
        if (p.isSprinting()) {
            float yaw = p.getYRot() * 0.017453292F;
            nx -= Mth.sin(yaw) * 0.2;
            nz += Mth.cos(yaw) * 0.2;
        }
        p.setDeltaMovement(nx, Math.max(0.42, v.y), nz);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;

        if (mc.screen != null) {
            renderTarget = null;
            eng.end();
            return;
        }

        timer++;
        LivingEntity t = pick(mc, p);
        renderTarget = t;
        if (t == null) {
            eng.end();
            return;
        }
        Combat.set(t);

        // --- наводка ---
        Vec3 eye = p.getEyePosition();
        Vec3 aim = t.position().add(0, t.getBbHeight() * 0.75, 0);
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float ty = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float tp = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

        if (correction.is(0)) {
            // Свободная: ваша камера и управление не затрагиваются, модель смотрит на врага (только на вашем экране)
            if (!eng.active) eng.begin(p.getYRot(), p.getXRot());
            eng.step(rotation.index, ty, tp);
            if (modelLook.value) {
                p.yHeadRot = eng.yaw;
                p.yBodyRot = eng.yaw;
            }
        } else {
            // Таргет: жёсткий захват цели, камера поворачивается за ней
            eng.seed(p.getYRot(), p.getXRot());
            eng.step(rotation.index, ty, tp);
            p.setYRot(eng.yaw);
            p.setXRot(eng.pitch);

            // вжимаемся в цель, но не залезаем внутрь неё
            double hx = t.getX() - p.getX(), hz = t.getZ() - p.getZ();
            double hd = Math.hypot(hx, hz);
            double minDist = (t.getBbWidth() + p.getBbWidth()) * 0.5 + 0.25;
            Vec3 v = p.getDeltaMovement();
            if (hd > minDist && Math.hypot(v.x, v.z) < 0.3) {
                p.setDeltaMovement(v.x + hx / hd * 0.06, v.y, v.z + hz / hd * 0.06);
            }
        }

        // --- удар: только критами ---
        boolean inReach = Math.sqrt(t.getBoundingBox().distanceToSqr(eye)) <= range.value;
        if (!inReach) return;

        // сами подпрыгиваем с земли, чтобы получить удар в падении
        if (autoJump.value && p.onGround() && !p.isInWater() && !p.onClimbable() && !p.isPassenger()) {
            jump(p);
        }

        if (skipUsing.value && p.isUsingItem()) return;
        if (timer < INTERVAL) return;
        if (!CritHelper.canCrit(p)) return;

        // перед ударом сервер должен знать, что мы не бежим (иначе вместо крита будет обычный удар)
        CritHelper.attack(mc, p, t, true);
        timer = 0;
    }

    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        if (renderTarget != null && renderTarget.isAlive()) marker.render(g, renderTarget, targetEsp.index);
    }

    @Override
    public void onDisable() {
        eng.end();
        renderTarget = null;
    }
}
