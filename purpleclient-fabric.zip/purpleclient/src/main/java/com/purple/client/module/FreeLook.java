package com.purple.client.module;

import com.purple.client.setting.NumSetting;

/** Камера в третьем лице (F5) не упирается в блоки; дистанция настраивается. Логика в mixin.CameraMixin. */
public class FreeLook extends Module {
    private final NumSetting distance = new NumSetting("Дистанция", 4.0, 2, 12, 0.5);

    public FreeLook() {
        super("FreeLook", "Render");
        settings.add(distance);
    }

    public double distance() { return distance.value; }
}
