package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Держит тотем в левой руке; после сноса тотема может вернуть предмет, который лежал там раньше. */
public class AutoTotem extends Module {
    private final BoolSetting always = new BoolSetting("Всегда", true);
    private final NumSetting health = new NumSetting("Здоровье (HP)", 10, 1, 20, 1);
    private final NumSetting delay = new NumSetting("Задержка (тики)", 2, 0, 10, 1);
    private final BoolSetting returnItem = new BoolSetting("Вернуть предмет", true);

    private int timer;
    private boolean hadTotem;
    private Item saved;

    public AutoTotem() {
        super("AutoTotem", "Player");
        settings.add(always);
        settings.add(health);
        settings.add(delay);
        settings.add(returnItem);
    }

    private static int findSlot(LocalPlayer p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(item)) return 36 + i;
        for (int i = 9; i < 36; i++) if (p.getInventory().getItem(i).is(item)) return i;
        return -1;
    }

    private static void swap(Minecraft mc, LocalPlayer p, int slot) {
        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null) return;
        if (p.containerMenu != p.inventoryMenu) return;

        timer++;
        ItemStack off = p.getOffhandItem();
        boolean offTotem = off.is(Items.TOTEM_OF_UNDYING);
        if (offTotem) hadTotem = true;
        if (timer <= delay.value) return;

        boolean low = always.value || p.getHealth() + p.getAbsorptionAmount() <= health.value;
        int totemSlot = offTotem ? -1 : findSlot(p, Items.TOTEM_OF_UNDYING);

        if (!offTotem && low && totemSlot != -1) {
            if (!off.isEmpty()) saved = off.getItem(); // запоминаем, что лежало в левой руке
            swap(mc, p, totemSlot);
            timer = 0;
            return;
        }

        if (!offTotem && hadTotem) {
            // тотем снесён: возвращаем прежний предмет
            if (off.isEmpty() && returnItem.value && !always.value && saved != null) {
                int s = findSlot(p, saved);
                if (s != -1) {
                    swap(mc, p, s);
                    timer = 0;
                }
            }
            hadTotem = false;
            saved = null;
        }
    }
}
