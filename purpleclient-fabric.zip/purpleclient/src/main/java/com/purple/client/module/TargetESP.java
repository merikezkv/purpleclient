package com.purple.client.module;

import com.purple.client.setting.ModeSetting;
import com.purple.client.setting.NumSetting;
import com.purple.client.util.Combat;
import com.purple.client.util.TargetMarker;
import net.minecraft.client.gui.GuiGraphics;

/** Отмечает цель, которую бьёт AttackAura / TriggerBot / игрок. */
public class TargetESP extends Module {
    private final ModeSetting mode = new ModeSetting("Режим", 1, TargetMarker.MODES);
    private final NumSetting size = new NumSetting("Размер", 1.0, 0.5, 2.0, 0.1);
    private final TargetMarker marker = new TargetMarker();

    public TargetESP() {
        super("TargetESP", "Render");
        settings.add(mode);
        settings.add(size);
    }

    @Override
    public void onRenderHud(GuiGraphics g, int w, int h) {
        marker.size = size.value;
        marker.render(g, Combat.get(), mode.index);
    }
}
