package com.purple.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Убирает задержку прыжка: при зажатом пробеле игрок подпрыгивает сразу после приземления,
 * даже если ваниль ещё держит 10-тиковую паузу (низкие потолки, короткие прыжки, ступени).
 */
public class NoJumpDelay extends Module {
    private boolean wasGround = true;
    private int sinceJump = 100;

    public NoJumpDelay() {
        super("NoJumpDelay", "Movement");
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null) return;

        boolean ground = p.onGround();
        Vec3 v = p.getDeltaMovement();
        if (wasGround && !ground && v.y > 0.2) sinceJump = 0; else sinceJump++;
        wasGround = ground;

        // игра сама прыгнет, если пауза уже прошла; помогаем только пока пауза ещё действует
        if (ground && sinceJump < 10 && mc.options.keyJump.isDown()
                && !p.isInWater() && !p.onClimbable() && !p.isPassenger()) {
            double nx = v.x, nz = v.z;
            if (p.isSprinting()) {
                float yaw = p.getYRot() * 0.017453292F;
                nx -= Mth.sin(yaw) * 0.2;
                nz += Mth.cos(yaw) * 0.2;
            }
            p.setDeltaMovement(nx, Math.max(0.42, v.y), nz);
            sinceJump = 0;
        }
    }
}
