package com.purple.client.util;

import net.minecraft.client.gui.GuiGraphics;

public final class Draw {
    private Draw() {}

    public static int alpha(int rgb, int a) { return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF); }

    /** Прямоугольник со скруглёнными углами (радиус 3). */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int c) {
        if (w < 8 || h < 8) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x + 3, y, x + w - 3, y + 1, c);
        g.fill(x + 2, y + 1, x + w - 2, y + 2, c);
        g.fill(x + 1, y + 2, x + w - 1, y + 3, c);
        g.fill(x, y + 3, x + w, y + h - 3, c);
        g.fill(x + 1, y + h - 3, x + w - 1, y + h - 2, c);
        g.fill(x + 2, y + h - 2, x + w - 2, y + h - 1, c);
        g.fill(x + 3, y + h - 1, x + w - 3, y + h, c);
    }

    /** Линия из точек 2x2. */
    public static void line(GuiGraphics g, double x1, double y1, double x2, double y2, int color, int step) {
        double dx = x2 - x1, dy = y2 - y1;
        int n = (int) Math.max(1, Math.max(Math.abs(dx), Math.abs(dy)) / Math.max(1, step));
        n = Math.min(n, 400);
        for (int i = 0; i <= n; i++) {
            int x = (int) (x1 + dx * i / n), y = (int) (y1 + dy * i / n);
            g.fill(x, y, x + 2, y + 2, color);
        }
    }

    public static void dot(GuiGraphics g, double x, double y, int color) {
        g.fill((int) x, (int) y, (int) x + 2, (int) y + 2, color);
    }
}
