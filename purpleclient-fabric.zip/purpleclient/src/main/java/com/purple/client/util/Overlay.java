package com.purple.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

/** Строка над хотбаром: только GPS (остальной HUD рисуется в HUD-слое). */
public final class Overlay {
    private Overlay() {}

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        Component gps = Gps.line(p);
        if (gps != null) mc.gui.setOverlayMessage(gps, false);
    }
}
