package com.purple.client.util;

import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.HashSet;
import java.util.Set;

/** Вызывается из HudRenderCallback (Fabric): рисует HUD всех включённых модулей. */
public final class HudHook {
    private static final Set<String> reported = new HashSet<>();

    private HudHook() {}

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        for (Module m : ModuleManager.MODULES) {
            if (!m.isEnabled()) continue;
            try {
                m.onRenderHud(g, w, h);
            } catch (Throwable t) {
                // один раз сообщаем об ошибке отрисовки модуля
                if (reported.add(m.name)) Commands.msg("§c" + m.name + " (HUD): " + t);
            }
        }
    }
}
