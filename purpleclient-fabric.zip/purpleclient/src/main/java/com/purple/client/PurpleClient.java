package com.purple.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.purple.client.gui.ClickGuiScreen;
import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.setting.KeySetting;
import com.purple.client.setting.Setting;
import com.purple.client.util.Combat;
import com.purple.client.util.Commands;
import com.purple.client.util.Config;
import com.purple.client.util.HudHook;
import com.purple.client.util.Overlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PurpleClient implements ClientModInitializer {
    public static final String VERSION = "2.0";

    private static KeyMapping openGui;
    private final Map<Integer, Boolean> keyState = new HashMap<>();

    @Override
    public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.purpleclient.gui", GLFW.GLFW_KEY_Y, "key.categories.purpleclient"));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

        // HUD: штатное событие Fabric, работает без обходных путей
        HudRenderCallback.EVENT.register((g, dt) -> HudHook.render(g));

        // команды в чате через точку: .help .gps .bind .friend .ezz .toggle
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> {
            if (msg.length() > 1 && msg.startsWith(".")) {
                Commands.handle(msg.substring(1));
                return false;
            }
            return true;
        });

        // кнопка для телефона: в меню паузы и в инвентаре
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> onScreenInit(screen));
    }

    private void onScreenInit(Screen s) {
        if (s instanceof PauseScreen || s instanceof InventoryScreen) {
            Screens.getButtons(s).add(Button.builder(Component.literal("Purple GUI"),
                    b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                    .bounds(4, 4, 76, 20).build());
        }
    }

    private void onTick(Minecraft mc) {
        Config.loadOnce();

        while (openGui.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new ClickGuiScreen());
        }
        pollKeys(mc);

        if (mc.player != null) {
            Combat.trackManual(mc);
            ModuleManager.tick();
            Overlay.tick();
        }
    }

    /** Бинды модулей и клавиши в настройках (AutoSwap, ClickPearl): отслеживаем нажатия сами. */
    private void pollKeys(Minecraft mc) {
        long win = mc.getWindow().getWindow();

        Set<Integer> keys = new HashSet<>();
        for (Module m : ModuleManager.MODULES) {
            if (m.bindKey != -1) keys.add(m.bindKey);
            for (Setting s : m.settings) {
                if (s instanceof KeySetting ks && ks.key != -1) keys.add(ks.key);
            }
        }

        List<Integer> pressed = new ArrayList<>();
        for (int key : keys) {
            boolean down = InputConstants.isKeyDown(win, key);
            boolean was = keyState.getOrDefault(key, false);
            keyState.put(key, down);
            if (down && !was) pressed.add(key);
        }

        if (mc.screen != null || mc.player == null) return;
        for (int key : pressed) {
            for (Module m : ModuleManager.MODULES) {
                if (m.bindKey == key) m.toggle();
                if (m.isEnabled()) m.onKey(key);
            }
        }
    }
}
