package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/** Увеличивает хитбоксы существ на клиенте (в прицел попасть легче). Для одиночной игры и своих серверов. */
public class Hitboxes extends Module {
    private final NumSetting size = new NumSetting("Размер", 0.3, 0.0, 1.5, 0.05);
    private final BoolSetting players = new BoolSetting("Игроки", false);
    private final BoolSetting hostile = new BoolSetting("Враждебные", true);
    private final BoolSetting animals = new BoolSetting("Животные", false);

    private final Set<Integer> changed = new HashSet<>();

    public Hitboxes() {
        super("Hitboxes", "Combat");
        settings.add(size);
        settings.add(players);
        settings.add(hostile);
        settings.add(animals);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;

        Set<Integer> now = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!Targets.valid(e, p, players.value, hostile.value, animals.value)) continue;
            AABB base = e.getDimensions(e.getPose()).makeBoundingBox(e.position());
            e.setBoundingBox(base.inflate(size.value));
            now.add(e.getId());
        }
        for (Iterator<Integer> it = changed.iterator(); it.hasNext(); ) {
            int id = it.next();
            if (!now.contains(id)) {
                Entity e = mc.level.getEntity(id);
                if (e != null) e.refreshDimensions();
                it.remove();
            }
        }
        changed.addAll(now);
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) {
            for (int id : changed) {
                Entity e = mc.level.getEntity(id);
                if (e != null) e.refreshDimensions();
            }
        }
        changed.clear();
    }
}
